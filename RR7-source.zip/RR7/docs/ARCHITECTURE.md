# 架构和调试经验

PPU 和 SPU 的静态转译由外部 ps3recomp 工具在用户本地完成。手写 runner 加载本地 ELF 的初始数据，注册本地生成的函数和宿主 HLE 服务。这里不包含任何游戏转译结果。

## 渲染

`rr7/port/main.cpp` 按精确 60Hz 时钟派发 vblank/flip；将实际 guest flip 与完整 FIFO 帧边界关联，防止固定时钟在帧中途展示。`frame_handoff.cpp` 防止生产者过早复用两段 FIFO 缓冲。兼容性地址依赖于实际输入版本，其他地区或修订版本需要重新验证。

SDK 补丁只把真正的 3D 命令送到 3D 状态镜像，防止 2D 尺寸寄存器被当作 alpha 状态；保留透明片元的颜色和深度丢弃。有效纹理区域不应把分配尺寸中的填充区一同缩放。X32_FLOAT 采样需要把标量映射到四个通道，避免夜间 RGB 乘法偏红。

`sdk-overrides/libs/video/rsx_metalfx.m` 是 MetalFX Spatial 的薄封装。采用 720p + SMAA + 1440p，不使用时域历史。性能图表读取系统统计；GPU、CPU、RAM 曲线是整机观测值，不能当作当前进程的独占 GPU 利用率。FPS/帧间隔与 draw 计数来自渲染路径。

## 媒体与音频

`pamf_pes.hpp` 负责 PES 增量解析，`guest_au_ring.hpp` 管理 guest 所有的 AU 生命周期；Get 不应直接释放仍被解码器读取的存储。媒体工作线程和回调线程分离。输入队列有界，输出背压由真实的消费进度解除，不伪造 AUDONE 或绕过 BUSY。

`adec_bridge.cpp` 与 `vdec_bridge.cpp` 调用本地 FFmpeg。ATRAC 的通道顺序、BSI 和 FFmpeg 平面顺序需要分别处理。音频生产节奏采用 256/48000 秒，消费耗空后等待真实的新 PCM 预缓冲再恢复，避免重复旧音频掩盖问题。SPU 异步派发携带任务身份和参数快照，避免共享全局值被并发任务覆盖。

macOS 宿主在运行期间持有 scoped 活动 token，结束时释放，不改系统全局电源设置。仅靠静音块计数不能判定爆音，合法音乐也会静音；需要实际听感与录音证据。

## AppKit

AppKit 主线程运行事件队列，渲染线程通过主队列执行窗口操作，不递归调用 nextEvent。后端仅在宿主没有菜单时安装 fallback 菜单，避免覆盖正常菜单。打包时曾因 fallback Quit 持续重投 Cmd-Q 造成窗口卡住；公开补丁保留此修复。

用户可写状态放在 Application Support / Caches，应用资源保持只读。打包脚本是本地工具，会把用户私有游戏资源装进本地 App，因此它的产物绝不能直接作为本仓库的公开 Release 上传。
