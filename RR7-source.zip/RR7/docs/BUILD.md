# 本地构建

这是一份排除了游戏内容的研究源码快照，不是开箱即用的游戏。以下命令只描述本地处理流程，不提供受版权保护的输入。需要具备对输入和生成物的使用权；不要将本地生成物提交到 GitHub。

## 工具链

本地已验证环境为 Apple Silicon、macOS 27.2.1 和对应 Apple Clang / MetalFX SDK。本仓库不承诺较旧系统可编译或运行。另需 Python 3.12、CMake、Ninja；本地打包需要 Pillow。可在 `rr7/.venv312` 建立虚拟环境并安装 `cmake ninja pillow`。工具版本和依赖路径改变可能需要调整构建参数。

```sh
python3 tools/prepare_sdk.py
python3 -m venv rr7/.venv312
rr7/.venv312/bin/python -m pip install cmake ninja pillow
```

prepare_sdk 会下载固定版本的 MIT 上游源码，检验补丁并应用，再复制本仓库新增文件。它拒绝覆盖已有 SDK 目录，避免覆盖本地修改。上游内部各组件仍有独立许可证。

## 外部依赖

依赖源码/二进制不包含在本仓库。使用官方发布：

- [SDL2](https://github.com/libsdl-org/SDL/releases)：将开发用 framework 放入 `rr7/deps/SDL2.framework`。
- [FFmpeg 8.0.1](https://ffmpeg.org/releases/)：源码压缩包放入 `rr7/deps-src/ffmpeg-8.0.1.tar.xz`。`rr7/build_media_deps.sh` 内固定 SHA-256，构建 MPEG2 / ATRAC3plus 共享库到 `deps-prefix-av`。将同版本头文件放入 `deps-prefix/include`，打包时保留原始 `ffmpeg-8.0.1/COPYING.LGPLv2.1`。
- [glslang](https://github.com/KhronosGroup/glslang) 16.6.0 和 [SPIRV-Cross](https://github.com/KhronosGroup/SPIRV-Cross) MoltenVK-1.1.5：通过它们各自的 CMake 构建并安装到 `rr7/deps-prefix`。保留相应源码许可证在 `rr7/deps-src/glslang/LICENSE.txt` 和 `rr7/deps-src/SPIRV-Cross/LICENSE` 供本地打包使用。

依赖安装部分记录了已运行版本和布局，尚未做全自动干净机器安装验证。动态库名称、API 和打包布局变化时应先检查本地脚本，不能仅依赖文件名。

## 本地私有输入

在本地准备有权使用的兼容游戏输入：`rr7/EBOOT.ELF` 和 `rr7/game/PS3_GAME/USRDIR/`。本项目使用 BCAS-20001 布局；其他版本的 hard-coded 同步地址不保证有效。这里不提供解密、密钥、镜像下载或素材提取步骤。

```sh
python3 ps3recomp/tools/ppu_lifter.py rr7/EBOOT.ELF --output rr7/port/recompiled
rr7/build_native.sh
```

SPU 输入由 CMake 的 `PORT_SPU_INPUTS` 传入，在本地构建目录生成。不要提交 `port/recompiled`、`build/generated_spu` 或 SPU 镜像。上面的重生成流程没有在本次公开清理中重新执行整场比赛验收；若重生成输出与本地历史版本不同，需要重新验证。

## 本地打包

为打包提供自己的、具有发布/使用权限的方形 PNG 图标，通过 `RR7_ICON` 指定路径。原游戏图标和基于其生成的图标没有随仓库发布。

```sh
RR7_ICON=/absolute/path/to/your-own-icon.png rr7/.venv312/bin/python rr7/package_app.py
```

脚本还要求本地 `game/PS3_DISC.SFB`、`game/PS3_GAME/PARAM.SFO`、完整 USRDIR 以及 `gamedata/`、`hdd0/` 目录。没有旧存档可迁移时，自行创建这两个空目录。脚本拒绝覆盖已有桌面 RR7.app。它会将游戏资源、ELF 和必要动态库放入本地应用，执行 ad-hoc 签名。这种产物含私有游戏内容，**不要公开上传**。默认 720p→1440p，存档位于用户 Library。

本仓库的扫描和 CI 只运行不依赖游戏的检查；完整媒体/赛车检查应在有权使用的本地环境中完成。
