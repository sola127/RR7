# RR7

版本 **0.3.1** · 2026-11-17。

中文为主的 Apple Silicon / Metal 原生静态重编译研究项目，研究对象为 Ridge Racer 7。仓库发布手写的宿主代码、媒体 ABI 桥接、ps3recomp 补丁和测试，便于参考实现与调试方法。

**这不是游戏下载，也不包含可直接运行的游戏 App。** 原游戏的可执行文件、资源和从中转译生成的 PPU/SPU 源码均不发布。构建需要自行准备有权使用的本地输入。仓库不提供下载来源、解密密钥或破解工具。

## 实现范围

- 固定 1280×720 内部渲染，MetalFX Spatial 输出 720p / 1080p / 1440p / 4K。
- 关闭 / FXAA / SMAA / 真正的 2×、4×、8× MSAA；多采样颜色、深度和模板缓冲保留与 resolve。
- AppKit 主线程事件循环、单实例 App、CPU / GPU / 内存性能图表。
- F1、⌘, 或窗口“设置 F1”打开画面、声音、操作和存档设置；手柄选择与键位映射、音量与静音、存档位置迁移。
- 白名单打包、仅 ARM64 必需依赖、ad-hoc 签名；可收益资源使用 macOS 透明无损压缩并逐文件 SHA-256 验证。
- 原生 MPEG2 / ATRAC3plus 媒体路径，异步 AU 队列、回调与输出背压。
- 修正 2D / 3D FIFO 状态路由、透明树木 alpha、有效纹理区域和标量光照纹理采样。
- SPU 任务身份和事件、音频输出预缓冲与重新缓冲、macOS 活动保护、Switch Pro 输入。

本地手动反馈确认菜单/赛车操作、音乐、影片和六分钟闲置音频。设置入口、输出分辨率、音量/输入参数和存档迁移边界已检查；真正的 MSAA 通过独立 Metal 边缘覆盖、深度/模板和跨 pass 测试。0.3.1 保持运行时代码，验证资源字节一致性和签名。完整比赛、保存/载入、日文字形、所有赛道及更长稳定性未全面验收；不要把这些局部结果当作完整兼容性保证。

## 开始阅读

1. [架构与修复说明](docs/ARCHITECTURE.md)
2. [本地构建与资源边界](docs/BUILD.md)
3. [发布范围与权利审查](docs/RIGHTS_REVIEW.md)
4. [第三方署名](NOTICE.md)

```sh
python3 tools/audit_public.py
c++ -std=c++17 -O1 -pthread rr7/test_au_ring.cpp -o /tmp/rr7-au-ring
/tmp/rr7-au-ring
```

[版本变更](CHANGELOG.md)。上述 ring 测试使用人工构造的数据，不需要原游戏。其他媒体集成测试需要本地合法输入，CI 不下载游戏。

## 上游与许可证

本项目基于 **Ned Heller / sp00nznet 的 [ps3recomp](https://github.com/sp00nznet/ps3recomp)**，上游版本固定在 `upstream.json`。请保留上游作者署名。原创补充和 MIT 部分按 [LICENSE](LICENSE) 发布；ATRAC 相关补丁保留其所在组件的 LGPL-2.1-or-later 条款，见 [NOTICE.md](NOTICE.md)。

RR7 / Ridge Racer 7 名称仅用于说明兼容性研究对象。本项目与游戏发行商、开发商及平台厂商没有隶属或授权关系。公开源码许可证不授予任何原游戏内容、商标、专利或第三方资产的权利。
