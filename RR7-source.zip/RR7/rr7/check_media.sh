#!/bin/zsh
# Reproduce the native media checks against the existing local dependencies.
set -eu
rr7_root="${0:A:h}"
rr7_inc="$rr7_root/deps-prefix/include"
rr7_lib="$rr7_root/deps-prefix/lib"
rr7_title="$rr7_root/game/PS3_GAME/USRDIR/title.pam"
export PS3RECOMP_FFMPEG_AVCODEC="$rr7_lib/libavcodec.dylib"
export PS3RECOMP_FFMPEG_AVUTIL="$rr7_lib/libavutil.dylib"
clang++ -std=c++17 -O1 -g -fsanitize=address,undefined \
  "$rr7_root/test_pes.cpp" -o "$rr7_root/test_pes"
"$rr7_root/test_pes" "$rr7_title"
clang++ -std=c++17 -O1 -g -fsanitize=address,undefined -I "$rr7_inc" \
  "$rr7_root/test_video_au.cpp" -L "$rr7_lib" -lavcodec -lavutil -o "$rr7_root/test_video_au"
"$rr7_root/test_video_au" "$rr7_title"
clang++ -std=c++17 -O1 -g -fsanitize=address,undefined \
  "$rr7_root/test_au_ring.cpp" -o "$rr7_root/test_au_ring"
"$rr7_root/test_au_ring"
clang++ -std=c++17 -O1 -g -fsanitize=address,undefined -I "$rr7_inc" \
  "$rr7_root/probe_video.cpp" -L "$rr7_lib" -lavcodec -lavutil -o "$rr7_root/probe_video"
"$rr7_root/probe_video" "$rr7_title" "$rr7_root/analysis/native-video-frame.ppm" \
  "$rr7_root/analysis/title-sample.m2v" "$rr7_root/analysis/title-reference.yuv"
clang -std=c17 -O1 -g -fsanitize=address,undefined -DPS3RECOMP_FFMPEG_RUNTIME \
  -I "$rr7_root/../ps3recomp/include" -I "$rr7_inc" \
  "$rr7_root/../ps3recomp/libs/codec/tests/test_vdec_decode.c" -o "$rr7_root/test_vdec_ffmpeg_san" -lm
"$rr7_root/test_vdec_ffmpeg_san" decode mpeg2 "$rr7_root/analysis/title-sample.m2v" \
  "$rr7_root/analysis/title-reference.yuv" 1280 720
clang++ -std=c++17 -O1 -g -fsanitize=address,undefined \
  -DPPU_NO_INLINE_LOADS -I "$rr7_root/port/recompiled" -I "$rr7_root/../ps3recomp/include" -I "$rr7_inc" \
  "$rr7_root/test_dmux_bridge.cpp" "$rr7_root/port/dmux_bridge.cpp" \
  -L "$rr7_lib" -lavcodec -lavutil -o "$rr7_root/analysis/test_dmux_bridge"
"$rr7_root/analysis/test_dmux_bridge" "$rr7_title"
clang++ -std=c++17 -O1 -g -fsanitize=address,undefined \
  -DPPU_NO_INLINE_LOADS -I "$rr7_root/port/recompiled" -I "$rr7_root/../ps3recomp/include" \
  "$rr7_root/test_vdec_callbacks.cpp" "$rr7_root/port/vdec_bridge.cpp" \
  -o "$rr7_root/analysis/test_vdec_callbacks"
"$rr7_root/analysis/test_vdec_callbacks"
clang++ -std=c++17 -O1 -g -fsanitize=address,undefined \
  -DPPU_NO_INLINE_LOADS -I "$rr7_root/port/recompiled" -I "$rr7_root/../ps3recomp/include" \
  "$rr7_root/test_vdec_backpressure.cpp" "$rr7_root/port/vdec_bridge.cpp" \
  -o "$rr7_root/analysis/test_vdec_backpressure"
"$rr7_root/analysis/test_vdec_backpressure"
for rr7_case in test_audio_au test_adec_bridge test_dmux_audio; do
  rr7_sources=("$rr7_root/$rr7_case.cpp")
  if [[ "$rr7_case" == test_adec_bridge ]]; then
    rr7_sources+=("$rr7_root/port/adec_bridge.cpp")
  elif [[ "$rr7_case" == test_dmux_audio ]]; then
    rr7_sources+=("$rr7_root/port/dmux_bridge.cpp")
  fi
  clang++ -std=c++17 -O1 -g -fsanitize=address,undefined -DPPU_NO_INLINE_LOADS \
    -I "$rr7_root/port/recompiled" -I "$rr7_root/../ps3recomp/include" \
    -I "$rr7_root/deps-prefix-av/include" "${rr7_sources[@]}" \
    -L "$rr7_root/deps-prefix-av/lib" -lavcodec -lavutil -o "$rr7_root/analysis/$rr7_case"
  "$rr7_root/analysis/$rr7_case" "$rr7_root/game/PS3_GAME/USRDIR/intro.pam"
done
