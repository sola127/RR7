#include <mutex>
#include <atomic>
#include "port/frame_handoff.cpp"
#include <cassert>
#include <unordered_map>
lv2_syscall_table g_lv2_syscalls={};
static std::mutex memoryLock;
static std::unordered_map<uint64_t,uint32_t> memory;
extern "C" uint32_t vm_read32(uint64_t p){std::lock_guard<std::mutex>l(memoryLock);return memory[p];}
static void write(uint64_t p,uint32_t v){std::lock_guard<std::mutex>l(memoryLock);memory[p]=v;}
extern "C" uint32_t gcm_io_offset_to_ea(uint32_t p){return p+0x11100000;}
extern "C" void* cellGcmGetControlRegister(){return reinterpret_cast<void*>(0x20002000);}
static std::atomic<unsigned> posts{0};
static int64_t originalPost(ppu_context*){posts++;return 0;}
int main(){
    setenv("RR7_RSX_HANDOFF","1",1);g_lv2_syscalls.handlers[94]=originalPost;
    write(0x4d6a68,0);rr7_register_frame_handoff();assert(g_lv2_syscalls.handlers[94]==originalPost);
    write(0x4d6a68,0x4b9394);rr7_register_frame_handoff();
    write(0x1049ce60,5);write(0x107bf8f0,0x107bf8e0);write(0x107bf8e0,0x121a0000);write(0x107bf8e4,0x1258fffc);
    write(0x20002000,0xcb12d0);write(0x20002004,0x10a0d2c);
    ppu_context c={};c.thread_id=4;c.gpr[3]=5;assert(g_lv2_syscalls.handlers[94](&c)==0&&posts==1);
    c.thread_id=1;c.gpr[3]=6;assert(g_lv2_syscalls.handlers[94](&c)==0&&posts==2);
    c.gpr[3]=5;
    std::thread consumer([]{std::this_thread::sleep_for(std::chrono::milliseconds(25));assert(posts==2);write(0x20002004,0xcb0010);});
    assert(g_lv2_syscalls.handlers[94](&c)==0);consumer.join();assert(posts==3);
    write(0x20002000,0x10a0000);write(0x20002004,0x10a0000);
    assert(g_lv2_syscalls.handlers[94](&c)==0&&posts==4);
    puts("Frame handoff: protects in-flight producer storage; ignores other threads/semaphores and an idle FIFO PASS");
}
