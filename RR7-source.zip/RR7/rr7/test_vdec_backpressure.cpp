#include "ppu_recomp.h"
#include "../ps3recomp/libs/codec/cellVdec.h"
#include "ps3emu/guest_call.h"
#include <atomic>
#include <cassert>
#include <chrono>
#include <mutex>
#include <thread>
#include <unordered_map>
#include <vector>
#include <cstdio>
uint8_t* vm_base;
extern "C" uint32_t vm_read32(uint64_t p){return uint32_t(vm_base[p])<<24|uint32_t(vm_base[p+1])<<16|uint32_t(vm_base[p+2])<<8|vm_base[p+3];}
static void w32(uint32_t p,uint32_t v){for(int i=0;i<4;i++)vm_base[p+i]=v>>(24-i*8);}
extern "C" void rr7_register_vdec_bridge();
static std::unordered_map<uint32_t,void(*)(ppu_context*)> functions;
extern "C" void ps3_hle_register_ctx(uint32_t n,const char*,void(*f)(ppu_context*)){functions[n]=f;}
CellVdecCallbackDispatch cellVdecCallbackDispatchHook=nullptr;
static std::atomic<bool> full{false};
static std::atomic<int> pictures{0},done{0},ends{0},errors{0},seqdone{0},busy{0};
static std::mutex records_lock;
static std::vector<uint64_t> records;
static size_t end_count;
extern "C" s32 cellVdecOpen(const CellVdecType*,const CellVdecResource*,const CellVdecCb*,CellVdecHandle* p){w32(uintptr_t(p),1);return 0;}
extern "C" s32 cellVdecClose(CellVdecHandle){return 0;}
extern "C" s32 cellVdecStartSeq(CellVdecHandle){return 0;}
extern "C" s32 cellVdecDecodeAuHost(CellVdecHandle h,s32 mode,const CellVdecAuInfo* au){
 assert(h==1&&mode==0);
 if(au->userData==0xBAD)return int32_t(CELL_VDEC_ERROR_AU);
 if(full.exchange(true)){busy++;return int32_t(CELL_VDEC_ERROR_BUSY);}
 assert(au->startAddr==0x11000&&au->size==17&&au->pts==0x123456789ABCDEF0ull);
 {std::lock_guard<std::mutex> l(records_lock);records.push_back(au->userData);}
 cellVdecCallbackDispatchHook(h,0x1234,0,0,0xCAFE);
 cellVdecCallbackDispatchHook(h,0x1234,1,0,0xCAFE);return 0;
}
extern "C" s32 cellVdecEndSeq(CellVdecHandle h){
 {std::lock_guard<std::mutex> l(records_lock);end_count=records.size();}ends++;
 cellVdecCallbackDispatchHook(h,0x1234,2,0,0xCAFE);return 0;
}
static void callback(uint32_t cb,uint64_t h,uint64_t kind,uint64_t data,uint64_t arg,uint64_t,uint64_t,uint64_t,uint64_t){
 assert(cb==0x1234&&h==1&&arg==0xCAFE);
 if(kind==0){if(uint32_t(data))assert(uint32_t(data)==CELL_VDEC_ERROR_AU);done++;}
 if(kind==1)pictures++;
 if(kind==2)seqdone++;
 if(kind==3){assert(uint32_t(data)==CELL_VDEC_ERROR_AU);errors++;}
}
ps3_guest_caller_fn g_ps3_guest_caller=callback;
static int32_t command(uint32_t n){ppu_context c{};c.gpr[3]=1;functions.at(n)(&c);return int32_t(c.gpr[3]);}
static int32_t submit(uint32_t id){
 w32(0x10040,0x11000);w32(0x10044,17);w32(0x10048,0x12345678);w32(0x1004C,0x9ABCDEF0);
 w32(0x10050,0);w32(0x10054,0);w32(0x10058,0);w32(0x1005C,id);
 ppu_context c{};c.gpr[3]=1;c.gpr[5]=0x10040;functions.at(0x2BF4DDD2)(&c);
 w32(0x1005C,0xDEAD);return int32_t(c.gpr[3]);
}
template<class F>static void wait_for(F f){auto end=std::chrono::steady_clock::now()+std::chrono::seconds(5);
 while(!f()){assert(std::chrono::steady_clock::now()<end);std::this_thread::sleep_for(std::chrono::milliseconds(1));}}
int main(){
 uint8_t memory[0x12000]{};vm_base=memory;rr7_register_vdec_bridge();
 w32(0x10100,0x1234);w32(0x10104,0xCAFE);
 ppu_context c{};c.gpr[5]=0x10100;c.gpr[6]=0x10000;functions.at(0xB6BBCD5D)(&c);assert(c.gpr[3]==0);
 assert(uint32_t(submit(1))==CELL_VDEC_ERROR_SEQ);
 assert(command(0xC757C2AA)==0);
 assert(submit(11)==0);wait_for([]{return pictures==1;});
 const auto t0=std::chrono::steady_clock::now();assert(submit(12)==0&&submit(13)==0);
 assert(std::chrono::steady_clock::now()-t0<std::chrono::milliseconds(100));
 wait_for([]{return busy>0;});assert(pictures==1&&done==1);
 assert(command(0x824433F0)==0);assert(ends==0);
 full=false;wait_for([]{return pictures==2;});assert(ends==0);
 full=false;wait_for([]{return pictures==3&&seqdone==1;});
 {std::lock_guard<std::mutex> l(records_lock);assert((records==std::vector<uint64_t>{11,12,13})&&end_count==3);}
 assert(command(0xC757C2AA)==0);assert(submit(0xBAD)==0);wait_for([]{return errors==1&&done==4;});
 // Close while output backpressure blocks a real input worker. Pending AUs
 // cannot get fake successful AUDONE or leak callbacks after the close.
 full=true;const int old_busy=busy;assert(submit(21)==0);wait_for([&]{return busy>old_busy;});
 unsigned accepted=0;int32_t rc=0;for(unsigned i=0;i<16;i++){rc=submit(30+i);if(rc)break;accepted++;}
 assert(accepted<=8&&uint32_t(rc)==CELL_VDEC_ERROR_BUSY);
 // StartSeq cancels a blocked previous generation and owns a clean input queue.
 assert(command(0xC757C2AA)==0);full=false;assert(submit(41)==0);
 wait_for([]{return pictures==4&&done==5;});
 {std::lock_guard<std::mutex> l(records_lock);assert((records==std::vector<uint64_t>{11,12,13,41}));}
 const int close_busy=busy;assert(submit(42)==0);wait_for([&]{return busy>close_busy;});
 const auto closing=std::chrono::steady_clock::now();assert(command(0x16698E83)==0);
 assert(std::chrono::steady_clock::now()-closing<std::chrono::milliseconds(250));
 assert(done==5&&pictures==4&&errors==1);
 puts("Vdec backpressure: callback progress, owned descriptor, ordered EndSeq, explicit failure, bounded queue and close cancellation PASS");
}
