#import <Foundation/Foundation.h>
#include <unistd.h>
static NSString* rr7_default_save_root(void){
    NSURL* support=[NSFileManager.defaultManager URLsForDirectory:NSApplicationSupportDirectory inDomains:NSUserDomainMask].firstObject;
    return [[support URLByAppendingPathComponent:@"RR7/SaveData" isDirectory:YES] path];
}
static NSString* rr7_selected_save_root(void){
    NSString* selected=[NSUserDefaults.standardUserDefaults stringForKey:@"SaveRoot"];
    return selected.length?[selected.stringByExpandingTildeInPath stringByStandardizingPath]:rr7_default_save_root();
}
static BOOL rr7_save_error(NSError** error,NSString* message){
    if(error)*error=[NSError errorWithDomain:@"RR7SavePath" code:1 userInfo:@{NSLocalizedDescriptionKey:message}];return NO;
}
/* Run under the game session lock, before the guest can write. Existing
 * profiles are used as-is; a new root receives a staged full copy. */
static BOOL rr7_prepare_save_root(NSString* destination,NSString* source,NSError** error){
    NSFileManager* fm=NSFileManager.defaultManager;
    destination=destination.stringByResolvingSymlinksInPath;source=source.stringByResolvingSymlinksInPath;
    for(NSString* component in destination.pathComponents)
        if([component.pathExtension.lowercaseString isEqualToString:@"app"])return rr7_save_error(error,@"存档不能放在应用程序包内。请选择普通文件夹。");
    if([source isEqualToString:destination])return [fm createDirectoryAtPath:destination withIntermediateDirectories:YES attributes:nil error:error];
    if([destination hasPrefix:[source stringByAppendingString:@"/"]]||[source hasPrefix:[destination stringByAppendingString:@"/"]])
        return rr7_save_error(error,@"新旧存档目录不能互相包含。请选择其他位置。");
    BOOL directory=NO;BOOL exists=[fm fileExistsAtPath:destination isDirectory:&directory];
    if(exists&&!directory)return rr7_save_error(error,@"目标路径不是文件夹。");
    NSArray* contents=exists?[fm contentsOfDirectoryAtPath:destination error:error]:@[];
    if(exists&&!contents)return NO;
    if(contents.count){
        BOOL profile=NO;
        if(![fm fileExistsAtPath:[destination stringByAppendingPathComponent:@"dev_hdd0"] isDirectory:&profile]||!profile)
            return rr7_save_error(error,@"目标不是空目录，也没有 RR7 存档结构。请选择其他位置。");
        if(![fm isWritableFileAtPath:destination])return rr7_save_error(error,@"存档目录不可写。");
        return YES;
    }
    NSString* parent=destination.stringByDeletingLastPathComponent;
    if(![fm createDirectoryAtPath:parent withIntermediateDirectories:YES attributes:nil error:error])return NO;
    NSString* stage=[parent stringByAppendingPathComponent:[@".rr7-save-copy-" stringByAppendingString:NSUUID.UUID.UUIDString]];
    BOOL copied=[fm fileExistsAtPath:source]?[fm copyItemAtPath:source toPath:stage error:error]:[fm createDirectoryAtPath:stage withIntermediateDirectories:NO attributes:nil error:error];
    if(!copied){[fm removeItemAtPath:stage error:NULL];return NO;}
    if(exists&&rmdir(destination.fileSystemRepresentation)!=0){[fm removeItemAtPath:stage error:NULL];return rr7_save_error(error,@"目标目录已变化，未覆盖任何文件。请重试。");}
    if(![fm moveItemAtPath:stage toPath:destination error:error]){[fm removeItemAtPath:stage error:NULL];return NO;}
    return YES;
}
