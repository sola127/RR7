/* RR7's producer recycles a two-buffer FIFO immediately after unblocking an
 * acquire at the old buffer's tail. A polling host must let the consumer leave
 * that tail before starting the native producer on the same storage. */
#include "../../ps3recomp/runtime/syscalls/lv2_syscall_table.h"
extern "C" uint32_t vm_read32(uint64_t);
#include <chrono>
#include <thread>
#include <cstdlib>
#include <cstdio>
extern "C" uint32_t gcm_io_offset_to_ea(uint32_t);
extern "C" void* cellGcmGetControlRegister(void);
namespace {
lv2_syscall_fn original;
int64_t post(ppu_context* c) {
    if (c->thread_id == 1 && uint32_t(c->gpr[3]) == vm_read32(0x1049ce60)) {
        const uint32_t context = vm_read32(0x107bf8f0);
        const uint32_t begin = context ? vm_read32(context) : 0;
        const uint32_t end = context ? vm_read32(context + 4) : 0;
        const uint32_t control = uint32_t(uintptr_t(cellGcmGetControlRegister()));
        auto until = std::chrono::steady_clock::now() + std::chrono::milliseconds(250);
        unsigned polls = 0;
        for (;;) {
            const uint32_t put = vm_read32(control), get = vm_read32(control + 4);
            const uint32_t ea = gcm_io_offset_to_ea(get);
            if (!begin || end <= begin || ea < begin || ea > end || get == put) break;
            if (std::chrono::steady_clock::now() >= until) {
                std::fprintf(stderr,"[rr7-handoff] timeout protecting %08X..%08X get=%08X put=%08X\n",begin,end,get,put);
                break;
            }
            polls++;
            std::this_thread::sleep_for(std::chrono::microseconds(50));
        }
        static unsigned reports = 0;
        if (polls && reports++ < 16) std::fprintf(stderr,"[rr7-handoff] protected producer reuse after %u polls\n",polls);
    }
    return original(c);
}
}
extern "C" void rr7_register_frame_handoff(void) {
    const char* enabled = std::getenv("RR7_RSX_HANDOFF");
    if (!enabled || enabled[0] != '1') return;
    if (vm_read32(0x4d6a68) != 0x4b9394) {
        std::fprintf(stderr,"[rr7-handoff] unsupported executable layout\n"); return;
    }
    original = g_lv2_syscalls.handlers[SYS_SEMAPHORE_POST];
    g_lv2_syscalls.handlers[SYS_SEMAPHORE_POST] = post;
}
