/* RR7 SDK ABI adaptation. EAs stay 32-bit, floats arrive in FPRs, and
 * the SDK-facing argument order differs from several toolkit APIs. */
#include "ppu_recomp.h"
#include "../../ps3recomp/libs/font/cellFont.h"
#include <cstdio>
#include <algorithm>
#include <cstdint>
extern "C" void ps3_hle_register_ctx(uint32_t, const char*, void (*)(ppu_context*));
extern "C" int64_t sys_memory_allocate(ppu_context*);
extern "C" int64_t sys_memory_free(ppu_context*);
static uint32_t arg(ppu_context* c, int n) { return uint32_t(c->gpr[n]); }
template<class T> static T* ptr(uint32_t ea) { return reinterpret_cast<T*>(uintptr_t(ea)); }
static void result(ppu_context* c, int32_t rc) { c->gpr[3] = uint64_t(int64_t(rc)); }
static void font_library(ppu_context* c) {
    const uint32_t config=arg(c,4), out=arg(c,5);
    if (!out) { result(c,CELL_FONT_ERROR_INVALID_PARAMETER); return; }
    vm_write32(out,0);
    if (!config) { result(c,CELL_FONT_ERROR_INVALID_PARAMETER); return; }
    ppu_context allocation=*c;
    allocation.gpr[3]=0x10000; allocation.gpr[4]=0x200; allocation.gpr[5]=out;
    const int32_t rc=int32_t(sys_memory_allocate(&allocation));
    if (rc) { result(c,CELL_FONT_ERROR_ALLOCATION_FAILED); return; }
    const uint32_t library=vm_read32(out);
    // CellFontLibrary: libraryType, libraryVersion, SystemClosed.
    vm_write32(library,0); vm_write32(library+4,0); vm_write32(library+8,0);
    fprintf(stderr,"[rr7-font] library config=0x%08X out=0x%08X library=0x%08X\n",config,out,library);
    result(c,0);
}
static void font_end_library(ppu_context* c) {
    if (!arg(c,3)) { result(c,CELL_FONT_ERROR_INVALID_PARAMETER); return; }
    result(c,int32_t(sys_memory_free(c)));
}
static void font_id_code(ppu_context* c) {
    const uint32_t font=arg(c,3), code=arg(c,4), id=arg(c,5), mapped=arg(c,6);
    if (id) vm_write32(id,0);
    if (mapped) vm_write32(mapped,0);
    if (!font) { result(c,CELL_FONT_ERROR_INVALID_PARAMETER); return; }
    // The Unicode fontset uses the incoming codepoint without remapping.
    if (mapped) vm_write32(mapped,code);
    result(c,0);
}
static void font_create_renderer(ppu_context* c) {
    if (!arg(c,3) || !arg(c,4) || !arg(c,5)) { result(c,CELL_FONT_ERROR_INVALID_PARAMETER); return; }
    result(c,cellFontCreateRenderer(arg(c,3),ptr<CellFontRenderer>(arg(c,5))));
}
static void font_bind_renderer(ppu_context* c) {
    if (!arg(c,4)) { result(c,CELL_FONT_ERROR_INVALID_PARAMETER); return; }
    result(c,cellFontBindRenderer(ptr<CellFont>(arg(c,3)),vm_read32(arg(c,4))));
}
static void font_destroy_renderer(ppu_context* c) {
    if (!arg(c,3)) { result(c,CELL_FONT_ERROR_INVALID_PARAMETER); return; }
    result(c,cellFontDestroyRenderer(vm_read32(arg(c,3))));
}
static void font_open_memory(ppu_context* c) {
    if (!arg(c,3)) { result(c,CELL_FONT_ERROR_INVALID_PARAMETER); return; }
    result(c,cellFontOpenFontMemory(ptr<CellFont>(arg(c,8)),ptr<void>(arg(c,4)),arg(c,5),arg(c,6),int32_t(arg(c,7))));
}
static void font_scale(ppu_context* c) {
    result(c,cellFontSetScalePixel(ptr<CellFont>(arg(c,3)),float(c->fpr[1]),float(c->fpr[2])));
}
static void font_metrics(ppu_context* c) {
    result(c,cellFontGetRenderCharGlyphMetrics(ptr<CellFont>(arg(c,3)),arg(c,4),ptr<CellFontGlyphMetrics>(arg(c,5))));
}
static void font_render(ppu_context* c) {
    // Floating-point parameters reserve r6/r7, with metrics/info in r8/r9.
    // The toolkit's image struct is not CellFontImageTransInfo. Let it render
    // into the guest surface, then describe that surface using the SDK ABI.
    uint32_t font=arg(c,3), surface=arg(c,5), info=arg(c,9);
    if (!font || !surface) { result(c,CELL_FONT_ERROR_INVALID_PARAMETER); return; }
    int32_t rc=cellFontRenderCharGlyphImage(ptr<CellFont>(font),arg(c,4),
        ptr<CellFontRenderSurface>(surface),float(c->fpr[1]),float(c->fpr[2]),
        ptr<CellFontGlyphMetrics>(arg(c,8)),nullptr);
    if (!rc && info) {
        uint32_t buffer=vm_read32(surface),pitch=vm_read32(surface+4);
        vm_write32(info,buffer); vm_write32(info+4,pitch);
        vm_write32(info+8,vm_read32(surface+12)); vm_write32(info+12,vm_read32(surface+16));
        vm_write32(info+16,buffer); vm_write32(info+20,pitch);
    }
    result(c,rc);
}
static void font_surface(ppu_context* c) {
    const uint32_t s=arg(c,3); if (!s) return;
    vm_write32(s,arg(c,4)); vm_write32(s+4,arg(c,5)); vm_write32(s+8,arg(c,6));
    const uint32_t w=uint32_t(std::max(0,int32_t(arg(c,7)))), h=uint32_t(std::max(0,int32_t(arg(c,8))));
    vm_write32(s+12,w); vm_write32(s+16,h);
    vm_write32(s+20,0); vm_write32(s+24,0); vm_write32(s+28,w); vm_write32(s+32,h);
}
static void font_scissor(ppu_context* c) {
    const uint32_t s=arg(c,3); if (!s) return;
    const int64_t x=int32_t(arg(c,4)),y=int32_t(arg(c,5));
    const int64_t w=vm_read32(s+12),h=vm_read32(s+16);
    vm_write32(s+20,uint32_t(std::clamp<int64_t>(x,0,w)));
    vm_write32(s+24,uint32_t(std::clamp<int64_t>(y,0,h)));
    vm_write32(s+28,uint32_t(std::clamp<int64_t>(x+arg(c,6),0,w)));
    vm_write32(s+32,uint32_t(std::clamp<int64_t>(y+arg(c,7),0,h)));
}
extern "C" void rr7_register_font_bridge(void) {
    ps3_hle_register_ctx(0x7A0A83C4,"cellFontInitLibraryFreeTypeWithRevision",font_library);
    ps3_hle_register_ctx(0x40D40544,"cellFontEndLibrary",font_end_library);
    ps3_hle_register_ctx(0x98AC5524,"cellFontGetFontIdCode",font_id_code);
    ps3_hle_register_ctx(0x042E74E3,"cellFontCreateRenderer",font_create_renderer);
    ps3_hle_register_ctx(0x66A23100,"cellFontBindRenderer",font_bind_renderer);
    ps3_hle_register_ctx(0x21EBB248,"cellFontDestroyRenderer",font_destroy_renderer);
    ps3_hle_register_ctx(0x9E19072B,"cellFontOpenFontMemory",font_open_memory);
    ps3_hle_register_ctx(0x297F0E93,"cellFontSetScalePixel",font_scale);
    ps3_hle_register_ctx(0xD8EAEE9F,"cellFontGetCharGlyphMetrics",font_metrics);
    ps3_hle_register_ctx(0x88BE4799,"cellFontRenderCharGlyphImage",font_render);
    ps3_hle_register_ctx(0x90B9465E,"cellFontRenderSurfaceInit",font_surface);
    ps3_hle_register_ctx(0xB422B005,"cellFontRenderSurfaceSetScissor",font_scissor);
}
