/* RR7's imported PAMF APIs. All addresses and output layouts use the PS3 ABI.
 * Supports PAMF 0040/0041 with one grouping period and one stream group.
 * It deliberately rejects other layouts instead of fabricating stream data. */
#include "ppu_recomp.h"
#include <cstdint>
#include <cstdio>
#include <mutex>
#include <unordered_map>
extern "C" void ps3_hle_register_ctx(uint32_t, const char*, void (*)(ppu_context*));
namespace {
constexpr uint32_t invalid=0x80610503, badHeader=0x80610502, noStream=0x80610501;
struct Reader { uint32_t base, count, index; };
std::unordered_map<uint32_t,Reader> readers;
std::mutex readerLock;
uint32_t a(ppu_context* c,int r) { return uint32_t(c->gpr[r]); }
void rc(ppu_context* c,uint32_t r) { c->gpr[3]=uint64_t(int64_t(int32_t(r))); }
bool range(uint32_t p,uint64_t size) { return p>=0x10000 && uint64_t(p)+size<=0x100000000ull; }
uint32_t sizes(uint32_t base,uint64_t fileSize,uint64_t& header,uint64_t& data) {
    if (!range(base,0x88)) return invalid;
    if (vm_read32(base)!=0x50414d46) return 0x80610504;
    uint32_t version=vm_read32(base+4);
    if (version!=0x30303430 && version!=0x30303431) return 0x80610505;
    header=uint64_t(vm_read32(base+8))*2048;
    data=uint64_t(vm_read32(base+12))*2048;
    if (header<0x88 || !range(base,header) || (fileSize && header+data!=fileSize)) return badHeader;
    return 0;
}
bool get(uint32_t ea,Reader& r) {
    std::lock_guard<std::mutex> lock(readerLock);
    auto i=readers.find(ea); if(i==readers.end()) return false; r=i->second; return true;
}
uint32_t desc(const Reader& r,uint32_t index) { return r.base+0x88+index*48; }
int type(uint32_t d) {
    switch(vm_read8(d)) { case 0x1b:return 0; case 2:return 1; case 0xdc:return 2;
      case 0x80:return 3; case 0x81:return 4; case 0xdd:return 5; default:return -1; }
}
bool matches(int actual,uint32_t wanted) {
    return actual>=0 && (uint32_t(actual)==wanted || (wanted==20 && actual<2) ||
      (wanted==21 && actual>=2 && actual<=4) || (wanted==22 && actual==5));
}
void header_size(ppu_context* c) {
    uint64_t h=0,d=0; uint32_t out=a(c,5);
    uint32_t e=range(out,8)?sizes(a(c,3),c->gpr[4],h,d):invalid;
    if(!e)vm_write64(out,h); rc(c,e);
}
void stream_sizes(ppu_context* c) {
    uint64_t h=0,d=0; uint32_t offset=a(c,5),size=a(c,6);
    uint32_t e=(!offset || range(offset,8)) && (!size || range(size,8)) ? sizes(a(c,3),c->gpr[4],h,d):invalid;
    if(!e){if(offset)vm_write64(offset,h);if(size)vm_write64(size,d);} rc(c,e);
}
void initialize(ppu_context* c) {
    uint32_t self=a(c,3),base=a(c,4); uint64_t h=0,d=0;
    {std::lock_guard<std::mutex> lock(readerLock);readers.erase(self);}
    uint32_t e=range(self,128)?sizes(base,c->gpr[5],h,d):invalid;
    if(!e && (vm_read8(base+0x6f)!=1 || vm_read8(base+0x81)!=1))e=badHeader;
    uint32_t count=e?0:vm_read8(base+0x87);
    if(!e && (!count || 0x88+uint64_t(count)*48>h))e=badHeader;
    if(!e){std::lock_guard<std::mutex> lock(readerLock);readers[self]={base,count,0};}
    std::fprintf(stderr,"[rr7-pamf] initialize base=%08X header=%llu streams=%u rc=%08X\n",base,(unsigned long long)h,count,e);
    rc(c,e);
}
void timestamp(ppu_context* c,uint32_t offset) {
    Reader r;uint32_t out=a(c,4);
    if(!get(a(c,3),r)||!range(out,8)){rc(c,invalid);return;}
    vm_write32(out,vm_read16(r.base+offset));vm_write32(out+4,vm_read32(r.base+offset+2));rc(c,0);
}
void start(ppu_context* c){timestamp(c,0x56);}
void end(ppu_context* c){timestamp(c,0x5c);}
void count(ppu_context* c){
    Reader r;if(!get(a(c,3),r)){rc(c,invalid);return;}
    uint32_t n=0;for(uint32_t i=0;i<r.count;i++)n+=matches(type(desc(r,i)),a(c,4));rc(c,n);
}
void select(ppu_context* c){
    Reader r;uint32_t self=a(c,3);if(!get(self,r)){rc(c,invalid);return;}
    uint32_t wanted=a(c,5),n=0;if(wanted>=r.count){rc(c,invalid);return;}
    for(uint32_t i=0;i<r.count;i++)if(matches(type(desc(r,i)),a(c,4))&&n++==wanted){
        std::lock_guard<std::mutex> lock(readerLock);readers[self].index=i;rc(c,i);return;}
    rc(c,noStream);
}
void type_channel(ppu_context* c){
    Reader r;if(!get(a(c,3),r)){rc(c,invalid);return;}
    uint32_t d=desc(r,r.index),t=a(c,4),ch=a(c,5);int st=type(d);
    if(st<0 || (t&&!range(t,1)) || (ch&&!range(ch,1))){rc(c,invalid);return;}
    if(t)vm_write8(t,uint8_t(st));if(ch)vm_write8(ch,vm_read8(d+(st<2?4:5))&15);rc(c,0);
}
void filter(ppu_context* c){
    uint32_t t=a(c,3),ch=a(c,4),out=a(c,5),major=0,minor=0;
    if(t>5 || ch>15 || !range(out,16)){rc(c,invalid);return;}
    if(t<2)major=0xe0|ch;
    else {major=0xbd;constexpr uint8_t privateId[]={0,0,0,0x40,0x30,0x20};minor=privateId[t]|ch;}
    vm_write32(out,major);vm_write32(out+4,minor);vm_write32(out+8,t==0);vm_write32(out+12,0);rc(c,0);
}
void info(ppu_context* c){
    Reader r;uint32_t out=a(c,4),size=a(c,5);
    if(!get(a(c,3),r)||!range(out,size)){rc(c,invalid);return;}
    uint32_t d=desc(r,r.index),v=d+16;int t=type(d);
    uint32_t required=t==0?32:t==1?24:t>=2&&t<=4?8:0;
    if(!required || size<required){rc(c,invalid);return;}
    for(uint32_t i=0;i<required;i++)vm_write8(out+i,0);
    if(t>=2){vm_write32(out,vm_read8(v+3)&15);vm_write8(out+4,vm_read8(v+2)&15);
      if(t==3)vm_write16(out+6,vm_read8(v+4)>>6);rc(c,0);return;}
    uint8_t flags=vm_read8(v+2),aspect=vm_read8(v+3);bool avc=t==0;
    vm_write8(out,avc?vm_read8(v):(vm_read8(v)==0x44?3:vm_read8(v)==0x48?1:255));
    if(avc)vm_write8(out+1,vm_read8(v+1));
    vm_write8(out+(avc?2:1),(flags>>7)&1);vm_write8(out+(avc?3:2),(flags>>6)&1);
    vm_write8(out+(avc?4:3),(flags&15)-(avc?1:0));vm_write8(out+(avc?5:4),aspect);
    vm_write16(out+6,aspect==255?vm_read16(v+4):0);vm_write16(out+8,aspect==255?vm_read16(v+6):0);
    vm_write16(out+10,vm_read8(v+9)*16);vm_write16(out+12,vm_read8(v+11)*16);
    if(avc){for(int i=0;i<4;i++)vm_write16(out+14+i*2,vm_read16(v+12+i*2));}
    else{vm_write16(out+14,vm_read16(v+12));vm_write16(out+16,vm_read16(v+14));}
    uint32_t signalOut=out+(avc?22:18);
    if(flags&0x40){uint8_t f=vm_read8(v+20);vm_write8(signalOut,f>>5);vm_write8(signalOut+1,(f>>4)&1);
      for(int i=0;i<3;i++)vm_write8(signalOut+2+i,vm_read8(v+21+i));}
    if(avc){uint8_t f=vm_read8(v+24);vm_write8(out+27,f>>7);vm_write8(out+28,(f>>6)&1);
      vm_write8(out+29,(f>>4)&3);vm_write8(out+30,f&3);vm_write8(out+31,vm_read8(v+25));}
    std::fprintf(stderr,"[rr7-pamf] stream=%u type=%d size=%ux%u\n",r.index,t,vm_read16(out+10),vm_read16(out+12));
    rc(c,0);
}
}
extern "C" void rr7_register_pamf_bridge(){
    ps3_hle_register_ctx(0xCA8181C1,"cellPamfGetHeaderSize",header_size);
    ps3_hle_register_ctx(0x44F5C9E3,"cellPamfGetStreamOffsetAndSize",stream_sizes);
    ps3_hle_register_ctx(0xB8436EE5,"cellPamfReaderInitialize",initialize);
    ps3_hle_register_ctx(0x4DE501B1,"cellPamfReaderGetPresentationStartTime",start);
    ps3_hle_register_ctx(0xF61609D6,"cellPamfReaderGetPresentationEndTime",end);
    ps3_hle_register_ctx(0xD0230671,"cellPamfReaderGetNumberOfSpecificStreams",count);
    ps3_hle_register_ctx(0x28B4E2C1,"cellPamfReaderSetStreamWithTypeAndIndex",select);
    ps3_hle_register_ctx(0x9AB20793,"cellPamfReaderGetStreamTypeAndChannel",type_channel);
    ps3_hle_register_ctx(0x01067E22,"cellPamfStreamTypeToEsFilterId",filter);
    ps3_hle_register_ctx(0x67FD273B,"cellPamfReaderGetStreamInfo",info);
}
