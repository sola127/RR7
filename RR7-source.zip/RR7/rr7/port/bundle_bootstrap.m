/* Finder entry configuration. The development ELF command remains unchanged. */
#import <AppKit/AppKit.h>
#include <sys/file.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
extern void ps3_host_quit(const char* reason);
extern void rr7_set_performance_overlay(int enabled);
static id s_rr7_delegate;
static int s_rr7_instance_fd=-1;
static NSString* s_rr7_data;
@interface RR7AppDelegate:NSObject<NSApplicationDelegate>
@end
@implementation RR7AppDelegate
- (NSApplicationTerminateReply)applicationShouldTerminate:(NSApplication*)app {
    (void)app;
    dispatch_async(dispatch_get_global_queue(QOS_CLASS_USER_INITIATED,0),^{ps3_host_quit("RR7 application quit");});
    return NSTerminateCancel;
}
- (void)showControls:(id)sender {
    (void)sender;NSAlert* a=[NSAlert new];a.messageText=@"RR7 操作";
    a.informativeText=@"Switch Pro：A 确认／加速，X 刹车，B 返回／后视，＋ 暂停，左摇杆转向。\n\n键盘：方向键转向，Z 确认／加速，B 刹车，X 返回／后视，回车暂停。";
    [a runModal];
}
- (void)showSaves:(id)sender {(void)sender;[NSWorkspace.sharedWorkspace openURL:[NSURL fileURLWithPath:[s_rr7_data stringByAppendingPathComponent:@"SaveData"]]];}
- (void)togglePerformance:(NSMenuItem*)item {
    BOOL enabled=item.state!=NSControlStateValueOn;
    [NSUserDefaults.standardUserDefaults setBool:enabled forKey:@"ShowPerformance"];
    item.state=enabled?NSControlStateValueOn:NSControlStateValueOff;
    rr7_set_performance_overlay(enabled);
}
@end
static void rr7_env(const char* name,NSString* value){setenv(name,value.fileSystemRepresentation,1);}
static int rr7_bundle_error(NSString* text,BOOL check){
    if(check){fprintf(stderr,"RR7 bundle validation failed: %s\n",text.UTF8String);return -1;}
    [NSApplication sharedApplication];NSAlert* a=[NSAlert new];a.messageText=@"RR7 无法启动";a.informativeText=text;[a runModal];return -1;
}
int rr7_prepare_bundle(int* argc,char*** argv){@autoreleasepool {
    NSBundle* bundle=NSBundle.mainBundle;
    if(![bundle.bundleIdentifier isEqualToString:@"local.sola.RR7"])return 0;
    BOOL check=NO;for(int i=1;i<*argc;i++)if(!strcmp((*argv)[i],"--verify-bundle"))check=YES;
    NSString* resources=bundle.resourcePath;
    NSString* frameworks=bundle.privateFrameworksPath;
    NSString* elf=[resources stringByAppendingPathComponent:@"EBOOT.ELF"];
    NSString* game=[resources stringByAppendingPathComponent:@"Game"];
    NSFileManager* fm=NSFileManager.defaultManager;
    for(NSString* path in @[elf,[game stringByAppendingPathComponent:@"PS3_GAME/USRDIR/RR7.DAT"],
                           [game stringByAppendingPathComponent:@"PS3_GAME/USRDIR/BGM.nub"],
                           [frameworks stringByAppendingPathComponent:@"libavcodec.62.dylib"],
                           [frameworks stringByAppendingPathComponent:@"libavutil.60.dylib"]])
        if(![fm isReadableFileAtPath:path])return rr7_bundle_error([NSString stringWithFormat:@"应用运行文件不完整：%@",path.lastPathComponent],check);
    NSURL* support=[[fm URLsForDirectory:NSApplicationSupportDirectory inDomains:NSUserDomainMask] firstObject];
    NSURL* cache=[[fm URLsForDirectory:NSCachesDirectory inDomains:NSUserDomainMask] firstObject];
    s_rr7_data=[[support URLByAppendingPathComponent:@"RR7" isDirectory:YES] path];
    NSString* caches=[[cache URLByAppendingPathComponent:@"RR7" isDirectory:YES] path];
    for(NSString* dir in @[s_rr7_data,[s_rr7_data stringByAppendingPathComponent:@"SaveData"],
                          [s_rr7_data stringByAppendingPathComponent:@"HDD0"],caches]){
        NSError* error=nil;if(![fm createDirectoryAtPath:dir withIntermediateDirectories:YES attributes:nil error:&error])
            return rr7_bundle_error([NSString stringWithFormat:@"无法建立用户数据目录：%@",error.localizedDescription],check);
    }
    /* Daily launches ignore development overrides inherited from a terminal. */
    NSDictionary* inherited=NSProcessInfo.processInfo.environment;
    NSArray* prefixes=@[@"PS3_",@"PS3RECOMP_",@"SPU_",@"GCM_",@"RSX_",@"RR7_",@"PAD_",@"AUDIO_"];
    for(NSString* key in inherited)for(NSString* prefix in prefixes)
        if([key hasPrefix:prefix]){unsetenv(key.UTF8String);break;}
    rr7_env("PS3_VFS_ROOT",game);
    rr7_env("PS3_HDD0_ROOT",[s_rr7_data stringByAppendingPathComponent:@"HDD0"]);
    rr7_env("PS3_HDD1_ROOT",caches);
    rr7_env("PS3_GAMEDATA_ROOT",[s_rr7_data stringByAppendingPathComponent:@"SaveData"]);
    rr7_env("PS3RECOMP_FFMPEG_AVCODEC",[frameworks stringByAppendingPathComponent:@"libavcodec.62.dylib"]);
    rr7_env("PS3RECOMP_FFMPEG_AVUTIL",[frameworks stringByAppendingPathComponent:@"libavutil.60.dylib"]);
    setenv("PS3_FONT_FILE","/System/Library/Fonts/Supplemental/Arial.ttf",1);
    const char* names[]={"PS3_METALFX","PS3_AA","SPU_FLOAT_RZ","PS3_PPU_MIN_STACK","PAD_KEYBOARD_SQUARE_KEY","RR7_RSX_HANDOFF","RR7_RSX_POLL_US","GCM_SEMA_ACQUIRE","GCM_FLIPCB_ONTICK","GCM_HANDLER_THREAD","PS3_VERBOSE","PS3_HLE_TRACE","PS3_TITLE"};
    const char* values[]={"1","smaa","1","0x20000","B","1","100","1","1","1","0","0","RR7"};
    for(unsigned i=0;i<sizeof(names)/sizeof(names[0]);i++)setenv(names[i],values[i],1);
    BOOL overlay=[NSUserDefaults.standardUserDefaults boolForKey:@"ShowPerformance"];
    setenv("PS3RECOMP_METAL_DEBUG_OVERLAY",overlay?"1":"0",1);
    if(chdir(resources.fileSystemRepresentation)!=0)return rr7_bundle_error(@"无法打开应用资源目录。",check);
    if(check){
        NSDictionary* report=@{@"app":bundle.bundlePath,@"resources":resources,@"saves":[s_rr7_data stringByAppendingPathComponent:@"SaveData"],@"cache":caches,@"internal":@[@1280,@720],@"output":@[@2560,@1440],@"debugCapture":@NO,@"overlay":@(overlay)};
        NSData* json=[NSJSONSerialization dataWithJSONObject:report options:NSJSONWritingPrettyPrinted error:nil];
        fwrite(json.bytes,1,json.length,stdout);fputc('\n',stdout);return 1;
    }
    NSString* lock=[s_rr7_data stringByAppendingPathComponent:@"session.lock"];
    s_rr7_instance_fd=open(lock.fileSystemRepresentation,O_RDWR|O_CREAT,0600);
    if(s_rr7_instance_fd<0)return rr7_bundle_error(@"无法建立游戏会话。",NO);
    if(flock(s_rr7_instance_fd,LOCK_EX|LOCK_NB)!=0){
        for(NSRunningApplication* app in [NSRunningApplication runningApplicationsWithBundleIdentifier:bundle.bundleIdentifier])
            if(app.processIdentifier!=getpid())[app activateWithOptions:0];
        return 1;
    }
    /* No per-frame capture or ever-growing diagnostic files in daily play. */
    freopen("/dev/null","w",stdout);freopen("/dev/null","w",stderr);
    static char* args[3];args[0]=strdup((*argv)[0]);args[1]=strdup(elf.fileSystemRepresentation);args[2]=NULL;
    *argc=2;*argv=args;
    [NSApplication sharedApplication];[NSApp setActivationPolicy:NSApplicationActivationPolicyRegular];
    s_rr7_delegate=[RR7AppDelegate new];NSApp.delegate=s_rr7_delegate;
    NSMenu* bar=[NSMenu new];NSMenuItem* appItem=[NSMenuItem new];[bar addItem:appItem];
    NSMenu* menu=[[NSMenu alloc] initWithTitle:@"RR7"];appItem.submenu=menu;
    [menu addItemWithTitle:@"关于 RR7" action:@selector(orderFrontStandardAboutPanel:) keyEquivalent:@""];
    [menu addItem:NSMenuItem.separatorItem];
    NSMenuItem* controls=[menu addItemWithTitle:@"操作说明" action:@selector(showControls:) keyEquivalent:@""];controls.target=s_rr7_delegate;
    NSMenuItem* saves=[menu addItemWithTitle:@"打开存档文件夹" action:@selector(showSaves:) keyEquivalent:@""];saves.target=s_rr7_delegate;
    NSMenuItem* perf=[menu addItemWithTitle:@"显示性能图表" action:@selector(togglePerformance:) keyEquivalent:@""];perf.target=s_rr7_delegate;perf.state=overlay?NSControlStateValueOn:NSControlStateValueOff;
    [menu addItem:NSMenuItem.separatorItem];[menu addItemWithTitle:@"隐藏 RR7" action:@selector(hide:) keyEquivalent:@"h"];
    [menu addItemWithTitle:@"退出 RR7" action:@selector(terminate:) keyEquivalent:@"q"];
    NSApp.mainMenu=bar;
    [NSApp activateIgnoringOtherApps:YES];
    return 0;
}}
