/* Guest-owned AU storage for the forthcoming cellDmux SDK bridge.
 * A successful GetAu acquires a slot; only ReleaseAu permits reuse.
 * Fixed-size slots avoid fragmentation and leave the descriptor stable. */
#pragma once
#include "pamf_pes.hpp"
#include <cstring>
#include <deque>
#include <mutex>
#include <optional>
namespace rr7 {
class GuestAuRing {
    enum State { Free,Queued,Acquired };
    uint8_t* memory;uint32_t base,slotSize;
    std::vector<State> states;
    std::deque<size_t> queued,acquired;
    size_t tail=0;
    mutable std::mutex mutex;
    void w32(uint32_t p,uint32_t v){for(int i=0;i<4;i++)memory[p+i]=uint8_t(v>>(24-i*8));}
    void w64(uint32_t p,uint64_t v){w32(p,uint32_t(v>>32));w32(p+4,uint32_t(v));}
public:
    GuestAuRing(uint8_t* vm,uint32_t address,uint32_t bytes,size_t slots=4):
        memory(vm),base(address),slotSize(slots?uint32_t(bytes/slots)&~127u:0){
        if(!vm||address<0x10000||uint64_t(address)+bytes>0x100000000ull||slots<2||slots>64||slotSize<256||(address&127))
            throw std::runtime_error("invalid guest AU ring resource");
        states.assign(slots,Free);
    }
    uint32_t maximum_payload() const{return slotSize-128;}
    bool push(const uint8_t* bytes,size_t size,int64_t pts,int64_t dts,uint64_t user,bool key){
        std::lock_guard<std::mutex> lock(mutex);
        if(!bytes||!size||size>maximum_payload()||states[tail]!=Free)return false;
        uint32_t at=base+uint32_t(tail)*slotSize,data=at+128;
        std::memcpy(memory+data,bytes,size);
        std::memset(memory+at,0,128);
        // CellDmuxAuInfo: three u32 fields, isRap byte, aligned u64 userData,
        // then two {upper,lower} codec timestamps. -1 means unavailable.
        w32(at,data);w32(at+4,uint32_t(size));w32(at+8,maximum_payload());memory[at+12]=key;
        w64(at+16,user);w64(at+24,uint64_t(pts));w64(at+32,uint64_t(dts));
        states[tail]=Queued;queued.push_back(tail);tail=(tail+1)%states.size();return true;
    }
    std::optional<uint32_t> peek() const{
        std::lock_guard<std::mutex> lock(mutex);
        if(queued.empty())return {};return base+uint32_t(queued.front())*slotSize;
    }
    std::optional<uint32_t> get(){
        std::lock_guard<std::mutex> lock(mutex);
        if(queued.empty())return {};size_t i=queued.front();queued.pop_front();
        states[i]=Acquired;acquired.push_back(i);return base+uint32_t(i)*slotSize;
    }
    bool release(){
        std::lock_guard<std::mutex> lock(mutex);
        if(acquired.empty())return false;
        states[acquired.front()]=Free;acquired.pop_front();return true;
    }
    void reset(){
        std::lock_guard<std::mutex> lock(mutex);
        std::fill(states.begin(),states.end(),Free);queued.clear();acquired.clear();tail=0;
    }
};
}
