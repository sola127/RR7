/* Streaming MPEG-2 program-stream packet extraction for a PAMF data area.
 * Accepts arbitrary input chunk boundaries. Does not pretend PES packets
 * are video frames: the codec parser must assemble actual access units. */
#pragma once
#include <cstdint>
#include <cstddef>
#include <vector>
#include <functional>
#include <stdexcept>
namespace rr7 {
struct PesPayload {
    uint8_t stream;
    int64_t pts=-1,dts=-1;
    const uint8_t* data;
    size_t size;
};
class PamfPes {
    std::vector<uint8_t> pending;
    size_t packets=0;
    bool ended=false;
    static uint16_t u16(const uint8_t* p){return uint16_t(p[0])<<8|p[1];}
    static bool prefix(const uint8_t* p){return !p[0]&&!p[1]&&p[2]==1;}
    static int64_t timestamp(const uint8_t* p,uint8_t kind){
        if((p[0]>>4)!=kind || !(p[0]&1) || !(p[2]&1) || !(p[4]&1))
            throw std::runtime_error("invalid PES timestamp marker");
        return (int64_t((p[0]>>1)&7)<<30)|(int64_t(u16(p+1)>>1)<<15)|(u16(p+3)>>1);
    }
public:
    using Emit=std::function<void(const PesPayload&)>;
    void reset(){pending.clear();packets=0;ended=false;}
    size_t packet_count() const{return packets;}
    bool program_end() const{return ended;}
    // Callback byte storage is valid only until feed returns.
    void feed(const uint8_t* bytes,size_t size,const Emit& emit,bool eof=false){
        if(size>1024*1024 || pending.size()+size>2*1024*1024)
            throw std::runtime_error("PES input buffer limit exceeded");
        if(size)pending.insert(pending.end(),bytes,bytes+size);
        size_t pos=0;
        while(pending.size()-pos>=4){
            const uint8_t* p=pending.data()+pos;size_t have=pending.size()-pos;
            if(!prefix(p)){
                // Disc padding is zero/0xff. Other bytes at packet boundaries
                // indicate a bad input offset or damaged container.
                if(*p && *p!=0xff)throw std::runtime_error("invalid PS packet prefix");
                pos++;continue;
            }
            uint8_t id=p[3];size_t total=0;
            if(id==0xb9){ended=true;pos+=4;continue;}
            if(id==0xba){
                if(have<14)break;
                if((p[4]&0xc0)!=0x40)throw std::runtime_error("unsupported pack header");
                total=14+(p[13]&7);
            } else {
                if(have<6)break;total=6+u16(p+4);
                if(total==6 && id>=0xe0 && id<=0xef){
                    // A zero-length video PES ends at the next PS packet,
                    // not at MPEG elementary sequence/picture start codes.
                    total=0;for(size_t i=6;i+4<=have;i++)if(prefix(p+i)&&p[i+3]>=0xb9){total=i;break;}
                    if(!total){if(eof)total=have;else break;}
                }
            }
            if(have<total)break;
            if((id>=0xc0 && id<=0xef)||id==0xbd){
                if(total<9 || (p[6]&0xc0)!=0x80)throw std::runtime_error("unsupported PES header");
                size_t data=9+p[8];uint8_t flags=p[7]>>6;
                if(data>total || flags==1 || (flags==2&&p[8]<5) || (flags==3&&p[8]<10))
                    throw std::runtime_error("invalid PES optional header size");
                PesPayload packet{id,-1,-1,p+data,total-data};
                if(flags>=2){packet.pts=timestamp(p+9,flags);packet.dts=packet.pts;}
                if(flags==3)packet.dts=timestamp(p+14,1);
                emit(packet);packets++;
            } else if(id<0xb9){throw std::runtime_error("elementary start code outside PES");}
            pos+=total;
        }
        pending.erase(pending.begin(),pending.begin()+pos);
        if(eof){
            for(uint8_t b:pending)if(b && b!=0xff)throw std::runtime_error("truncated PS packet at EOF");
            pending.clear();
        }
    }
};
}
