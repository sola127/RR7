/* Native PAMF -> owned MPEG2 access units. Guest API wrappers can queue these
 * without retaining a pointer into the input read buffer or FFmpeg parser. */
#pragma once
#include "pamf_pes.hpp"
extern "C" {
#include <libavcodec/avcodec.h>
}
#include <memory>
namespace rr7 {
struct VideoAu {
    std::vector<uint8_t> bytes;
    int64_t pts=-1,dts=-1;
    bool key=false;
};
class PamfVideo {
    PamfPes ps;
    AVCodecParserContext* parser=nullptr;
    AVCodecContext* codec=nullptr;
    int64_t position=0;
    bool finished=false;
    void open(){
        parser=av_parser_init(AV_CODEC_ID_MPEG2VIDEO);
        codec=avcodec_alloc_context3(nullptr);
        if(!parser||!codec){close();throw std::runtime_error("native MPEG2 parser unavailable");}
    }
    void close(){if(parser)av_parser_close(parser);parser=nullptr;avcodec_free_context(&codec);}
public:
    using Emit=std::function<void(VideoAu)>;
    PamfVideo(){open();}
    ~PamfVideo(){close();}
    PamfVideo(const PamfVideo&)=delete;
    PamfVideo& operator=(const PamfVideo&)=delete;
    bool ended() const{return finished;}
    void reset(){close();ps.reset();position=0;finished=false;open();}
    void feed(const uint8_t* bytes,size_t size,const Emit& emit,bool eof=false,const PamfPes::Emit& other={}){
        if(finished){
            if(!size&&eof)return;
            if(size&&std::all_of(bytes,bytes+size,[](uint8_t b){return b==0||b==255;}))return;
            throw std::runtime_error("PAMF sequence already ended");
        }
        auto output=[&](uint8_t* data,int count){
            if(count<0 || count>4*1024*1024)throw std::runtime_error("invalid MPEG2 access unit size");
            if(!count)return;
            VideoAu au;au.bytes.assign(data,data+count);
            au.pts=parser->pts==AV_NOPTS_VALUE?-1:parser->pts;
            au.dts=parser->dts==AV_NOPTS_VALUE?-1:parser->dts;
            au.key=parser->key_frame==1 || (parser->key_frame<0 && parser->pict_type==AV_PICTURE_TYPE_I);
            emit(std::move(au));
        };
        auto packet=[&](const PesPayload& p){
            if(p.stream!=0xe0){if(other)other(p);return;}
            std::vector<uint8_t> padded(p.size+AV_INPUT_BUFFER_PADDING_SIZE,0);
            std::copy(p.data,p.data+p.size,padded.begin());size_t off=0;
            int64_t pts=p.pts<0?AV_NOPTS_VALUE:p.pts,dts=p.dts<0?AV_NOPTS_VALUE:p.dts;
            while(off<p.size){
                uint8_t* data=nullptr;int count=0;
                int used=av_parser_parse2(parser,codec,&data,&count,padded.data()+off,int(p.size-off),pts,dts,position+off);
                if(used<0 || (!used&&!count))throw std::runtime_error("MPEG2 parser made no progress");
                off+=used;pts=dts=AV_NOPTS_VALUE;output(data,count);
            }
            position+=p.size;
        };
        ps.feed(bytes,size,packet,eof);
        if(eof||ps.program_end()){uint8_t* data=nullptr;int count=0;
            if(av_parser_parse2(parser,codec,&data,&count,nullptr,0,AV_NOPTS_VALUE,AV_NOPTS_VALUE,position)<0)
                throw std::runtime_error("MPEG2 parser flush failed");
            output(data,count);finished=true;
        }
    }
};
}
