/*
 * ps3recomp game project -- game-specific hooks and overrides.
 *
 * main.cpp is the runner and is game-agnostic. This file is where a port puts
 * everything that is not: the PRX loading hook it must answer, overrides for
 * firmware functions the HLE library gets wrong for this title, and patches
 * over recompiled code.
 *
 * It starts out as the empty version of all of that, which is what a game with
 * no lifted PRX and no overrides needs.
 */

#include <cstdio>
#include <cstring>

#include "ps3emu/ps3types.h"
#include "ps3emu/error_codes.h"
#include "../../ps3recomp/libs/codec/cellAtrac.h"
extern "C" void ps3_hle_register(uint32_t,const char*,void*);

/* ---------------------------------------------------------------------------
 * PRX loading
 *
 * main.cpp calls this once, after the lifted function table is registered and
 * vm_base is live, before the game runs. A title that lifts a real system PRX
 * -- libsre, which is cellSpurs and cellSync -- loads its image into guest RAM
 * here and registers its exports. Most ports never need to: the HLE library
 * answers those modules instead.
 * -----------------------------------------------------------------------*/

extern "C" void rr7_register_font_bridge(void);
extern "C" void rr7_register_pamf_bridge(void);
extern "C" void rr7_register_dmux_bridge(void);
extern "C" void rr7_register_vdec_bridge(void);
extern "C" void rr7_register_adec_bridge(void);
extern "C" void ps3_load_prx_modules(void)
{
    rr7_register_font_bridge();
    rr7_register_pamf_bridge();
    rr7_register_dmux_bridge();
    rr7_register_vdec_bridge();
    rr7_register_adec_bridge();
    ps3_hle_register(0x2BFFF084,"cellAtracGetStreamDataInfo",(void*)cellAtracGetStreamDataInfo);
    ps3_hle_register(0x46CFC013,"cellAtracAddStreamData",(void*)cellAtracAddStreamData);
    ps3_hle_register(0x99EFE171,"cellAtracIsSecondBufferNeeded",(void*)cellAtracIsSecondBufferNeeded);
    ps3_hle_register(0xBE07F05E,"cellAtracGetSecondBufferInfo",(void*)cellAtracGetSecondBufferInfo);
    ps3_hle_register(0x06DDB53E,"cellAtracSetSecondBuffer",(void*)cellAtracSetSecondBuffer);
    ps3_hle_register(0xB5C11938,"cellAtracGetInternalErrorInfo",(void*)cellAtracGetInternalErrorInfo);
}

