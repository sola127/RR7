/* RR7 ATRAC3plus decoder: real native PCM, guest-owned output, serial SDK
 * callbacks. A callback can queue another AU without recursive decoding. */
#include "ppu_recomp.h"
#include "ps3emu/guest_call.h"
extern "C" {
#include <libavcodec/avcodec.h>
}
#include <array>
#include <atomic>
#include <condition_variable>
#include <deque>
#include <memory>
#include <mutex>
#include <thread>
#include <unordered_map>
#include <cstdio>
#include <vector>
#include <stdexcept>
extern "C" void ps3_hle_register_ctx(uint32_t,const char*,void(*)(ppu_context*));
namespace {
constexpr uint32_t Fatal=0x80610001,Seq=0x80610002,Arg=0x80610003,Busy=0x80610004,Empty=0x80610005;
constexpr uint32_t WorkBytes=0x40000;
uint32_t a(ppu_context*c,int r){return uint32_t(c->gpr[r]);}
void result(ppu_context*c,uint32_t r){c->gpr[3]=uint64_t(int64_t(int32_t(r)));}
bool range(uint32_t p,uint64_t n){return p>=0x10000&&uint64_t(p)+n<=0x100000000ull;}
struct Job{uint32_t info;std::array<uint8_t,24> metadata;std::vector<uint8_t> bytes;uint64_t generation;bool end=false;};
struct State{
    uint32_t handle,callback,arg,item,bsi,pcm;
    std::mutex lock;std::condition_variable cv;std::deque<Job> jobs;std::thread worker;
    std::atomic<bool> stop{false};bool started=false,hasPcm=false;uint32_t pcmBytes=0;
    uint64_t generation=0;
    uint64_t decoded=0,consumed=0;
};
std::mutex objects;std::unordered_map<uint32_t,std::shared_ptr<State>> states;
std::shared_ptr<State> state(uint32_t h){std::lock_guard<std::mutex>l(objects);auto i=states.find(h);return i==states.end()?nullptr:i->second;}
void notify(const std::shared_ptr<State>&s,uint32_t kind,int32_t data){
    if(!s->stop&&g_ps3_guest_caller)g_ps3_guest_caller(s->callback,s->handle,kind,uint64_t(int64_t(data)),s->arg,0,0,0,0);
}
void run(std::shared_ptr<State>s){
    AVCodecContext* ctx=nullptr;AVPacket* packet=av_packet_alloc();AVFrame* frame=av_frame_alloc();
    uint64_t generation=UINT64_MAX;
    try{
        if(!packet||!frame)throw std::runtime_error("native ATRAC allocation failed");
        while(!s->stop){
            Job job;
            {std::unique_lock<std::mutex>l(s->lock);s->cv.wait(l,[&]{return s->stop||(!s->hasPcm&&!s->jobs.empty());});
             if(s->stop)break;job=std::move(s->jobs.front());s->jobs.pop_front();}
            if(job.end){notify(s,3,0);continue;}
            const auto& b=job.bytes;
            if(b.size()<8||b[0]!=0x0f||b[1]!=0xd0)throw std::runtime_error("ATRAC AU missing transport header");
            const unsigned rates[]={32000,44100,48000,0,0,0,0,0},channels[]={0,1,2,3,4,6,7,8};
            unsigned hz=rates[b[2]>>5],ch=channels[(b[2]>>2)&7];
            const size_t payload=(((size_t(b[2])&3)<<8)|b[3])*8+8;
            if(!hz||!ch||b.size()!=payload+8)throw std::runtime_error("invalid ATRAC AU size/configuration");
            if(!ctx||generation!=job.generation){
                avcodec_free_context(&ctx);const AVCodec* decoder=avcodec_find_decoder(AV_CODEC_ID_ATRAC3P);
                if(!decoder)throw std::runtime_error("native ATRAC3plus decoder unavailable");
                ctx=avcodec_alloc_context3(decoder);if(!ctx)throw std::runtime_error("native ATRAC context allocation failed");
                ctx->block_align=int(payload);ctx->sample_rate=int(hz);av_channel_layout_default(&ctx->ch_layout,int(ch));
                if(avcodec_open2(ctx,decoder,nullptr)<0)throw std::runtime_error("native ATRAC decoder open failed");
                generation=job.generation;
            }
            if(av_new_packet(packet,int(payload))<0)throw std::runtime_error("native ATRAC packet allocation failed");
            memcpy(packet->data,b.data()+8,payload);
            int rc=avcodec_send_packet(ctx,packet);av_packet_unref(packet);
            if(rc<0||avcodec_receive_frame(ctx,frame)<0)throw std::runtime_error("native ATRAC frame decode failed");
            if(frame->format!=AV_SAMPLE_FMT_FLTP||frame->ch_layout.nb_channels!=int(ch)||frame->nb_samples!=2048)
                throw std::runtime_error("unexpected ATRAC PCM format");
            {
                std::lock_guard<std::mutex>l(s->lock);
                if(s->stop||s->generation!=job.generation){av_frame_unref(frame);continue;}
                s->pcmBytes=uint32_t(frame->nb_samples)*ch*4;
                // The guest's 5.1 ATRAC output is L,C,R,Ls,Rs,LFE. FFmpeg's
                // planes are L,R,C,LFE,Ls,Rs. RR7 itself converts the former
                // to its mixer order; supplying WAVE order swaps channels twice.
                static constexpr unsigned atrac51[]={0,2,1,4,5,3};
                for(unsigned i=0;i<unsigned(frame->nb_samples);i++)for(unsigned c=0;c<ch;c++){
                    const unsigned plane=ch==6?atrac51[c]:c;
                    uint32_t bits;memcpy(&bits,(float*)frame->extended_data[plane]+i,4);vm_write32(s->pcm+(i*ch+c)*4,bits);
                }
                for(unsigned i=0;i<64;i++)vm_write8(s->item+i,0);
                vm_write32(s->item,s->handle);vm_write32(s->item+8,s->pcm);vm_write32(s->item+12,s->pcmBytes);
                vm_write32(s->item+16,s->bsi);memcpy(vm_base+s->item+24,job.metadata.data(),24);
                for(unsigned i=0;i<64;i++)vm_write8(s->bsi+i,0);
                // CellAdecAtracXInfo has three words, not a PCM description.
                vm_write32(s->bsi,hz);vm_write32(s->bsi+4,(b[2]>>2)&7);vm_write32(s->bsi+8,uint32_t(payload));
                s->hasPcm=true;
                if(++s->decoded<=2 || s->decoded%300==0)
                    std::fprintf(stderr,"[rr7-adec] PCM ready handle=%08X frames=%llu channels=%u bytes=%u\n",s->handle,(unsigned long long)s->decoded,ch,s->pcmBytes);
            }
            av_frame_unref(frame);
            notify(s,0,int32_t(job.info));notify(s,1,0);
        }
    }catch(const std::exception&e){std::fprintf(stderr,"[rr7-adec] %s\n",e.what());notify(s,2,int32_t(Fatal));s->stop=true;}
    avcodec_free_context(&ctx);av_packet_free(&packet);av_frame_free(&frame);
}
void query(ppu_context*c){uint32_t out=a(c,4);if(!range(a(c,3),4)||vm_read32(a(c,3))!=3||!range(out,12)){result(c,Arg);return;}
    vm_write32(out,WorkBytes);vm_write32(out+4,0x260000);vm_write32(out+8,0x10000);result(c,0);}
void open(ppu_context*c){uint32_t type=a(c,3),res=a(c,4),cb=a(c,5),out=a(c,6);
    if(!range(type,4)||vm_read32(type)!=3||!range(res,20)||!range(cb,8)||!range(out,4)||!vm_read32(cb)){result(c,Arg);return;}
    uint32_t size=vm_read32(res),base=vm_read32(res+4);if(size<WorkBytes||!range(base,size)){result(c,Arg);return;}
    auto s=std::make_shared<State>();s->handle=base+0x100;s->callback=vm_read32(cb);s->arg=vm_read32(cb+4);
    s->item=base+0x200;s->bsi=base+0x240;s->pcm=base+0x1000;
    {std::lock_guard<std::mutex>l(objects);if(states.count(s->handle)){result(c,Busy);return;}states[s->handle]=s;}
    try{s->worker=std::thread(run,s);}catch(...){std::lock_guard<std::mutex>l(objects);states.erase(s->handle);result(c,Fatal);return;}
    vm_write32(out,s->handle);std::fprintf(stderr,"[rr7-adec] ATRAC3plus handle=%08X callback=%08X item=%08X bsi=%08X\n",s->handle,s->callback,s->item,s->bsi);result(c,0);
}
void close(ppu_context*c){auto s=state(a(c,3));if(!s){result(c,Arg);return;}
    s->stop=true;s->cv.notify_all();if(s->worker.joinable()){if(s->worker.get_id()==std::this_thread::get_id())s->worker.detach();else s->worker.join();}
    {std::lock_guard<std::mutex>l(objects);states.erase(s->handle);}result(c,0);}
void start(ppu_context*c){auto s=state(a(c,3));if(!s){result(c,Arg);return;}
    if(a(c,4)&&range(a(c,4),26))
        std::fprintf(stderr,"[rr7-adec] StartSeq rate=%u config=%u outputChannels=%u bytes=%u word=%02X downmix=%u transport=%u\n",
            vm_read32(a(c,4)),vm_read32(a(c,4)+4),vm_read32(a(c,4)+8),vm_read32(a(c,4)+12),
            vm_read32(a(c,4)+20),vm_read8(a(c,4)+24),vm_read8(a(c,4)+25));
    {std::lock_guard<std::mutex>l(s->lock);s->generation++;s->jobs.clear();s->hasPcm=false;s->started=true;}
    s->cv.notify_all();result(c,0);}
void end(ppu_context*c){auto s=state(a(c,3));if(!s){result(c,Arg);return;}
    {std::lock_guard<std::mutex>l(s->lock);if(!s->started){result(c,Seq);return;}s->started=false;Job j{};j.end=true;j.generation=s->generation;s->jobs.push_back(std::move(j));}
    s->cv.notify_all();result(c,0);}
void decode(ppu_context*c){auto s=state(a(c,3));uint32_t info=a(c,4);if(!s||!range(info,24)){result(c,Arg);return;}
    uint32_t at=vm_read32(info),size=vm_read32(info+4);if(size<8||size>16384||!range(at,size)){result(c,Arg);return;}
    {std::lock_guard<std::mutex>l(s->lock);if(!s->started||s->stop){result(c,Seq);return;}if(s->jobs.size()>=64){result(c,Busy);return;}
     Job j;j.info=info;j.generation=s->generation;memcpy(j.metadata.data(),vm_base+info,24);j.bytes.assign(vm_base+at,vm_base+at+size);s->jobs.push_back(std::move(j));}
    s->cv.notify_all();result(c,0);}
void get_item(ppu_context*c){auto s=state(a(c,3));uint32_t out=a(c,4);if(!s||!range(out,4)){result(c,Arg);return;}
    std::lock_guard<std::mutex>l(s->lock);if(!s->hasPcm){result(c,Empty);return;}vm_write32(out,s->item);result(c,0);}
void get_pcm(ppu_context*c){auto s=state(a(c,3));uint32_t out=a(c,4);if(!s){result(c,Arg);return;}
    {std::lock_guard<std::mutex>l(s->lock);if(!s->hasPcm){result(c,Empty);return;}if(out&&!range(out,s->pcmBytes)){result(c,Arg);return;}
     if(out)memcpy(vm_base+out,vm_base+s->pcm,s->pcmBytes);s->hasPcm=false;
     if(++s->consumed<=2 || s->consumed%300==0)
         std::fprintf(stderr,"[rr7-adec] PCM consumed handle=%08X frames=%llu out=%08X\n",s->handle,(unsigned long long)s->consumed,out);}
    s->cv.notify_all();result(c,0);}
}
extern "C" void rr7_register_adec_bridge(){
    ps3_hle_register_ctx(0x7E4A4A49,"cellAdecQueryAttr",query);ps3_hle_register_ctx(0xD00A6988,"cellAdecOpen",open);
    ps3_hle_register_ctx(0x847D2380,"cellAdecClose",close);ps3_hle_register_ctx(0x487B613E,"cellAdecStartSeq",start);
    ps3_hle_register_ctx(0xE2EA549B,"cellAdecEndSeq",end);ps3_hle_register_ctx(0x1529E506,"cellAdecDecodeAu",decode);
    ps3_hle_register_ctx(0x97FF2AF1,"cellAdecGetPcm",get_pcm);ps3_hle_register_ctx(0xBD75F78B,"cellAdecGetPcmItem",get_item);
}
