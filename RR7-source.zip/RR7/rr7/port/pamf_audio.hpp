/* ATRAC3plus access units in PAMF private-stream 1. The four-byte PES
 * substream header identifies the first frame and is not elementary data. */
#pragma once
#include "pamf_video.hpp"
#include <deque>
namespace rr7 {
class PamfAudio {
    std::vector<uint8_t> bytes;
    struct Mark {uint64_t at;int64_t pts;};
    std::deque<Mark> marks;
    uint64_t consumed=0,received=0;
    int64_t nextPts=-1;
public:
    void reset(){bytes.clear();marks.clear();consumed=received=0;nextPts=-1;}
    void packet(const PesPayload& p,const PamfVideo::Emit& emit){
        if(p.stream!=0xbd)return;
        if(p.size<4)throw std::runtime_error("truncated PAMF audio private header");
        if(p.data[0]!=0)return; // ATRAC3plus channel 0, the track in RR7 intro.pam.
        const size_t first=size_t(p.data[2])<<8|p.data[3];
        if(p.pts>=0 && first<p.size-4)marks.push_back({received+first,p.pts});
        bytes.insert(bytes.end(),p.data+4,p.data+p.size);received+=p.size-4;
        size_t at=0;
        while(bytes.size()-at>=8){
            const uint8_t* h=bytes.data()+at;
            if(h[0]!=0x0f||h[1]!=0xd0)throw std::runtime_error("invalid ATRAC3plus AU sync");
            const size_t payload=(((size_t(h[2])&3)<<8)|h[3])*8+8,total=payload+8;
            if(bytes.size()-at<total)break;
            int64_t pts=nextPts;
            while(!marks.empty()&&marks.front().at<=consumed+at){
                if(marks.front().at==consumed+at)pts=marks.front().pts;
                marks.pop_front();
            }
            const unsigned rate[]={32000,44100,48000,0,0,0,0,0};unsigned hz=rate[h[2]>>5];
            if(!hz)throw std::runtime_error("unsupported ATRAC3plus sampling frequency");
            VideoAu au;au.bytes.assign(h,h+total);au.pts=pts;au.dts=pts;au.key=true;
            if(pts>=0)nextPts=pts+int64_t(2048)*90000/hz;
            emit(std::move(au));at+=total;
        }
        bytes.erase(bytes.begin(),bytes.begin()+at);consumed+=at;
        if(bytes.size()>16384)throw std::runtime_error("ATRAC3plus assembly buffer limit");
    }
    void finish() const{if(!bytes.empty())throw std::runtime_error("truncated ATRAC3plus AU at EOF");}
};
}
