/* Local preferences contain only host settings, never guest data. */
#import <AppKit/AppKit.h>
#import <Metal/Metal.h>
#include <SDL2/SDL.h>
#include "save_paths.m"
extern void rr7_set_performance_overlay(int enabled);
extern void rr7_pad_set_ui_active(int active);
static const unsigned rr7_masks[]={0x4000,0x8000,0x2000,0x1000,0x0400,0x0800,0x0100,0x0200,0x0008,0x0001,0x0010,0x0040,0x0080,0x0020};
static const int rr7_keys[]={6,11,7,1,12,13,18,19,36,48,126,125,123,124};
static const int rr7_buttons[]={0,2,1,3,9,10,100,101,6,4,11,12,13,14};
static NSString* rr7_binding_key(NSString* kind,unsigned mask){return [NSString stringWithFormat:@"%@_%04X",kind,mask];}
static NSInteger rr7_pref_int(NSString* key,NSInteger fallback){id value=[NSUserDefaults.standardUserDefaults objectForKey:key];return value?[value integerValue]:fallback;}
static void rr7_settings_apply_environment(void){
    NSUserDefaults* d=NSUserDefaults.standardUserDefaults;
    NSInteger output=rr7_pref_int(@"OutputHeight",1440);if(output!=720&&output!=1080&&output!=1440&&output!=2160)output=1440;
    CGFloat scale=NSScreen.mainScreen.backingScaleFactor?:2;
    NSString* size=[NSString stringWithFormat:@"%ux%u",(unsigned)(output*16/9/scale),(unsigned)(output/scale)];
    setenv("PS3RECOMP_METAL_WINDOW",size.UTF8String,1);
    setenv("PS3_METALFX_OUTPUT_WIDTH",[NSString stringWithFormat:@"%ld",(long)(output*16/9)].UTF8String,1);
    setenv("PS3_METALFX_OUTPUT_HEIGHT",[NSString stringWithFormat:@"%ld",(long)output].UTF8String,1);
    setenv("PS3_METALFX",rr7_pref_int(@"MetalFX",1)?"1":"0",1);
    NSString* aa=[d stringForKey:@"AntiAliasing"]?:@"smaa";
    if(![@[@"none",@"fxaa",@"smaa",@"msaa2",@"msaa4",@"msaa8"] containsObject:aa])aa=@"smaa";
    unsigned samples=[aa hasPrefix:@"msaa"]?[[aa substringFromIndex:4] intValue]:1;
    if(samples>1&&![MTLCreateSystemDefaultDevice() supportsTextureSampleCount:samples]){aa=@"smaa";samples=1;}
    setenv("PS3_MSAA_SAMPLES",[NSString stringWithFormat:@"%u",samples].UTF8String,1);
    setenv("PS3_AA",aa.UTF8String,1);
    double volume=rr7_pref_int(@"Muted",0)?0:rr7_pref_int(@"Volume",100)/100.0;
    setenv("PS3_MASTER_VOLUME",[NSString stringWithFormat:@"%.3f",fmax(0,fmin(1,volume))].UTF8String,1);
    NSString* guid=[d stringForKey:@"ControllerGUID"]?:@"";setenv("PAD_CONTROLLER_GUID",guid.UTF8String,1);
    for(unsigned i=0;i<14;i++){
        NSString* key=rr7_binding_key(@"PAD_KEY",rr7_masks[i]);
        setenv(key.UTF8String,[[NSString stringWithFormat:@"%ld",(long)rr7_pref_int(key,rr7_keys[i])] UTF8String],1);
        key=rr7_binding_key(@"PAD_BUTTON",rr7_masks[i]);
        setenv(key.UTF8String,[[NSString stringWithFormat:@"%ld",(long)rr7_pref_int(key,rr7_buttons[i])] UTF8String],1);
    }
}
static NSTextField* rr7_label(NSView* parent,NSString* text,NSRect rect){
    NSTextField* label=[NSTextField labelWithString:text];label.frame=rect;[parent addSubview:label];return label;
}
static NSPopUpButton* rr7_popup(NSView* parent,NSRect rect,NSArray<NSString*>* names,NSArray<NSNumber*>* tags,NSInteger selected){
    NSPopUpButton* p=[[NSPopUpButton alloc] initWithFrame:rect pullsDown:NO];[p addItemsWithTitles:names];
    for(NSUInteger i=0;i<tags.count;i++)p.itemArray[i].tag=tags[i].integerValue;
    [p selectItemWithTag:selected];[parent addSubview:p];return p;
}
@interface RR7SettingsController:NSWindowController<NSWindowDelegate> {
    NSPopUpButton *output,*aa,*device;
    NSButton *metalFX,*mute,*overlay;
    NSSlider* volume;
    NSTextField *volumeLabel,*status,*savePath;
    NSMutableArray<NSPopUpButton*> *keyboard,*controller;
}
- (void)refreshDevices:(id)sender;
@end
@implementation RR7SettingsController
- (instancetype)init{
    NSWindow* w=[[NSWindow alloc] initWithContentRect:NSMakeRect(0,0,690,650)
        styleMask:NSWindowStyleMaskTitled|NSWindowStyleMaskClosable backing:NSBackingStoreBuffered defer:NO];
    if(!(self=[super initWithWindow:w]))return nil;
    w.title=@"RR7 设置";w.delegate=self;w.releasedWhenClosed=NO;[w center];
    NSView* root=w.contentView;
    NSTextField* title=rr7_label(root,@"RR7 设置",NSMakeRect(26,600,620,28));title.font=[NSFont boldSystemFontOfSize:22];
    rr7_label(root,@"F1 / ⌘, 打开设置 · 图表立即生效，其他选项保存后重启生效。",NSMakeRect(26,571,630,22));
    NSTabView* tabs=[[NSTabView alloc] initWithFrame:NSMakeRect(20,112,650,445)];[root addSubview:tabs];
    NSView* graphics=[[NSView alloc] initWithFrame:NSMakeRect(0,0,620,400)];
    NSTabViewItem* item=[[NSTabViewItem alloc] initWithIdentifier:@"graphics"];item.label=@"画面";item.view=graphics;[tabs addTabViewItem:item];
    rr7_label(graphics,@"内部渲染",NSMakeRect(24,341,160,22));rr7_label(graphics,@"1280 × 720（固定）",NSMakeRect(215,341,350,22));
    rr7_label(graphics,@"输出渲染分辨率",NSMakeRect(24,283,160,22));
    output=rr7_popup(graphics,NSMakeRect(210,280,350,28),@[@"1280 × 720",@"1920 × 1080",@"2560 × 1440（默认）",@"3840 × 2160（4K）"],@[@720,@1080,@1440,@2160],rr7_pref_int(@"OutputHeight",1440));
    rr7_label(graphics,@"抗锯齿",NSMakeRect(24,225,160,22));
    NSArray* aaNames=@[@"关闭",@"FXAA",@"SMAA（默认）",@"MSAA 2×",@"MSAA 4×",@"MSAA 8×"];
    NSString* current=[NSUserDefaults.standardUserDefaults stringForKey:@"AntiAliasing"]?:@"smaa";
    NSInteger index=[@[@"none",@"fxaa",@"smaa",@"msaa2",@"msaa4",@"msaa8"] indexOfObject:current];if(index==NSNotFound)index=2;
    aa=rr7_popup(graphics,NSMakeRect(210,222,350,28),aaNames,@[@0,@1,@2,@3,@4,@5],index);
    aa.menu.autoenablesItems=NO;
    id<MTLDevice> gpu=MTLCreateSystemDefaultDevice();for(unsigned i=3;i<6;i++)if(![gpu supportsTextureSampleCount:(2u<<(i-3))])aa.itemArray[i].enabled=NO;
    if(!aa.selectedItem.enabled)[aa selectItemWithTag:2];
    metalFX=[NSButton checkboxWithTitle:@"启用 MetalFX Spatial 空间放大" target:nil action:NULL];metalFX.frame=NSMakeRect(210,164,370,28);metalFX.state=rr7_pref_int(@"MetalFX",1);[graphics addSubview:metalFX];
    overlay=[NSButton checkboxWithTitle:@"显示实时系统状态图表（GPU / CPU / 内存 / FPS）" target:self action:@selector(toggleOverlay:)];overlay.frame=NSMakeRect(24,117,575,28);overlay.state=rr7_pref_int(@"ShowPerformance",0);[graphics addSubview:overlay];
    rr7_label(graphics,@"MSAA 对几何边缘多重采样；更高倍数会增加 GPU 和内存开销。",NSMakeRect(24,84,585,22));
    NSTextField* note=rr7_label(graphics,@"启用 MetalFX 时按所选分辨率输出；关闭时跟随窗口像素尺寸。\n默认配置：720p → SMAA → MetalFX → 2K。",NSMakeRect(24,17,570,55));note.textColor=NSColor.secondaryLabelColor;
    NSView* sound=[[NSView alloc] initWithFrame:graphics.frame];item=[[NSTabViewItem alloc] initWithIdentifier:@"audio"];item.label=@"声音";item.view=sound;[tabs addTabViewItem:item];
    rr7_label(sound,@"总音量",NSMakeRect(24,320,150,24));
    volume=[NSSlider sliderWithValue:rr7_pref_int(@"Volume",100) minValue:0 maxValue:100 target:self action:@selector(volumeChanged:)];volume.frame=NSMakeRect(190,318,310,28);[sound addSubview:volume];
    volumeLabel=rr7_label(sound,@"",NSMakeRect(515,320,75,24));[self volumeChanged:nil];
    mute=[NSButton checkboxWithTitle:@"静音" target:nil action:NULL];mute.frame=NSMakeRect(190,253,200,28);mute.state=rr7_pref_int(@"Muted",0);[sound addSubview:mute];
    rr7_label(sound,@"声音输出：跟随 macOS 当前默认输出设备。\n音乐和音效已由游戏混合，总音量同时影响两者。\n音量与静音在重新打开游戏后生效。",NSMakeRect(24,95,570,100));
    NSView* input=[[NSView alloc] initWithFrame:graphics.frame];item=[[NSTabViewItem alloc] initWithIdentifier:@"input"];item.label=@"操作";item.view=input;[tabs addTabViewItem:item];
    rr7_label(input,@"游戏手柄",NSMakeRect(16,365,110,22));device=[[NSPopUpButton alloc] initWithFrame:NSMakeRect(125,361,370,28) pullsDown:NO];[input addSubview:device];
    NSButton* refresh=[NSButton buttonWithTitle:@"刷新" target:self action:@selector(refreshDevices:)];refresh.frame=NSMakeRect(510,361,80,28);[input addSubview:refresh];[self refreshDevices:nil];
    rr7_label(input,@"功能",NSMakeRect(19,328,160,22));rr7_label(input,@"键盘",NSMakeRect(205,328,160,22));rr7_label(input,@"手柄按钮（SDL 名称）",NSMakeRect(400,328,205,22));
    NSScrollView* scroll=[[NSScrollView alloc] initWithFrame:NSMakeRect(10,14,600,310)];scroll.hasVerticalScroller=YES;scroll.borderType=NSBezelBorder;[input addSubview:scroll];
    NSView* rows=[[NSView alloc] initWithFrame:NSMakeRect(0,0,575,14*36+12)];scroll.documentView=rows;
    keyboard=[NSMutableArray new];controller=[NSMutableArray new];
    NSArray* labels=@[@"× 确认 / 加速",@"□ 刹车",@"○ 返回 / 后视",@"△",@"L1",@"R1",@"L2",@"R2",@"START / 暂停",@"SELECT",@"方向上",@"方向下",@"方向左",@"方向右"];
    NSArray* keyNames=@[@"Z",@"X",@"B",@"S",@"Q",@"W",@"1",@"2",@"Return",@"Tab",@"↑",@"↓",@"←",@"→",@"Space",@"A",@"D",@"E",@"R",@"F",@"C",@"V"];
    NSArray* keyTags=@[@6,@7,@11,@1,@12,@13,@18,@19,@36,@48,@126,@125,@123,@124,@49,@0,@2,@14,@15,@3,@8,@9];
    NSArray* padNames=@[@"A",@"B",@"X",@"Y",@"Back / −",@"Start / ＋",@"左肩键",@"右肩键",@"左扳机",@"右扳机",@"十字键上",@"十字键下",@"十字键左",@"十字键右"];
    NSArray* padTags=@[@0,@1,@2,@3,@4,@6,@9,@10,@100,@101,@11,@12,@13,@14];
    for(unsigned i=0;i<14;i++){
        CGFloat y=rows.frame.size.height-42-i*36;rr7_label(rows,labels[i],NSMakeRect(8,y+3,170,22));
        NSPopUpButton* k=rr7_popup(rows,NSMakeRect(185,y,165,28),keyNames,keyTags,rr7_pref_int(rr7_binding_key(@"PAD_KEY",rr7_masks[i]),rr7_keys[i]));k.accessibilityLabel=[labels[i] stringByAppendingString:@" 键盘"];[keyboard addObject:k];
        NSPopUpButton* p=rr7_popup(rows,NSMakeRect(365,y,185,28),padNames,padTags,rr7_pref_int(rr7_binding_key(@"PAD_BUTTON",rr7_masks[i]),rr7_buttons[i]));p.accessibilityLabel=[labels[i] stringByAppendingString:@" 手柄"];[controller addObject:p];
    }
    [rows scrollPoint:NSMakePoint(0,rows.frame.size.height)];
    NSView* saves=[[NSView alloc] initWithFrame:graphics.frame];item=[[NSTabViewItem alloc] initWithIdentifier:@"saves"];item.label=@"存档";item.view=saves;[tabs addTabViewItem:item];
    rr7_label(saves,@"存档位置",NSMakeRect(24,338,570,25));
    savePath=rr7_label(saves,rr7_selected_save_root(),NSMakeRect(24,255,570,72));savePath.selectable=YES;savePath.lineBreakMode=NSLineBreakByCharWrapping;
    NSButton* choose=[NSButton buttonWithTitle:@"选择位置…" target:self action:@selector(chooseSaveLocation:)];choose.frame=NSMakeRect(24,195,145,32);[saves addSubview:choose];
    NSButton* open=[NSButton buttonWithTitle:@"打开文件夹" target:self action:@selector(openSaveLocation:)];open.frame=NSMakeRect(180,195,145,32);[saves addSubview:open];
    NSButton* defaultSave=[NSButton buttonWithTitle:@"使用默认位置" target:self action:@selector(defaultSaveLocation:)];defaultSave.frame=NSMakeRect(340,195,170,32);[saves addSubview:defaultSave];
    rr7_label(saves,@"选择父文件夹后，会建立“RR7 SaveData”目录。\n新位置下次启动生效：复制当前存档，原位置保留。\n若目标已有 RR7 存档，则使用目标存档，不覆盖进度。\n更改后请点击“保存设置”。",NSMakeRect(24,45,575,120));
    status=rr7_label(root,@"建议在比赛暂停后调整设置。",NSMakeRect(27,64,630,35));status.textColor=NSColor.secondaryLabelColor;
    NSButton* reset=[NSButton buttonWithTitle:@"恢复默认" target:self action:@selector(reset:)];reset.frame=NSMakeRect(25,20,120,32);[root addSubview:reset];
    NSButton* save=[NSButton buttonWithTitle:@"保存设置" target:self action:@selector(save:)];save.frame=NSMakeRect(535,20,130,32);[root addSubview:save];return self;
}
- (void)volumeChanged:(id)sender{(void)sender;volumeLabel.stringValue=[NSString stringWithFormat:@"%ld%%",(long)volume.integerValue];}
- (void)toggleOverlay:(id)sender{(void)sender;[NSUserDefaults.standardUserDefaults setBool:overlay.state==NSControlStateValueOn forKey:@"ShowPerformance"];rr7_set_performance_overlay(overlay.state==NSControlStateValueOn);}
- (void)chooseSaveLocation:(id)sender{
    (void)sender;NSOpenPanel* panel=[NSOpenPanel openPanel];panel.canChooseDirectories=YES;panel.canChooseFiles=NO;panel.canCreateDirectories=YES;panel.allowsMultipleSelection=NO;panel.prompt=@"选择位置";panel.message=@"选择父文件夹，将在其中建立 RR7 SaveData。";
    if([panel runModal]==NSModalResponseOK)savePath.stringValue=[panel.URL.path stringByAppendingPathComponent:@"RR7 SaveData"];
}
- (void)openSaveLocation:(id)sender{(void)sender;NSString* path=savePath.stringValue;if(![NSFileManager.defaultManager fileExistsAtPath:path])path=path.stringByDeletingLastPathComponent;[NSWorkspace.sharedWorkspace openURL:[NSURL fileURLWithPath:path]];}
- (void)defaultSaveLocation:(id)sender{(void)sender;savePath.stringValue=rr7_default_save_root();}
- (void)refreshDevices:(id)sender{
    (void)sender;NSString* selected=device.selectedItem.representedObject?:[NSUserDefaults.standardUserDefaults stringForKey:@"ControllerGUID"]?:@"";
    [device removeAllItems];[device addItemWithTitle:@"自动选择已连接手柄"];device.lastItem.representedObject=@"";
    [device addItemWithTitle:@"仅键盘"];device.lastItem.representedObject=@"none";
    if(SDL_WasInit(SDL_INIT_GAMECONTROLLER)){
        SDL_LockJoysticks();int n=SDL_NumJoysticks();
        for(int i=0;i<n;i++)if(SDL_IsGameController(i)){
            char guid[33];SDL_JoystickGetGUIDString(SDL_JoystickGetDeviceGUID(i),guid,sizeof guid);
            const char* name=SDL_GameControllerNameForIndex(i);
            [device addItemWithTitle:[NSString stringWithFormat:@"%s（%d）",name?:"Game controller",i+1]];device.lastItem.representedObject=@(guid);
        }
        SDL_UnlockJoysticks();
    }
    BOOL found=NO;for(NSMenuItem* item in device.itemArray)if([item.representedObject isEqual:selected]){[device selectItem:item];found=YES;break;}
    if(!found){[device addItemWithTitle:@"已选择的手柄（当前未连接）"];device.lastItem.representedObject=selected;[device selectItem:device.lastItem];}
}
- (void)save:(id)sender{
    (void)sender;NSMutableSet* keys=[NSMutableSet new];NSMutableSet* buttons=[NSMutableSet new];
    for(unsigned i=0;i<14;i++){
        NSNumber* k=@(keyboard[i].selectedTag);NSNumber* b=@(controller[i].selectedTag);
        if([keys containsObject:k]||[buttons containsObject:b]){status.stringValue=@"保存失败：同一输入不能分配给多个功能，请检查重复按键。";return;}
        [keys addObject:k];[buttons addObject:b];
    }
    NSString* destination=savePath.stringValue.stringByResolvingSymlinksInPath;
    NSString* source=([NSUserDefaults.standardUserDefaults stringForKey:@"LastSaveRoot"]?:rr7_default_save_root()).stringByResolvingSymlinksInPath;
    for(NSString* component in destination.pathComponents)if([component.pathExtension.lowercaseString isEqualToString:@"app"]){status.stringValue=@"保存失败：存档位置不能在应用程序包内。";return;}
    if(![destination isEqual:source]&&([destination hasPrefix:[source stringByAppendingString:@"/"]]||[source hasPrefix:[destination stringByAppendingString:@"/"]])){status.stringValue=@"保存失败：新旧存档目录不能互相包含。";return;}
    NSUserDefaults* d=NSUserDefaults.standardUserDefaults;
    [d setInteger:output.selectedTag forKey:@"OutputHeight"];[d setObject:@[@"none",@"fxaa",@"smaa",@"msaa2",@"msaa4",@"msaa8"][aa.selectedTag] forKey:@"AntiAliasing"];
    [d setInteger:metalFX.state forKey:@"MetalFX"];[d setInteger:volume.integerValue forKey:@"Volume"];[d setInteger:mute.state forKey:@"Muted"];
    [d setObject:device.selectedItem.representedObject?:@"" forKey:@"ControllerGUID"];
    [d setObject:savePath.stringValue forKey:@"SaveRoot"];
    for(unsigned i=0;i<14;i++){
        [d setInteger:keyboard[i].selectedTag forKey:rr7_binding_key(@"PAD_KEY",rr7_masks[i])];
        [d setInteger:controller[i].selectedTag forKey:rr7_binding_key(@"PAD_BUTTON",rr7_masks[i])];
    }
    status.stringValue=@"已保存。请正常退出 RR7，再重新打开，应用新的画面、声音和操作设置。";
}
- (void)reset:(id)sender{
    (void)sender;[output selectItemWithTag:1440];[aa selectItemWithTag:2];metalFX.state=1;mute.state=0;volume.integerValue=100;[self volumeChanged:nil];[device selectItemAtIndex:0];
    for(unsigned i=0;i<14;i++){[keyboard[i] selectItemWithTag:rr7_keys[i]];[controller[i] selectItemWithTag:rr7_buttons[i]];}
    savePath.stringValue=rr7_default_save_root();
    status.stringValue=@"已恢复默认选项；点击“保存设置”后，下次启动生效。";
}
- (void)windowDidBecomeKey:(NSNotification*)note{(void)note;rr7_pad_set_ui_active(1);}
- (void)windowDidResignKey:(NSNotification*)note{(void)note;rr7_pad_set_ui_active(0);}
- (void)windowWillClose:(NSNotification*)note{(void)note;rr7_pad_set_ui_active(0);}
@end
static RR7SettingsController* s_rr7_settings;
static void rr7_show_settings(void){if(!s_rr7_settings)s_rr7_settings=[RR7SettingsController new];[s_rr7_settings showWindow:nil];[s_rr7_settings.window makeKeyAndOrderFront:nil];}
