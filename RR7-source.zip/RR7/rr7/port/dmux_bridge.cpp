/* RR7 PAMF/MPEG2 cellDmux subset, backed by the native streaming parser.
 * The worker owns parser state; guest resource buffers own exposed AUs. */
#include "ppu_recomp.h"
#include "pamf_video.hpp"
#include "guest_au_ring.hpp"
#include "pamf_audio.hpp"
#include "ps3emu/guest_call.h"
#include <atomic>
#include <condition_variable>
#include <memory>
#include <thread>
#include <unordered_map>
#include <cstdio>
extern "C" void ps3_hle_register_ctx(uint32_t,const char*,void(*)(ppu_context*));
namespace {
constexpr uint32_t Arg=0x80610201,Seq=0x80610202,Busy=0x80610203,Empty=0x80610204,Fatal=0x80610205;
constexpr uint32_t DmuxBytes=0x10000,EsBytes=0x400100;
constexpr uint32_t AudioEsBytes=0x100100;
uint32_t a(ppu_context* c,int i){return uint32_t(c->gpr[i]);}
void result(ppu_context* c,uint32_t r){c->gpr[3]=uint64_t(int64_t(int32_t(r)));}
bool range(uint32_t p,uint64_t n){return p>=0x10000&&uint64_t(p)+n<=0x100000000ull;}
struct Dmux;
struct Es {
    uint32_t handle,cb,arg,message;
    bool audio=false;
    std::weak_ptr<Dmux> parent;
    std::unique_ptr<rr7::GuestAuRing> ring;
    std::atomic<bool> enabled{true};
    std::atomic<uint64_t> epoch{0};
    std::recursive_mutex callback;
    std::atomic<uint32_t> trace_notifications{0};
    uint32_t trace_phase=~0u;
};
struct Task {std::vector<uint8_t> bytes;bool discontinuity;uint64_t user,generation;};
struct Dmux {
    uint32_t handle,cb,arg,message;
    std::mutex lock;
    std::condition_variable cv;
    std::optional<Task> task;
    std::vector<std::shared_ptr<Es>> streams;
    std::atomic<bool> stop{false};
    std::atomic<uint64_t> generation{0};
    bool busy=false;
    std::thread worker;
};
std::mutex objects;
std::unordered_map<uint32_t,std::shared_ptr<Dmux>> demuxers;
std::unordered_map<uint32_t,std::shared_ptr<Es>> elementary;
std::shared_ptr<Dmux> dm(uint32_t h){std::lock_guard<std::mutex> l(objects);auto i=demuxers.find(h);return i==demuxers.end()?nullptr:i->second;}
std::shared_ptr<Es> es(uint32_t h){std::lock_guard<std::mutex> l(objects);auto i=elementary.find(h);return i==elementary.end()?nullptr:i->second;}
bool type(uint32_t p){return range(p,12)&&vm_read32(p)==1;}
bool filter(uint32_t p){return range(p,16)&&(vm_read32(p)==0xe0||vm_read32(p)==0xbd)&&vm_read32(p+4)==0&&vm_read32(p+8)==0;}
void notify(const std::shared_ptr<Dmux>& d,uint32_t kind,uint64_t data){
    if(d->stop||!g_ps3_guest_caller)return;
    if(getenv("RR7_MEDIA_TRACE"))fprintf(stderr,"[rr7-media] dmux notify handle=%08X type=%u data=%llX\n",d->handle,kind,(unsigned long long)data);
    vm_write32(d->message,kind);vm_write32(d->message+4,0);vm_write64(d->message+8,data);
    g_ps3_guest_caller(d->cb,d->handle,d->message,d->arg,0,0,0,0,0);
}
void notify_es(const std::shared_ptr<Dmux>& d,const std::shared_ptr<Es>& e,uint32_t kind,uint64_t epoch){
    std::lock_guard<std::recursive_mutex> l(e->callback);
    if(d->stop||!e->enabled||e->epoch!=epoch||!g_ps3_guest_caller)return;
    vm_write32(e->message,kind);vm_write32(e->message+4,0);vm_write64(e->message+8,0);
    if(getenv("RR7_MEDIA_TRACE")){
        const uint32_t phase=range(e->arg,0x1f4)?vm_read32(e->arg+0x1f0):~0u;
        if(e->trace_notifications++<24||phase!=e->trace_phase)
            fprintf(stderr,"[rr7-media] ES notify es=%08X cb=%08X arg=%08X phase=%u kind=%u queued=%u/%u\n",
                e->handle,e->cb,e->arg,phase,kind,range(e->arg,0x1c8)?vm_read32(e->arg+0x1bc):0,
                range(e->arg,0x1c8)?vm_read32(e->arg+0x1c4):0);
        e->trace_phase=phase;
    }
    g_ps3_guest_caller(e->cb,d->handle,e->handle,e->message,e->arg,0,0,0,0);
}
void run(std::shared_ptr<Dmux> d){
    try{
        rr7::PamfVideo video;
        rr7::PamfAudio audio;
        while(!d->stop){
            Task t;std::vector<std::shared_ptr<Es>> streams;
            {std::unique_lock<std::mutex> l(d->lock);d->cv.wait(l,[&]{return d->stop||d->task.has_value();});
                if(d->stop)break;t=std::move(*d->task);d->task.reset();streams=d->streams;}
            bool ended=false;
            try{
                if(t.discontinuity){video.reset();audio.reset();}
                auto emit=[&](rr7::VideoAu au,bool isAudio){
                    for(auto& e:streams){uint64_t epoch=e->epoch;
                        if(e->audio!=isAudio)continue;
                        if(au.bytes.size()>e->ring->maximum_payload())throw std::runtime_error("video AU exceeds ES resource slot");
                        while(!d->stop&&d->generation==t.generation&&e->enabled&&e->epoch==epoch){
                            bool pushed;
                            {std::lock_guard<std::recursive_mutex> l(e->callback);
                                pushed=e->enabled&&e->epoch==epoch&&e->ring->push(au.bytes.data(),au.bytes.size(),au.pts,au.dts,t.user,au.key);}
                            if(pushed){notify_es(d,e,0,epoch);break;}
                            std::unique_lock<std::mutex> l(d->lock);d->cv.wait_for(l,std::chrono::milliseconds(5));
                        }
                    }
                };
                auto emitVideo=[&](rr7::VideoAu au){emit(std::move(au),false);};
                auto emitAudio=[&](rr7::VideoAu au){emit(std::move(au),true);};
                video.feed(t.bytes.data(),t.bytes.size(),emitVideo,false,
                    [&](const rr7::PesPayload& p){audio.packet(p,emitAudio);});
                ended=video.ended();if(ended)audio.finish();
            }catch(const std::exception& e){
                std::fprintf(stderr,"[rr7-dmux] stream failure: %s\n",e.what());
                if(d->generation==t.generation)notify(d,1,Fatal);
                d->stop=true;
            }
            {std::lock_guard<std::mutex> l(d->lock);d->busy=false;}
            d->cv.notify_all();
            if(d->generation==t.generation){if(ended)notify(d,2,t.user);notify(d,0,t.user);}
        }
    }catch(const std::exception& e){std::fprintf(stderr,"[rr7-dmux] worker failure: %s\n",e.what());notify(d,1,Fatal);d->stop=true;}
}
void query(ppu_context* c){
    uint32_t out=a(c,4);
    std::fprintf(stderr,"[rr7-dmux] query type=%08X value=%08X out=%08X\n",a(c,3),range(a(c,3),4)?vm_read32(a(c,3)):0,out);
    if(!type(a(c,3))||!range(out,12)){result(c,Arg);return;}
    vm_write32(out,DmuxBytes);vm_write32(out+4,0x260000);vm_write32(out+8,0x10000);result(c,0);
}
void query_es(ppu_context* c){
    uint32_t out=a(c,6);
    std::fprintf(stderr,"[rr7-dmux] query_es type=%08X filter=%08X major=%08X supplemental=%08X out=%08X\n",a(c,3),a(c,4),range(a(c,4),16)?vm_read32(a(c,4)):0,range(a(c,4),16)?vm_read32(a(c,4)+8):0,out);
    if(!type(a(c,3))||!filter(a(c,4))||!range(out,4)){result(c,Arg);return;}
    vm_write32(out,vm_read32(a(c,4))==0xbd?AudioEsBytes:EsBytes);result(c,0);
}
void open(ppu_context* c){
    uint32_t resource=a(c,4),cb=a(c,5),out=a(c,6);
    std::fprintf(stderr,"[rr7-dmux] open args type=%08X resource=%08X cb=%08X out=%08X\n",a(c,3),resource,cb,out);
    if(!type(a(c,3))||!range(resource,24)||!range(cb,8)||!range(out,4)||!vm_read32(cb)){result(c,Arg);return;}
    uint32_t base=vm_read32(resource),size=vm_read32(resource+4);
    std::fprintf(stderr,"[rr7-dmux] resource base=%08X size=%08X\n",base,size);
    if(!range(base,size)||size<DmuxBytes){result(c,Arg);return;}
    auto d=std::make_shared<Dmux>();d->handle=base+0x100;d->message=base+0x80;d->cb=vm_read32(cb);d->arg=vm_read32(cb+4);
    {std::lock_guard<std::mutex> l(objects);if(demuxers.count(d->handle)){result(c,Busy);return;}demuxers[d->handle]=d;}
    try{d->worker=std::thread(run,d);}catch(...){std::lock_guard<std::mutex> l(objects);demuxers.erase(d->handle);result(c,Fatal);return;}
    vm_write32(out,d->handle);std::fprintf(stderr,"[rr7-dmux] open handle=%08X cb=%08X\n",d->handle,d->cb);result(c,0);
}
void enable(ppu_context* c){
    auto d=dm(a(c,3));uint32_t resource=a(c,5),cb=a(c,6),out=a(c,8);
    if(!d||!filter(a(c,4))||!range(resource,8)||!range(cb,8)||!range(out,4)||!vm_read32(cb)){result(c,Arg);return;}
    uint32_t base=vm_read32(resource),size=vm_read32(resource+4);
    const bool isAudio=vm_read32(a(c,4))==0xbd;
    if(!range(base,size)||size<(isAudio?AudioEsBytes:EsBytes)){result(c,Arg);return;}
    uint32_t aligned=(base+127u)&~127u;size-=aligned-base;base=aligned;
    auto e=std::make_shared<Es>();e->handle=base;e->cb=vm_read32(cb);e->arg=vm_read32(cb+4);e->message=base+64;e->parent=d;
    e->audio=isAudio;
    try{e->ring=std::make_unique<rr7::GuestAuRing>(vm_base,base,size);}catch(...){result(c,Arg);return;}
    {std::lock_guard<std::mutex> l(d->lock);
        if(d->stop){result(c,Seq);return;}
        std::lock_guard<std::mutex> o(objects);if(elementary.count(base)){result(c,Busy);return;}
        elementary[base]=e;d->streams.push_back(e);}
    vm_write32(out,base);std::fprintf(stderr,"[rr7-dmux] enable es=%08X cb=%08X\n",base,e->cb);result(c,0);
}
void set_stream(ppu_context* c){
    auto d=dm(a(c,3));uint32_t at=a(c,4),size=a(c,5);
    if(getenv("RR7_MEDIA_TRACE"))fprintf(stderr,"[rr7-media] SetStream handle=%08X at=%08X size=%u discontinuity=%u user=%llX\n",a(c,3),at,size,a(c,6),(unsigned long long)c->gpr[7]);
    if(!d||!size||size>1024*1024||!range(at,size)){result(c,Arg);return;}
    std::lock_guard<std::mutex> l(d->lock);
    if(d->stop){result(c,Seq);return;}if(d->busy){result(c,Busy);return;}
    Task t;t.discontinuity=a(c,6)!=0;t.user=c->gpr[7];t.generation=d->generation;
    // SetStream receives the mux data area. Reject accidental container headers.
    if(size>=4&&vm_read32(at)==0x50414d46){result(c,Arg);return;}
    t.bytes.assign(vm_base+at,vm_base+at+size);d->task=std::move(t);d->busy=true;
    d->cv.notify_all();result(c,0);
}
void get_au(ppu_context* c){
    auto e=es(a(c,3));uint32_t out=a(c,4),specific=a(c,5);
    if(!e||!e->enabled||(out&&!range(out,4))||(specific&&!range(specific,4))){result(c,Arg);return;}
    auto p=e->ring->get();if(!p){result(c,Empty);return;}
    if(getenv("RR7_MEDIA_TRACE")&&e->trace_notifications<32)
        fprintf(stderr,"[rr7-media] GetAu es=%08X item=%08X size=%u\n",e->handle,*p,vm_read32(*p+4));
    if(out)vm_write32(out,*p);if(specific)vm_write32(specific,0);result(c,0);
}
void release(ppu_context* c){
    auto e=es(a(c,3));if(!e||!e->enabled){result(c,Arg);return;}
    if(!e->ring->release()){result(c,Seq);return;}if(auto d=e->parent.lock())d->cv.notify_all();result(c,0);
}
void reset_es(ppu_context* c){
    auto e=es(a(c,3));if(!e||!e->enabled){result(c,Arg);return;}
    {std::lock_guard<std::recursive_mutex> l(e->callback);e->epoch++;e->ring->reset();}
    if(auto d=e->parent.lock())d->cv.notify_all();result(c,0);
}
void disable(ppu_context* c){
    auto e=es(a(c,3));if(!e){result(c,Arg);return;}e->enabled=false;
    {std::lock_guard<std::recursive_mutex> l(e->callback);e->epoch++;}
    {std::lock_guard<std::mutex> l(objects);elementary.erase(e->handle);}
    if(auto d=e->parent.lock()){
        std::lock_guard<std::mutex> l(d->lock);d->streams.erase(std::remove(d->streams.begin(),d->streams.end(),e),d->streams.end());d->cv.notify_all();}
    result(c,0);
}
void close(ppu_context* c){
    auto d=dm(a(c,3));if(!d){result(c,Arg);return;}d->stop=true;d->generation++;d->cv.notify_all();
    if(d->worker.joinable()){if(d->worker.get_id()==std::this_thread::get_id())d->worker.detach();else d->worker.join();}
    {std::lock_guard<std::mutex> l(d->lock);std::lock_guard<std::mutex> o(objects);
        for(auto& e:d->streams){e->enabled=false;elementary.erase(e->handle);}demuxers.erase(d->handle);}
    result(c,0);
}
}
extern "C" void rr7_register_dmux_bridge(){
    ps3_hle_register_ctx(0xA2D4189B,"cellDmuxQueryAttr",query);
    ps3_hle_register_ctx(0x02170D1A,"cellDmuxQueryEsAttr",query_es);
    ps3_hle_register_ctx(0x68492DE9,"cellDmuxOpen",open);
    ps3_hle_register_ctx(0x7B56DC3F,"cellDmuxEnableEs",enable);
    ps3_hle_register_ctx(0x04E7499F,"cellDmuxSetStream",set_stream);
    ps3_hle_register_ctx(0x42C716B5,"cellDmuxGetAu",get_au);
    ps3_hle_register_ctx(0x24EA6474,"cellDmuxReleaseAu",release);
    ps3_hle_register_ctx(0x21D424F0,"cellDmuxResetEs",reset_es);
    ps3_hle_register_ctx(0x05371C8D,"cellDmuxDisableEs",disable);
    ps3_hle_register_ctx(0x8C692521,"cellDmuxClose",close);
}
