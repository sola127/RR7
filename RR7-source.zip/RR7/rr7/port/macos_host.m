/* Let AppKit own the main event queue. Calling nextEvent from inside a
 * dispatch block serviced by a bare CFRunLoop triggers an assertion on
 * recent macOS releases. The renderer still dispatches window work here. */
#import <AppKit/AppKit.h>
#include <stdio.h>
void rr7_run_app_loop(volatile int* done) {
    @autoreleasepool {
        [NSApplication sharedApplication];
        /* A real-time game remains active without input. Keep App Nap and
         * latency coalescing from treating a stationary car/attract scene as
         * idle work; this token does not disable system or display sleep. */
        id<NSObject> activity=[NSProcessInfo.processInfo
            beginActivityWithOptions:(NSActivityUserInitiatedAllowingIdleSystemSleep |
                                      NSActivityLatencyCritical)
            reason:@"Ridge Racer 7 native audio and rendering"];
        fprintf(stderr,"[rr7-host] latency-critical gameplay activity %s\n",activity?"active":"unavailable");
        NSTimer* timer=[NSTimer scheduledTimerWithTimeInterval:0.05 repeats:YES block:^(NSTimer* t) {
            (void)t;
            if (__atomic_load_n(done,__ATOMIC_ACQUIRE)) {
                [NSApp stop:nil];
                NSEvent* wake=[NSEvent otherEventWithType:NSEventTypeApplicationDefined
                    location:NSZeroPoint modifierFlags:0 timestamp:0 windowNumber:0
                    context:nil subtype:0 data1:0 data2:0];
                [NSApp postEvent:wake atStart:NO];
            }
        }];
        [NSApp run];
        [timer invalidate];
        if(activity)[NSProcessInfo.processInfo endActivity:activity];
    }
}

#include "bundle_bootstrap.m"
