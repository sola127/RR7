#import "rsx_metalfx.h"
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char** argv) {
    @autoreleasepool {
        id<MTLDevice> dev = MTLCreateSystemDefaultDevice();
        assert(dev);
        RSXMetalFX* fx = [[RSXMetalFX alloc] initWithDevice:dev];
        assert(fx);
        id<MTLCommandQueue> queue = [dev newCommandQueue];
        const NSUInteger heights[]={720,1080,1440,2160};
        for(unsigned resolution=0;resolution<4;resolution++){
        NSUInteger dh=heights[resolution],dw=dh*16/9;
        for (unsigned pass = 0; pass < 3; pass++) {
            NSUInteger w = pass == 2 ? 640 : 1280, h = pass == 2 ? 360 : 720;
            NSUInteger pw = w + 128, ph = h + 48;
            MTLPixelFormat fmt = pass == 1 ? MTLPixelFormatBGRA8Unorm : MTLPixelFormatRGBA8Unorm;
            MTLTextureDescriptor* td = [MTLTextureDescriptor texture2DDescriptorWithPixelFormat:fmt
                width:pw height:ph mipmapped:NO];
            td.storageMode = MTLStorageModeShared;
            td.usage = MTLTextureUsageShaderRead;
            id<MTLTexture> input = [dev newTextureWithDescriptor:td];
            unsigned char* pixels = calloc(pw * ph, 4);
            for (NSUInteger y = 0; y < ph; y++) for (NSUInteger x = 0; x < pw; x++) {
                unsigned char* p = pixels + (y*pw+x)*4;
                /* Green padding must never enter the 2K image. */
                p[0] = x < w && y < h ? (x < w/2 ? 230 : 35) : 0;
                p[1] = x < w && y < h ? 0 : 255;
                p[2] = x < w && y < h ? (x < w/2 ? 35 : 230) : 0;
                p[3] = 255;
            }
            [input replaceRegion:MTLRegionMake2D(0,0,pw,ph) mipmapLevel:0 withBytes:pixels bytesPerRow:pw*4];
            free(pixels);
            id<MTLCommandBuffer> cb = [queue commandBuffer];
            assert(![fx encode:cb source:input contentWidth:pw+1 contentHeight:h outputWidth:dw outputHeight:dh]);
            id<MTLTexture> output = [fx encode:cb source:input contentWidth:w contentHeight:h outputWidth:dw outputHeight:dh];
            assert(output && output.width == dw && output.height == dh);
            assert(output.storageMode == MTLStorageModePrivate);
            id<MTLBuffer> buffer = [dev newBufferWithLength:dw*dh*4 options:MTLResourceStorageModeShared];
            id<MTLBlitCommandEncoder> copy = [cb blitCommandEncoder];
            [copy copyFromTexture:output sourceSlice:0 sourceLevel:0 sourceOrigin:MTLOriginMake(0,0,0)
                sourceSize:MTLSizeMake(dw,dh,1) toBuffer:buffer destinationOffset:0
                destinationBytesPerRow:dw*4 destinationBytesPerImage:dw*dh*4];
            [copy endEncoding]; [cb commit]; [cb waitUntilCompleted];
            if (cb.error) fprintf(stderr,"GPU error: %s\n",cb.error.description.UTF8String);
            assert(cb.status == MTLCommandBufferStatusCompleted && !cb.error);
            const unsigned char* data = buffer.contents;
            for (NSUInteger y = 16; y < dh; y += 128) {
                const unsigned char* left = data+(y*dw+dw/10)*4;
                const unsigned char* right = data+(y*dw+dw*9/10)*4;
                assert(left[0] > 200 && left[2] < 70 && left[1] < 10);
                assert(right[2] > 200 && right[0] < 70 && right[1] < 10);
            }
            if (!pass && resolution==2 && argc > 1) {
                FILE* f = fopen(argv[1],"wb"); assert(f);
                fprintf(f,"P6\n2560 1440\n255\n");
                for (NSUInteger i=0;i<dw*dh;i++) fwrite(data+i*4,1,3,f);
                fclose(f);
            }
        }
        }
        printf("MetalFX GPU PASS: 720p -> 720p/1080p/1440p/2160p, padded surfaces, RGBA/BGRA, resize, private readback\n");
    }
}
