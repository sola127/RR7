#import "rsx_metalfx.h"
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char** argv) {
    @autoreleasepool {
        id<MTLDevice> dev = MTLCreateSystemDefaultDevice();
        assert(dev);
        RSXMetalFX* fx = [[RSXMetalFX alloc] initWithDevice:dev];
        assert(fx);
        id<MTLCommandQueue> queue = [dev newCommandQueue];
        for (unsigned pass = 0; pass < 3; pass++) {
            NSUInteger w = pass == 2 ? 640 : 1280, h = pass == 2 ? 360 : 720;
            NSUInteger pw = w + 128, ph = h + 48;
            MTLPixelFormat fmt = pass == 1 ? MTLPixelFormatBGRA8Unorm : MTLPixelFormatRGBA8Unorm;
            MTLTextureDescriptor* td = [MTLTextureDescriptor texture2DDescriptorWithPixelFormat:fmt
                width:pw height:ph mipmapped:NO];
            td.storageMode = MTLStorageModeShared;
            td.usage = MTLTextureUsageShaderRead;
            id<MTLTexture> input = [dev newTextureWithDescriptor:td];
            unsigned char* pixels = calloc(pw * ph, 4);
            for (NSUInteger y = 0; y < ph; y++) for (NSUInteger x = 0; x < pw; x++) {
                unsigned char* p = pixels + (y*pw+x)*4;
                /* Green padding must never enter the 2K image. */
                p[0] = x < w && y < h ? (x < w/2 ? 230 : 35) : 0;
                p[1] = x < w && y < h ? 0 : 255;
                p[2] = x < w && y < h ? (x < w/2 ? 35 : 230) : 0;
                p[3] = 255;
            }
            [input replaceRegion:MTLRegionMake2D(0,0,pw,ph) mipmapLevel:0 withBytes:pixels bytesPerRow:pw*4];
            free(pixels);
            id<MTLCommandBuffer> cb = [queue commandBuffer];
            assert(![fx encode:cb source:input contentWidth:pw+1 contentHeight:h outputWidth:2560 outputHeight:1440]);
            id<MTLTexture> output = [fx encode:cb source:input contentWidth:w contentHeight:h outputWidth:2560 outputHeight:1440];
            assert(output && output.width == 2560 && output.height == 1440);
            assert(output.storageMode == MTLStorageModePrivate);
            id<MTLBuffer> buffer = [dev newBufferWithLength:2560*1440*4 options:MTLResourceStorageModeShared];
            id<MTLBlitCommandEncoder> copy = [cb blitCommandEncoder];
            [copy copyFromTexture:output sourceSlice:0 sourceLevel:0 sourceOrigin:MTLOriginMake(0,0,0)
                sourceSize:MTLSizeMake(2560,1440,1) toBuffer:buffer destinationOffset:0
                destinationBytesPerRow:2560*4 destinationBytesPerImage:2560*1440*4];
            [copy endEncoding]; [cb commit]; [cb waitUntilCompleted];
            if (cb.error) fprintf(stderr,"GPU error: %s\n",cb.error.description.UTF8String);
            assert(cb.status == MTLCommandBufferStatusCompleted && !cb.error);
            const unsigned char* data = buffer.contents;
            for (NSUInteger y = 16; y < 1440; y += 128) {
                const unsigned char* left = data+(y*2560+256)*4;
                const unsigned char* right = data+(y*2560+2304)*4;
                assert(left[0] > 200 && left[2] < 70 && left[1] < 10);
                assert(right[2] > 200 && right[0] < 70 && right[1] < 10);
            }
            if (!pass && argc > 1) {
                FILE* f = fopen(argv[1],"wb"); assert(f);
                fprintf(f,"P6\n2560 1440\n255\n");
                for (NSUInteger i=0;i<2560*1440;i++) fwrite(data+i*4,1,3,f);
                fclose(f);
            }
        }
        printf("MetalFX GPU PASS: 720p -> 2560x1440, padded surfaces, RGBA/BGRA, resize, private readback\n");
    }
}
