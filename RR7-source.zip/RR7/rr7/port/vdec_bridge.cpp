/* RR7 video notifications run on a decoder callback thread, like the SDK.
 * Synchronous AUDONE -> DecodeAu recursion otherwise exhausts the host stack. */
#include "ppu_recomp.h"
#include "../../ps3recomp/libs/codec/cellVdec.h"
#include "ps3emu/guest_call.h"
#include <condition_variable>
#include <deque>
#include <memory>
#include <mutex>
#include <thread>
#include <unordered_map>
#include <cstdio>
#include <chrono>
extern "C" void ps3_hle_register_ctx(uint32_t,const char*,void(*)(ppu_context*));
namespace {
struct Message{uint32_t callback,kind,arg;int32_t data;uint64_t generation;};
struct Input{CellVdecAuInfo au{};int32_t mode=0;uint64_t generation=0;bool end=false;};
struct State{
    std::mutex lock;std::condition_variable cv;std::deque<Message> messages;
    std::deque<Input> inputs;
    bool stop=false;uint64_t generation=0;uint32_t handle;std::thread worker;
    std::thread decoder;
    bool decoding=false,sequence=false,resetting=false;
    uint32_t callback=0,arg=0;
    uint64_t trace_count=0;
};
std::mutex objects;
std::unordered_map<uint32_t,std::shared_ptr<State>> states;
uint32_t a(ppu_context* c,int n){return uint32_t(c->gpr[n]);}
template<class T>T* ptr(uint32_t p){return reinterpret_cast<T*>(uintptr_t(p));}
void result(ppu_context*c,int32_t r){c->gpr[3]=uint64_t(int64_t(r));}
std::shared_ptr<State> state(uint32_t h){std::lock_guard<std::mutex>l(objects);auto i=states.find(h);return i==states.end()?nullptr:i->second;}
void dispatch(uint32_t,uint32_t,uint32_t,int32_t,uint32_t);

/* The SDK's output queue may fill while the guest has not yet taken its
 * pictures. Keep that backpressure on an AU worker, outside both the guest
 * submitter and callback thread. RR7 does not retry a rejected DecodeAu:
 * issuing AUDONE ahead of unbounded synchronous decoding used to lose AU 19
 * to BUSY and strand the remainder of a movie. Descriptors are snapshotted;
 * the guest retains encoded bytes until the real AUDONE from the codec. */
void decode_run(std::shared_ptr<State> s){
    for(;;){Input in;
        {std::unique_lock<std::mutex> l(s->lock);
            s->cv.wait(l,[&]{return s->stop||(!s->resetting&&!s->inputs.empty());});
            if(s->stop)break;
            in=s->inputs.front();s->inputs.pop_front();
            if(in.generation!=s->generation)continue;
            s->decoding=true;}
        int32_t rc=0;
        for(;;){
            {std::lock_guard<std::mutex> l(s->lock);
                if(s->stop||in.generation!=s->generation)break;}
            rc=in.end?cellVdecEndSeq(s->handle):cellVdecDecodeAuHost(s->handle,in.mode,&in.au);
            if(uint32_t(rc)!=CELL_VDEC_ERROR_BUSY)break;
            std::unique_lock<std::mutex> l(s->lock);
            s->cv.wait_for(l,std::chrono::milliseconds(2),[&]{return s->stop||in.generation!=s->generation;});
        }
        bool current;
        {std::lock_guard<std::mutex> l(s->lock);s->decoding=false;
            current=!s->stop&&in.generation==s->generation;}
        s->cv.notify_all();
        if(current&&rc&&uint32_t(rc)!=CELL_VDEC_ERROR_BUSY){
            fprintf(stderr,"[rr7-vdec] accepted AU failed, handle=%u error=%08X\n",s->handle,uint32_t(rc));
            dispatch(s->handle,s->callback,CELL_VDEC_MSG_TYPE_ERROR,rc,s->arg);
            if(!in.end)dispatch(s->handle,s->callback,CELL_VDEC_MSG_TYPE_AUDONE,rc,s->arg);
        }
    }
}
void run(std::shared_ptr<State> s){
    for(;;){Message m;
        {std::unique_lock<std::mutex> l(s->lock);s->cv.wait(l,[&]{return s->stop||!s->messages.empty();});
            if(s->stop)break;m=s->messages.front();s->messages.pop_front();if(m.generation!=s->generation)continue;}
        if(getenv("RR7_MEDIA_TRACE")&&(s->trace_count++<64||s->trace_count%300==0))
            fprintf(stderr,"[rr7-media] Vdec notify h=%u cb=%08X arg=%08X kind=%u data=%08X generation=%llu\n",
                s->handle,m.callback,m.arg,m.kind,uint32_t(m.data),(unsigned long long)m.generation);
        try{if(g_ps3_guest_caller)g_ps3_guest_caller(m.callback,s->handle,m.kind,uint64_t(int64_t(m.data)),m.arg,0,0,0,0);}
        catch(const std::exception& e){std::fprintf(stderr,"[rr7-vdec] callback failure: %s\n",e.what());
            std::lock_guard<std::mutex> l(s->lock);s->stop=true;break;}
    }
}
void dispatch(uint32_t handle,uint32_t callback,uint32_t kind,int32_t data,uint32_t arg){
    auto s=state(handle);if(!s)return;
    std::lock_guard<std::mutex> l(s->lock);if(s->stop)return;
    if(s->messages.size()>=4096){std::fprintf(stderr,"[rr7-vdec] callback queue overflow, handle=%u\n",handle);s->stop=true;s->cv.notify_all();return;}
    s->messages.push_back({callback,kind,arg,data,s->generation});s->cv.notify_one();
}
void stop(const std::shared_ptr<State>& s){
    {std::lock_guard<std::mutex> l(s->lock);s->stop=true;s->messages.clear();s->inputs.clear();}s->cv.notify_all();
    if(s->decoder.joinable())s->decoder.join();
    if(s->worker.joinable()){if(s->worker.get_id()==std::this_thread::get_id())s->worker.detach();else s->worker.join();}
    std::lock_guard<std::mutex> l(objects);auto i=states.find(s->handle);if(i!=states.end()&&i->second==s)states.erase(i);
}
void open(ppu_context* c){
    int32_t r=cellVdecOpen(ptr<CellVdecType>(a(c,3)),ptr<CellVdecResource>(a(c,4)),ptr<CellVdecCb>(a(c,5)),ptr<CellVdecHandle>(a(c,6)));
    if(r){result(c,r);return;}
    uint32_t handle=vm_read32(a(c,6));auto s=std::make_shared<State>();s->handle=handle;
    const uint32_t cb=a(c,5);
    if(cb){s->callback=vm_read32(cb);s->arg=vm_read32(cb+4);}
    {std::lock_guard<std::mutex> l(objects);states[handle]=s;}
    try{s->worker=std::thread(run,s);s->decoder=std::thread(decode_run,s);}
    catch(...){stop(s);cellVdecClose(handle);result(c,int32_t(CELL_VDEC_ERROR_FATAL));return;}
    std::fprintf(stderr,"[rr7-vdec] asynchronous callbacks handle=%u\n",handle);result(c,0);
}
void close(ppu_context* c){uint32_t handle=a(c,3);if(auto s=state(handle))stop(s);result(c,cellVdecClose(handle));}
void start(ppu_context* c){uint32_t handle=a(c,3);auto s=state(handle);
    if(!s){result(c,int32_t(CELL_VDEC_ERROR_ARG));return;}
    {std::unique_lock<std::mutex> l(s->lock);s->resetting=true;s->sequence=false;
        s->generation++;s->inputs.clear();s->messages.clear();s->cv.notify_all();
        s->cv.wait(l,[&]{return !s->decoding;});s->messages.clear();}
    const int32_t rc=cellVdecStartSeq(handle);
    {std::lock_guard<std::mutex> l(s->lock);s->sequence=rc==0;s->resetting=false;}s->cv.notify_all();result(c,rc);}
void decode(ppu_context* c){
    auto s=state(a(c,3));const uint32_t p=a(c,5);
    if(!s||p<0x10000||uint64_t(p)+32>0x100000000ull){result(c,int32_t(CELL_VDEC_ERROR_ARG));return;}
    Input in;in.mode=int32_t(a(c,4));
    in.au.startAddr=vm_read32(p);in.au.size=vm_read32(p+4);
    in.au.pts=(uint64_t(vm_read32(p+8))<<32)|vm_read32(p+12);
    in.au.dts=(uint64_t(vm_read32(p+16))<<32)|vm_read32(p+20);
    in.au.userData=(uint64_t(vm_read32(p+24))<<32)|vm_read32(p+28);
    if(in.au.size&&(in.au.startAddr<0x10000||uint64_t(in.au.startAddr)+in.au.size>0x100000000ull)){
        result(c,int32_t(CELL_VDEC_ERROR_ARG));return;}
    std::lock_guard<std::mutex> l(s->lock);
    if(s->stop||!s->sequence||s->resetting){result(c,int32_t(CELL_VDEC_ERROR_SEQ));return;}
    /* The demuxer owns four source slots. Eight queued inputs also leave
     * room for an AUDONE already dispatched during the worker's return. */
    if(s->inputs.size()>=8){result(c,int32_t(CELL_VDEC_ERROR_BUSY));return;}
    in.generation=s->generation;s->inputs.push_back(in);s->cv.notify_all();result(c,0);
}
void end(ppu_context* c){auto s=state(a(c,3));if(!s){result(c,int32_t(CELL_VDEC_ERROR_ARG));return;}
    std::lock_guard<std::mutex> l(s->lock);
    if(s->stop||!s->sequence||s->resetting){result(c,int32_t(CELL_VDEC_ERROR_SEQ));return;}
    Input in;in.generation=s->generation;in.end=true;s->inputs.push_back(in);s->sequence=false;
    s->cv.notify_all();result(c,0);
}
}
extern "C" void rr7_register_vdec_bridge(){
    cellVdecCallbackDispatchHook=dispatch;
    ps3_hle_register_ctx(0xB6BBCD5D,"cellVdecOpen",open);
    ps3_hle_register_ctx(0x16698E83,"cellVdecClose",close);
    ps3_hle_register_ctx(0xC757C2AA,"cellVdecStartSeq",start);
    ps3_hle_register_ctx(0x2BF4DDD2,"cellVdecDecodeAu",decode);
    ps3_hle_register_ctx(0x824433F0,"cellVdecEndSeq",end);
}
