#include "port/pamf_audio.hpp"
#include "ppu_recomp.h"
#include "ps3emu/guest_call.h"
#include <cassert>
#include <fstream>
#include <unordered_map>
#include <atomic>
#include <thread>
extern "C" void rr7_register_adec_bridge();
uint8_t* vm_base;
static std::unordered_map<uint32_t,void(*)(ppu_context*)> functions;
extern "C" void ps3_hle_register_ctx(uint32_t n,const char*,void(*f)(ppu_context*)){functions[n]=f;}
extern "C" uint8_t vm_read8(uint64_t p){assert(p<32*1024*1024);return vm_base[p];}
extern "C" uint16_t vm_read16(uint64_t p){return uint16_t(vm_read8(p))<<8|vm_read8(p+1);}
extern "C" uint32_t vm_read32(uint64_t p){return uint32_t(vm_read16(p))<<16|vm_read16(p+2);}
extern "C" uint64_t vm_read64(uint64_t p){return uint64_t(vm_read32(p))<<32|vm_read32(p+4);}
extern "C" void vm_write8(uint64_t p,uint8_t v){assert(p<32*1024*1024);vm_base[p]=v;}
extern "C" void vm_write16(uint64_t p,uint16_t v){vm_write8(p,v>>8);vm_write8(p+1,v);}
extern "C" void vm_write32(uint64_t p,uint32_t v){vm_write16(p,v>>16);vm_write16(p+2,v);}
extern "C" void vm_write64(uint64_t p,uint64_t v){vm_write32(p,v>>32);vm_write32(p+4,v);}
static uint32_t call(uint32_t n,std::initializer_list<uint64_t>args){ppu_context c={};int r=3;for(auto a:args)c.gpr[r++]=a;functions.at(n)(&c);return uint32_t(c.gpr[3]);}
static uint32_t handle;static std::vector<rr7::VideoAu> aus;static std::vector<std::vector<uint32_t>> reference;
static std::atomic<unsigned> done{0},auDone{0};static std::atomic<bool> ended{false};
static void callback(uint32_t cb,uint64_t h,uint64_t kind,uint64_t data,uint64_t arg,uint64_t,uint64_t,uint64_t,uint64_t){
    assert(cb==0x1234&&h==handle&&arg==0xbeef);
    if(kind==0){assert(uint32_t(data)==0x200000+auDone*32);auDone++;return;}
    if(kind==3){ended=true;return;}
    assert(kind==1&&data==0);unsigned index=done.load();assert(index<reference.size());
    assert(call(0xBD75F78B,{handle,0x11000})==0);uint32_t item=vm_read32(0x11000);
    assert(vm_read32(item)==handle&&vm_read32(item+4)==0&&vm_read32(item+12)==49152);
    assert(vm_read64(item+32)==uint64_t(aus[index].pts)&&vm_read64(item+40)==0xc000+index);
    uint32_t bsi=vm_read32(item+16);
    assert(vm_read32(bsi)==48000&&vm_read32(bsi+4)==5&&vm_read32(bsi+8)==1712);
    assert(call(0x97FF2AF1,{handle,0x300000})==0);
    // Exercise RR7's actual six-channel reorder, recovering standard WAVE
    // order; a decoder that merely copies FFmpeg planes fails this check.
    constexpr unsigned guestToWave[]={0,2,1,5,3,4};
    for(size_t i=0;i<2048;i++)for(unsigned c=0;c<6;c++)
        assert(vm_read32(0x300000+(i*6+guestToWave[c])*4)==reference[index][i*6+c]);
    assert(call(0x97FF2AF1,{handle,0x300000})==0x80610005);done++;
}
ps3_guest_caller_fn g_ps3_guest_caller=callback;
int main(int argc,char**argv){
    assert(argc==2);rr7::PamfPes ps;rr7::PamfAudio audio;std::ifstream f(argv[1],std::ios::binary);assert(f);f.seekg(2048);
    std::vector<uint8_t> b(65536);while(f&&aus.size()<63){f.read((char*)b.data(),b.size());ps.feed(b.data(),size_t(f.gcount()),[&](const rr7::PesPayload&p){audio.packet(p,[&](rr7::VideoAu au){if(aus.size()<63)aus.push_back(std::move(au));});});}
    assert(aus.size()==63);const AVCodec* codec=avcodec_find_decoder(AV_CODEC_ID_ATRAC3P);assert(codec);
    AVCodecContext* ctx=avcodec_alloc_context3(codec);ctx->block_align=1712;ctx->sample_rate=48000;ctx->ch_layout=AV_CHANNEL_LAYOUT_5POINT1_BACK;
    assert(avcodec_open2(ctx,codec,nullptr)==0);AVPacket* pkt=av_packet_alloc();AVFrame* frame=av_frame_alloc();
    for(const auto&au:aus){assert(av_new_packet(pkt,1712)==0);memcpy(pkt->data,au.bytes.data()+8,1712);assert(avcodec_send_packet(ctx,pkt)==0);av_packet_unref(pkt);assert(avcodec_receive_frame(ctx,frame)==0);
      std::vector<uint32_t> pcm;for(int i=0;i<2048;i++)for(int c=0;c<6;c++){uint32_t bits;memcpy(&bits,(float*)frame->extended_data[c]+i,4);pcm.push_back(bits);}reference.push_back(std::move(pcm));av_frame_unref(frame);}
    av_packet_free(&pkt);av_frame_free(&frame);avcodec_free_context(&ctx);
    std::vector<uint8_t> memory(32*1024*1024,0xa5);vm_base=memory.data();rr7_register_adec_bridge();
    vm_write32(0x10000,3);vm_write32(0x10100,0x40000);vm_write32(0x10104,0x100000);vm_write32(0x10200,0x1234);vm_write32(0x10204,0xbeef);
    assert(call(0x7E4A4A49,{0x10000,0x10300})==0&&vm_read32(0x10300)==0x40000);
    assert(call(0xD00A6988,{0x10000,0x10100,0x10200,0x10300})==0);handle=vm_read32(0x10300);
    for(unsigned i=0;i<28;i++)vm_write8(0x10400+i,0);
    vm_write32(0x10408,6);vm_write32(0x10414,0x84);vm_write8(0x10419,1);
    assert(call(0x487B613E,{handle,0x10400})==0);
    for(size_t i=0;i<aus.size();i++){uint32_t info=0x200000+uint32_t(i)*32,data=0x400000+uint32_t(i)*2048;memcpy(vm_base+data,aus[i].bytes.data(),aus[i].bytes.size());
      vm_write32(info,data);vm_write32(info+4,uint32_t(aus[i].bytes.size()));vm_write64(info+8,uint64_t(aus[i].pts));vm_write64(info+16,0xc000+i);assert(call(0x1529E506,{handle,info})==0);}
    assert(call(0xE2EA549B,{handle})==0);
    auto until=std::chrono::steady_clock::now()+std::chrono::seconds(10);while(!ended){assert(std::chrono::steady_clock::now()<until);std::this_thread::yield();}
    assert(done==63&&auDone==63);assert(call(0x847D2380,{handle})==0);
    assert(memory[0xfffff]==0xa5&&memory[0x140000]==0xa5&&memory[0x2fffff]==0xa5&&memory[0x30c000]==0xa5);
    puts("ATRAC3plus guest SDK: 63 real AUs, 6-channel PCM bit comparison, metadata, callbacks, ownership, EOF and canaries PASS");
}
