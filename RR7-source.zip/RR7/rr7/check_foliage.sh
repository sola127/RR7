#!/bin/zsh
set -eu
rr7_root="${0:A:h}"
cd "$rr7_root"
rr7_sdk="$rr7_root/../ps3recomp"
clang -std=c11 -O1 -g -fsanitize=address,undefined -I "$rr7_sdk/include" \
 "$rr7_sdk/libs/video/tests/test_fp_decompiler.c" "$rr7_sdk/libs/video/rsx_fp_decompiler.c" \
 -o analysis/test_fp_decompiler
analysis/test_fp_decompiler > analysis/foliage-alpha-tests.log
clang -std=gnu17 -O1 -g -fsanitize=address,undefined -I "$rr7_sdk/include" -I "$rr7_sdk/libs/video" \
 "$rr7_sdk/libs/video/tests/test_gcm_engine_routing.c" -ffunction-sections -fdata-sections \
 -Wl,-dead_strip -pthread -o analysis/test_gcm_engine_routing
analysis/test_gcm_engine_routing > analysis/foliage-routing-tests.log
analysis/test_gcm_engine_routing sub1-2d >> analysis/foliage-routing-tests.log
clang -fobjc-arc -O1 -I "$rr7_sdk/include" -I "$rr7_sdk/libs/video" -DPS3RECOMP_HAVE_SHADER_MSL=1 \
 -c "$rr7_sdk/libs/video/tests/test_color_feedback_metal.m" -o analysis/test_color_feedback_metal.o
clang++ analysis/test_color_feedback_metal.o build/ps3recomp_sdk/libps3recomp_runtime.a -Wl,-dead_strip \
 -framework Metal -framework MetalFX -framework Foundation -framework AppKit -framework QuartzCore \
 -framework IOKit -framework ApplicationServices -F deps -framework SDL2 -L deps-prefix/lib \
 -lSPIRV -lglslang -lglslang-default-resource-limits -lspirv-cross-c-shared \
 -Wl,-rpath,"$rr7_root/deps-prefix/lib" -Wl,-rpath,"$rr7_root/deps" -o analysis/test_color_feedback_metal
MTL_DEBUG_LAYER=1 analysis/test_color_feedback_metal > analysis/foliage-gpu-tests.log 2>&1
print 'Foliage shader, FIFO routing and real Metal colour/depth checks passed.'
