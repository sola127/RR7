#!/bin/zsh
# Standalone SPU group lifetime/ABI checks, including priority capture.
# Link fixtures supply runtime services that these paths never execute.
set -eu
rr7_root="${0:A:h}"
rr7_sdk="$rr7_root/../ps3recomp"
clang -DPS3_GROUP_TEST_LINK_STUBS \
  -c "$rr7_sdk/runtime/spu/tests/test_spu_group_lifecycle_win_stubs.c" \
  -o "$rr7_root/analysis/group-test-link-stubs.o"
clang -std=gnu17 -O1 -g -fsanitize=address,undefined \
  -I "$rr7_sdk/include" -I "$rr7_sdk/runtime" \
  -I "$rr7_sdk/runtime/syscalls" -I "$rr7_sdk/runtime/spu" -I "$rr7_sdk/libs/video" \
  "$rr7_sdk/runtime/spu/tests/test_spu_group_lifecycle.c" \
  "$rr7_sdk/runtime/spu/spu_lifted_thread.c" "$rr7_root/analysis/group-test-link-stubs.o" \
  -Wl,-dead_strip -pthread -o "$rr7_root/analysis/test_spu_group_lifecycle"
"$rr7_root/analysis/test_spu_group_lifecycle"
