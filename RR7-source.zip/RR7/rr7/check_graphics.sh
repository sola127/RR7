#!/bin/zsh
set -eu
rr7_root="${0:A:h}"
rr7_sdk="$rr7_root/../ps3recomp"
clang -std=gnu17 -O1 -g -fsanitize=address,undefined -I "$rr7_sdk/include" \
  "$rr7_root/test_videoout.c" -o "$rr7_root/analysis/test_videoout"
"$rr7_root/analysis/test_videoout"
for rr7_test in test_gcm_flip_stream test_gcm_flip_status; do
  clang -std=gnu17 -O1 -I "$rr7_sdk/include" -I "$rr7_sdk/libs/video" \
    "$rr7_sdk/libs/video/tests/$rr7_test.c" -ffunction-sections -fdata-sections \
    -Wl,-dead_strip -pthread -o "$rr7_root/analysis/$rr7_test"
  "$rr7_root/analysis/$rr7_test"
done
clang -fobjc-arc -O1 -g -I "$rr7_sdk/libs/video" \
  "$rr7_root/port/test_metalfx.m" "$rr7_sdk/libs/video/rsx_metalfx.m" \
  -framework Foundation -framework Metal -framework MetalFX -o "$rr7_root/analysis/test_metalfx"
MTL_DEBUG_LAYER=1 "$rr7_root/analysis/test_metalfx" "$rr7_root/analysis/metalfx-2k-pattern.ppm"
clang++ -std=c++17 -O1 -g -fsanitize=address,undefined -I "$rr7_sdk/include" \
  "$rr7_root/test_frame_handoff.cpp" -o "$rr7_root/analysis/test_frame_handoff"
"$rr7_root/analysis/test_frame_handoff"
