"""Assemble a self-contained, signed local RR7.app. Never removes dev/game originals."""
from pathlib import Path
import subprocess,shutil,plistlib,json,hashlib,os,datetime
from PIL import Image
r=Path(__file__).resolve().parent
app=Path.home()/'Desktop/RR7.app'
if app.exists():raise SystemExit(f'Refusing to replace an existing app without review: {app}')
c=app/'Contents';mac=c/'MacOS';res=c/'Resources';fw=c/'Frameworks'
for p in (mac,res,fw):p.mkdir(parents=True,exist_ok=True)
def run(*args):subprocess.run([str(x) for x in args],check=True,stdout=subprocess.DEVNULL)
def copy(src,dst):
 src=Path(src).resolve();dst=Path(dst);dst.parent.mkdir(parents=True,exist_ok=True)
 # APFS clone is independent of the source pathname and deletion, unlike a symlink.
 if subprocess.run(['/bin/cp','-c',str(src),str(dst)],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode:
  shutil.copyfile(src,dst)
 os.chmod(dst,src.stat().st_mode&0o777)
copy(r/'build/RidgeRacer7Recomp',mac/'RR7')
copy(r/'EBOOT.ELF',res/'EBOOT.ELF')
game=res/'Game'
for name in ('PS3_DISC.SFB','PS3_GAME/PARAM.SFO'):
 copy(r/'game'/name,game/name)
usr=game/'PS3_GAME/USRDIR'
for src in sorted((r/'game/PS3_GAME/USRDIR').iterdir()):
 if src.name.startswith('.') or src.name=='EBOOT.BIN':continue
 if src.is_file():copy(src,usr/src.name)
print('Game resources copied independently.',flush=True)
libs=[(r/'deps-prefix-av/lib/libavcodec.62.dylib','libavcodec.62.dylib'),
      (r/'deps-prefix-av/lib/libavutil.60.dylib','libavutil.60.dylib'),
      (r/'deps-prefix/lib/libspirv-cross-c-shared.0.dylib','libspirv-cross-c-shared.0.dylib')]
for src,name in libs:copy(src,fw/name)
sdl=fw/'SDL2.framework';ver=sdl/'Versions/A';(ver/'Resources').mkdir(parents=True)
run('lipo',r/'deps/SDL2.framework/Versions/A/SDL2','-thin','arm64','-output',ver/'SDL2')
for name in ('Info.plist','License.txt','default.metallib'):
 copy(r/'deps/SDL2.framework/Versions/A/Resources'/name,ver/'Resources'/name)
(sdl/'Versions/Current').symlink_to('A');(sdl/'SDL2').symlink_to('Versions/Current/SDL2');(sdl/'Resources').symlink_to('Versions/Current/Resources')
# Rewrite every non-system dependency to the app; remove build-tree rpaths.
exe=mac/'RR7'
for src,name in libs:
 old=subprocess.check_output(['otool','-D',str(src)],text=True).splitlines()[1].strip()
 run('install_name_tool','-change',old,'@rpath/'+name,exe)
 run('install_name_tool','-id','@rpath/'+name,fw/name)
avutil_id=subprocess.check_output(['otool','-D',str(libs[1][0])],text=True).splitlines()[1].strip()
run('install_name_tool','-change',avutil_id,'@loader_path/libavutil.60.dylib',fw/'libavcodec.62.dylib')
lines=subprocess.check_output(['otool','-l',str(exe)],text=True).splitlines()
for i,line in enumerate(lines):
 if line.strip()=='cmd LC_RPATH':
  old=lines[i+2].strip().split(' (offset ')[0][5:]
  run('install_name_tool','-delete_rpath',old,exe)
run('install_name_tool','-add_rpath','@executable_path/../Frameworks',exe)
for binary in [exe,*[fw/name for _,name in libs],ver/'SDL2']:run('strip','-x',binary)
# Standard multi-resolution icns, using the generated square image unchanged.
iconset=r/'analysis/RR7.iconset';iconset.mkdir(exist_ok=True)
im=Image.open(Path(os.environ['RR7_ICON'])).convert('RGBA')
for n in (16,32,128,256,512):
 for scale in (1,2):
  size=n*scale;suffix='@2x' if scale==2 else ''
  im.resize((size,size),Image.Resampling.LANCZOS).save(iconset/f'icon_{n}x{n}{suffix}.png')
run('iconutil','-c','icns',iconset,'-o',res/'RR7.icns')
info=dict(CFBundleIdentifier='local.sola.RR7',CFBundleName='RR7',CFBundleDisplayName='RR7',
 CFBundleExecutable='RR7',CFBundleIconFile='RR7',CFBundlePackageType='APPL',
 CFBundleShortVersionString='0.1.0',CFBundleVersion='20261114.1',LSMinimumSystemVersion='27.2',
 LSApplicationCategoryType='public.app-category.racing-games',LSMultipleInstancesProhibited=True,
 NSHighResolutionCapable=True,NSPrincipalClass='NSApplication',LSArchitecturePriority=['arm64'])
(c/'Info.plist').write_bytes(plistlib.dumps(info,sort_keys=True));(c/'PkgInfo').write_bytes(b'APPL????')
licenses=res/'Licenses';licenses.mkdir()
for src,name in [(r.parent/'ps3recomp/LICENSE','ps3recomp.txt'),
 (r/'deps-src/ffmpeg-8.0.1/COPYING.LGPLv2.1','FFmpeg-LGPL-2.1.txt'),
 (r/'deps-src/SPIRV-Cross/LICENSE','SPIRV-Cross.txt'),
 (r/'deps-src/glslang/LICENSE.txt','glslang.txt')]:copy(src,licenses/name)
(licenses/'NOTICE.txt').write_text('RR7 local native build. Runtime: ps3recomp; SDL2; FFmpeg 8.0.1 (MPEG2/ATRAC3plus); glslang; SPIRV-Cross.\nGame data and trademarks remain those of their respective owners.\n')
# Keep writable state separate; preserve the user's existing test-play saves.
support=Path.home()/'Library/Application Support/RR7';support.mkdir(parents=True,exist_ok=True)
for src,name in [(r/'gamedata','SaveData'),(r/'hdd0','HDD0')]:
 dst=support/name
 if not dst.exists():shutil.copytree(src,dst)
manifest={'built_at':datetime.datetime.now().isoformat(),'app':str(app),'data_root':str(support),
 'render':'1280x720 -> SMAA1x -> MetalFX Spatial -> 2560x1440',
 'game_bytes':sum(x.stat().st_size for x in game.rglob('*') if x.is_file()),
 'independent_game_files':True,'debug_capture_default':False,
 'resources':[{'path':str(f.relative_to(c)),'bytes':f.stat().st_size} for f in sorted(c.rglob('*')) if f.is_file()]}
(res/'BuildInfo.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
for binary in [*[fw/name for _,name in libs],sdl]:run('codesign','--force','--sign','-',binary)
run('codesign','--force','--sign','-',app)
run('codesign','--verify','--deep','--strict',app)
# Validate all symlinks are internal and all load commands are relocatable.
for f in app.rglob('*'):
 if f.is_symlink():assert f.resolve().is_relative_to(app.resolve()),f
for binary in [exe,*[fw/name for _,name in libs],ver/'SDL2']:
 output=subprocess.check_output(['otool','-L',str(binary)],text=True)
 for line in output.splitlines()[1:]:
  dep=line.strip().split(' (')[0]
  assert dep.startswith(('/System/Library/','/usr/lib/','@rpath/','@loader_path/','@executable_path/')),dep
(out:=r.parent/'local-artifacts').mkdir(parents=True,exist_ok=True)
(out/'app-package.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'app':str(app),'game_GiB':round(manifest['game_bytes']/2**30,2),'native_bytes':exe.stat().st_size,'saves':str(support/'SaveData')},ensure_ascii=False),flush=True)
