#import <AppKit/AppKit.h>
#include <assert.h>
void rr7_pad_set_ui_active(int active){(void)active;}
void rr7_set_performance_overlay(int enabled){(void)enabled;}
#include "port/settings.m"
int main(){@autoreleasepool{
[NSApplication sharedApplication];NSUserDefaults*d=NSUserDefaults.standardUserDefaults;
[d setVolatileDomain:@{@"OutputHeight":@2160,@"Volume":@50,@"PAD_KEY_4000":@8,@"PAD_BUTTON_4000":@3,@"ControllerGUID":@"none",@"AntiAliasing":@"fxaa"} forName:NSArgumentDomain];
rr7_settings_apply_environment();assert(!strcmp(getenv("PS3_METALFX_OUTPUT_WIDTH"),"3840"));assert(!strcmp(getenv("PS3_METALFX_OUTPUT_HEIGHT"),"2160"));assert(!strcmp(getenv("PS3_MASTER_VOLUME"),"0.500"));assert(!strcmp(getenv("PAD_KEY_4000"),"8"));assert(!strcmp(getenv("PAD_BUTTON_4000"),"3"));assert(!strcmp(getenv("PAD_CONTROLLER_GUID"),"none"));assert(!strcmp(getenv("PS3_AA"),"fxaa"));
[d setVolatileDomain:@{@"OutputHeight":@999,@"Volume":@200,@"AntiAliasing":@"invalid"} forName:NSArgumentDomain];rr7_settings_apply_environment();assert(!strcmp(getenv("PS3_METALFX_OUTPUT_HEIGHT"),"1440"));assert(!strcmp(getenv("PS3_MASTER_VOLUME"),"1.000"));assert(!strcmp(getenv("PS3_AA"),"smaa"));
[d setVolatileDomain:@{@"Muted":@1,@"Volume":@100} forName:NSArgumentDomain];rr7_settings_apply_environment();assert(!strcmp(getenv("PS3_MASTER_VOLUME"),"0.000"));
[d setVolatileDomain:@{@"AntiAliasing":@"msaa8"} forName:NSArgumentDomain];rr7_settings_apply_environment();assert(!strcmp(getenv("PS3_MSAA_SAMPLES"),"8"));
[d removeVolatileDomainForName:NSArgumentDomain];
puts("settings: 4K output, volume clamp/mute, key/controller forwarding and invalid-setting fallback PASS");}}
