#include "../ps3recomp/libs/video/cellVideoOut.c"
#include <assert.h>
#include <stddef.h>
#include <stdlib.h>
uint8_t* vm_base;
_Static_assert(sizeof(CellVideoOutDeviceInfo)==456,"SDK device info size");
_Static_assert(offsetof(CellVideoOutDeviceInfo,availableModes)==32,"SDK mode table offset");
_Static_assert(offsetof(CellVideoOutDeviceInfo,ksvList)==288,"SDK KSV offset");
_Static_assert(sizeof(CellVideoOutState)==16,"SDK state size");
_Static_assert(sizeof(CellVideoOutConfiguration)==16,"SDK config size");
int main(void){
    vm_base=malloc(0x20000);memset(vm_base,0xa5,0x20000);u32 out=0x10000;
    assert(cellVideoOutGetDeviceInfo(0,0,(CellVideoOutDeviceInfo*)(uintptr_t)out)==0);
    assert(vm_base[out]==1&&vm_base[out+5]==1&&vm_base[out+4]==4);
    assert(vm_base[out-1]==0xa5&&vm_base[out+456]==0xa5);
    assert(vm_read32(out+28)==100&&vm_read32(out+452)==0);
    const u8 expected[]={4,5,2,1};
    for(int i=0;i<4;i++){
        assert(vm_base[out+32+i*8]==expected[i]);
        assert(vm_read16(out+32+i*8+6)==(expected[i]==5?2:5));
    }
    assert(cellVideoOutGetDeviceInfo(0,1,(CellVideoOutDeviceInfo*)(uintptr_t)out)==CELL_VIDEO_OUT_ERROR_DEVICE_NOT_FOUND);
    assert(cellVideoOutGetState(0,0,(CellVideoOutState*)(uintptr_t)out)==0);
    assert(vm_base[out]==0&&vm_base[out+8]==2&&vm_base[out+11]==2);
    assert(cellVideoOutGetState(0,1,(CellVideoOutState*)(uintptr_t)out)==CELL_VIDEO_OUT_ERROR_DEVICE_NOT_FOUND);
    memset(vm_base+out,0,16);vm_base[out]=1;vm_base[out+1]=0;vm_base[out+2]=2;
    vm_base[out+12]=0;vm_base[out+13]=0;vm_base[out+14]=0x1e;vm_base[out+15]=0;
    assert(cellVideoOutConfigure(0,(CellVideoOutConfiguration*)(uintptr_t)out,NULL,0)==0);
    assert(cellVideoOutGetConfiguration(0,(CellVideoOutConfiguration*)(uintptr_t)out,NULL)==0);
    assert(vm_base[out]==1&&vm_base[out+1]==0&&vm_read32(out+12)==7680);
    vm_base[out]=0x33;assert(cellVideoOutConfigure(0,(CellVideoOutConfiguration*)(uintptr_t)out,NULL,0)==CELL_VIDEO_OUT_ERROR_ILLEGAL_CONFIGURATION);
    assert(cellVideoOutGetResolution(0x33,(CellVideoOutResolution*)(uintptr_t)out)==CELL_VIDEO_OUT_ERROR_PARAMETER_OUT_OF_RANGE);
    assert(cellVideoOutGetResolutionAvailability(0,0x33,0,0)==0);
    free(vm_base);puts("Video output SDK layout, enums, endian fields, device indices and config round trip PASS");
}
