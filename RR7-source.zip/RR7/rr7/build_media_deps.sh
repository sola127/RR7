#!/bin/zsh
# Rebuild the MPEG2 + ATRAC3plus LGPL shared libraries from the verified local source.
set -eu
rr7_root="${0:A:h}"
rr7_archive="$rr7_root/deps-src/ffmpeg-8.0.1.tar.xz"
rr7_digest=$(shasum -a 256 "$rr7_archive" | cut -d ' ' -f 1)
[[ "$rr7_digest" == 05ee0b03119b45c0bdb4df654b96802e909e0a752f72e4fe3794f487229e5a41 ]]
rr7_source="$rr7_root/deps-src/ffmpeg-audio"
mkdir -p "$rr7_source"
if [[ ! -f "$rr7_source/configure" ]]; then
  tar -xJf "$rr7_archive" --strip-components=1 -C "$rr7_source"
fi
cd "$rr7_source"
./configure --disable-everything --enable-decoder=mpeg2video,atrac3p \
  --enable-parser=mpegvideo --enable-shared --disable-static --disable-programs \
  --disable-doc --disable-avdevice --disable-avformat --disable-swresample \
  --disable-swscale --disable-autodetect --disable-iconv --prefix="$rr7_root/deps-prefix-av"
make -j4
make install
