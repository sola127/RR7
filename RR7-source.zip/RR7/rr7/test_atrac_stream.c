/* Actual RR7 six-channel ATRAC: full-memory versus bounded streaming. */
#include <assert.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
uint8_t* vm_base;
#include "../ps3recomp/libs/codec/cellAtrac.c"
int g_resv_store_active;uint32_t g_ww_lo,g_ww_hi;
void ppu_resv_break_store(uint64_t a){(void)a;}
void ps3_ww_report_inline(uint32_t a,uint64_t v,int w){(void)a;(void)v;(void)w;}
int spu_coh_is_reserved(uint32_t a){(void)a;return 0;}
void spu_lockline_lock(void){}void spu_lockline_unlock(void){}void spu_coh_notify_write(uint32_t a){(void)a;}
static void wl32(u8* p,u32 v){p[0]=v;p[1]=v>>8;p[2]=v>>16;p[3]=v>>24;}
enum { H=0x100,ARGS=0x200,OUT=0x1000,FILE_EA=0x100000,STREAM=0x400000,CAP=8192 };
int main(int argc,char**argv) {
 assert(argc==2);vm_base=calloc(1,8u<<20);assert(vm_base);
 FILE* f=fopen(argv[1],"rb");assert(f);assert(!fseek(f,12288,SEEK_SET));
 assert(fread(vm_base+FILE_EA,1,1u<<20,f)==1u<<20);fclose(f);
 u8* data=vm_base+FILE_EA;AtracTrackInfo t;
 assert(!atrac_parse_riff(data,1u<<20,&t)&&t.channels==6);
 const u32 bytes=t.data_off+96*t.block_align;
 wl32(data+4,bytes-8);wl32(data+t.data_off-4,96*t.block_align);
 for(u32 o=12;o+8<t.data_off;o+=8+le32(data+o+4)) {
  if(!memcmp(data+o,"fact",4))wl32(data+o+8,96*2048-t.first);
  if(!memcmp(data+o,"smpl",4))wl32(data+o+8+28,0);
 }
 assert(!atrac_parse_riff(data,bytes,&t)&&t.end==96*2048);
 const u32 expected=(u32)(t.end-t.first)*t.channels;
 u8* reference=malloc(expected*4);assert(reference);
 assert(!cellAtracSetDataAndGetMemSize(H,FILE_EA,bytes,bytes,ARGS));
 assert(!cellAtracCreateDecoder(H,0,0,0));
 u32 count=0;double energy[8]={0};
 while(count<expected) {
  assert(!cellAtracDecode(H,OUT,ARGS,ARGS+4,ARGS+8));
  u32 n=vm_read32(ARGS)*t.channels;assert(n&&count+n<=expected);
  memcpy(reference+count*4,vm_base+OUT,n*4);
  for(u32 i=0;i<n;i++){u32 v=vm_read32(OUT+i*4);float x;memcpy(&x,&v,4);assert(isfinite(x)&&fabsf(x)<2);energy[i%6]+=(double)x*x;}
  count+=n;
 }
 assert(!cellAtracDeleteDecoder(H));
 for(u32 c=0;c<6;c++)assert(energy[c]>0.01);
 memcpy(vm_base+STREAM,data,t.data_off+t.block_align);
 assert(!cellAtracSetDataAndGetMemSize(H,STREAM,t.data_off+t.block_align,CAP,ARGS));
 assert(!cellAtracCreateDecoder(H,0,0,0));
 assert(cellAtracAddStreamData(H,CAP+1)==(s32)CELL_ATRAC_ERROR_ADD_DATA_IS_TOO_BIG);
 count=0;u32 starvation=0,refills=0;
 while(count<expected) {
  s32 rc=cellAtracDecode(H,OUT,ARGS,ARGS+4,ARGS+8);
  if(rc==(s32)CELL_ATRAC_ERROR_NODATA_IN_BUFFER) {
   starvation++;assert(!cellAtracGetStreamDataInfo(H,ARGS+16,ARGS+20,ARGS+24));
   u32 ptr=vm_read32(ARGS+16),n=vm_read32(ARGS+20),pos=vm_read32(ARGS+24);
   if(n>1879)n=1879;assert(n&&pos+n<=bytes&&ptr==STREAM);
   memcpy(vm_base+ptr,data+pos,n);assert(!cellAtracAddStreamData(H,n));refills++;continue;
  }
  assert(rc==CELL_OK);u32 n=vm_read32(ARGS)*t.channels;
  assert(n&&count+n<=expected&&!memcmp(reference+count*4,vm_base+OUT,n*4));count+=n;
 }
 assert(starvation&&refills);assert(vm_read32(ARGS+4)==1);
 assert(!cellAtracDeleteDecoder(H));
 printf("ATRAC stream PASS: 6 channels, %u samples/ch, %u refills; all PCM identical to full-memory decode; energy %.2f/%.2f/%.2f/%.2f/%.2f/%.2f\n",expected/6,refills,energy[0],energy[1],energy[2],energy[3],energy[4],energy[5]);
 free(reference);free(vm_base);return 0;
}
