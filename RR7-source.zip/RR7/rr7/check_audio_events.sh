#!/bin/zsh
set -eu
rr7_root="${0:A:h}"
rr7_sdk="$rr7_root/../ps3recomp"
clang -std=gnu17 -O1 -g -fsanitize=address,undefined \
  -I"$rr7_sdk/include" -I"$rr7_sdk/runtime" -I"$rr7_sdk/runtime/syscalls" \
  -I"$rr7_sdk/runtime/spu" -I"$rr7_sdk/libs/video" \
  "$rr7_sdk/runtime/spu/tests/test_spu_receive_event.c" \
  "$rr7_sdk/runtime/syscalls/sys_event.c" "$rr7_sdk/runtime/platform/win32_compat.c" \
  -Wl,-dead_strip -pthread -o "$rr7_root/analysis/test_spu_receive_event"
"$rr7_root/analysis/test_spu_receive_event"
