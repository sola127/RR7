#include "ppu_recomp.h"
#include <cassert>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <unordered_map>
#include <initializer_list>
extern "C" void rr7_register_pamf_bridge();
uint8_t* vm_base=nullptr;
static std::unordered_map<uint32_t,void(*)(ppu_context*)> functions;
extern "C" void ps3_hle_register_ctx(uint32_t n,const char*,void(*f)(ppu_context*)){functions[n]=f;}
extern "C" uint8_t vm_read8(uint64_t p){assert(p<0x100000);return vm_base[p];}
extern "C" uint16_t vm_read16(uint64_t p){return uint16_t(vm_read8(p))<<8|vm_read8(p+1);}
extern "C" uint32_t vm_read32(uint64_t p){return uint32_t(vm_read16(p))<<16|vm_read16(p+2);}
extern "C" uint64_t vm_read64(uint64_t p){return uint64_t(vm_read32(p))<<32|vm_read32(p+4);}
extern "C" void vm_write8(uint64_t p,uint8_t v){assert(p<0x100000);vm_base[p]=v;}
extern "C" void vm_write16(uint64_t p,uint16_t v){vm_write8(p,v>>8);vm_write8(p+1,v);}
extern "C" void vm_write32(uint64_t p,uint32_t v){vm_write16(p,v>>16);vm_write16(p+2,v);}
extern "C" void vm_write64(uint64_t p,uint64_t v){vm_write32(p,v>>32);vm_write32(p+4,v);}
static uint32_t call(uint32_t n,std::initializer_list<uint64_t> args){ppu_context c={};int i=3;for(auto a:args)c.gpr[i++]=a;functions.at(n)(&c);return uint32_t(c.gpr[3]);}
int main(int argc,char**argv){
    assert(argc==2);vm_base=(uint8_t*)calloc(1,0x100000);rr7_register_pamf_bridge();
    FILE*f=fopen(argv[1],"rb");assert(f);fseek(f,0,SEEK_END);uint64_t size=ftell(f);rewind(f);
    assert(fread(vm_base+0x10000,1,2048,f)==2048);fclose(f);
    constexpr uint32_t base=0x10000,reader=0x20000,out=0x30000;
    assert(call(0xCA8181C1,{base,size,out})==0);assert(vm_read64(out)==2048);
    assert(call(0xCA8181C1,{base,size+1,out})==0x80610502);
    assert(call(0x44F5C9E3,{base,0,out,out+8})==0);assert(vm_read64(out)==2048);assert(vm_read64(out+8)+2048==size);
    // A zero unknown file size is valid and used by RR7.
    assert(call(0xB8436EE5,{reader,base,0,0})==0);
    assert(call(0xD0230671,{reader,1})==1);assert(call(0xD0230671,{reader,20})==1);assert(call(0xD0230671,{reader,21})==0);
    assert(call(0x28B4E2C1,{reader,1,0})==0);
    assert(call(0x9AB20793,{reader,out,out+1})==0);assert(vm_read8(out)==1&&vm_read8(out+1)==0);
    memset(vm_base+out,0xa5,64);assert(call(0x67FD273B,{reader,out,24})==0);
    assert(vm_read16(out+10)==1280&&vm_read16(out+12)==720);assert(vm_read8(out+24)==0xa5);
    assert(call(0x67FD273B,{reader,out,23})==0x80610503);
    assert(call(0x4DE501B1,{reader,out})==0);assert(vm_read64(out)==90000);
    assert(call(0xF61609D6,{reader,out})==0);assert(vm_read64(out)==2789697);
    memset(vm_base+out,0xa5,32);assert(call(0x01067E22,{1,0,out})==0);
    assert(vm_read32(out)==0xe0&&vm_read32(out+4)==0&&vm_read32(out+8)==0&&vm_read32(out+12)==0);assert(vm_read8(out+16)==0xa5);
    assert(call(0x01067E22,{0,3,out})==0);assert(vm_read32(out)==0xe3&&vm_read32(out+8)==1);
    assert(call(0x01067E22,{3,2,out})==0);assert(vm_read32(out)==0xbd&&vm_read32(out+4)==0x42);
    assert(call(0x01067E22,{6,0,out})==0x80610503);assert(call(0x01067E22,{0,16,out})==0x80610503);
    assert(call(0x01067E22,{0,0,0})==0x80610503);
    // Failed reinitialization must invalidate the old reader state.
    vm_write32(base,0);assert(call(0xB8436EE5,{reader,base,0,0})!=0);
    assert(call(0xD0230671,{reader,1})==0x80610503);
    free(vm_base);puts("PAMF bridge: actual title.pam metadata, ABI output bounds and error paths PASS");
}
