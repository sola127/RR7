#include "port/pamf_pes.hpp"
#include <cassert>
#include <fstream>
#include <iostream>
#include <array>
static void rejects(std::vector<uint8_t> bytes){
    rr7::PamfPes p;bool caught=false;
    try{p.feed(bytes.data(),bytes.size(),[](const auto&){},true);}catch(const std::runtime_error&){caught=true;}
    assert(caught);
}
int main(int argc,char**argv){
    assert(argc==2);
    // One video PES with PTS 90000 and three bytes of payload.
    const std::vector<uint8_t> pes={0,0,1,0xe0,0,11,0x80,0x80,5,0x21,0,5,0xbf,0x21,0x12,0x34,0x56};
    for(size_t split=0;split<=pes.size();split++){
        rr7::PamfPes p;int n=0;auto emit=[&](const rr7::PesPayload& x){
            n++;assert(x.stream==0xe0&&x.pts==90000&&x.dts==90000&&x.size==3);
            assert(x.data[0]==0x12&&x.data[1]==0x34&&x.data[2]==0x56);
        };
        p.feed(pes.data(),split,emit);p.feed(pes.data()+split,pes.size()-split,emit,true);assert(n==1);
    }
    auto bad=pes;bad[13]&=0xfe;rejects(bad);bad=pes;bad.pop_back();rejects(bad);
    bad=pes;bad[8]=99;rejects(bad);rejects({0,0,1,0,0,1});
    // Zero-length video packets end at a PS packet, not at an elementary
    // picture start code. Test every split, including a split in that code.
    auto unbounded=pes;unbounded[4]=unbounded[5]=0;
    unbounded.insert(unbounded.end(),{0,0,1,0,0,0,1,0xb9});
    for(size_t split=0;split<=unbounded.size();split++){
        rr7::PamfPes p;int n=0;auto emit=[&](const rr7::PesPayload& x){
            n++;assert(x.size==7&&x.pts==90000&&x.data[6]==0);
        };
        p.feed(unbounded.data(),split,emit);p.feed(unbounded.data()+split,unbounded.size()-split,emit,true);assert(n==1);
    }
    // Actual data must yield identical bytes/timestamps independently of chunks.
    uint64_t expectedHash=0,expectedBytes=0,expectedPackets=0;
    for(size_t chunk: {size_t(1),size_t(7),size_t(2048),size_t(65536)}){
        std::ifstream f(argv[1],std::ios::binary);assert(f);f.seekg(2048);
        rr7::PamfPes p;std::vector<uint8_t> b(chunk);uint64_t hash=14695981039346656037ull,bytes=0;int64_t first=-1,last=-1;
        auto emit=[&](const rr7::PesPayload& x){assert(x.stream==0xe0);bytes+=x.size;
            for(size_t i=0;i<x.size;i++){hash^=x.data[i];hash*=1099511628211ull;}
            if(x.pts>=0){if(first<0)first=x.pts;last=x.pts;}
        };
        while(f){f.read((char*)b.data(),b.size());p.feed(b.data(),size_t(f.gcount()),emit);}
        p.feed(nullptr,0,emit,true);assert(first==90000);assert(last>first);assert(p.packet_count()>1000);
        if(!expectedPackets){expectedHash=hash;expectedBytes=bytes;expectedPackets=p.packet_count();}
        assert(hash==expectedHash&&bytes==expectedBytes&&p.packet_count()==expectedPackets);
        std::cout<<"chunk="<<chunk<<" packets="<<p.packet_count()<<" bytes="<<bytes<<" firstPTS="<<first<<" lastPTS="<<last<<" hash="<<hash<<" PASS\n";
    }
    std::cout<<"PAMF PES streaming boundaries and malformed input PASS\n";
}
