#!/bin/zsh
set -eu
rr7_root="${0:A:h}"
clang++ -std=c++17 -DPPU_NO_INLINE_LOADS=1 -fsanitize=address,undefined -g \
  -I "$rr7_root/port/recompiled" \
  "$rr7_root/test_pamf_bridge.cpp" "$rr7_root/port/pamf_bridge.cpp" \
  -o "$rr7_root/test_pamf_bridge"
"$rr7_root/test_pamf_bridge" "$rr7_root/game/PS3_GAME/USRDIR/title.pam"
