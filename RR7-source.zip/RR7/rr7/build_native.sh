#!/bin/zsh
# Rebuild the existing local development checkout. This is not an installer.
set -eu
rr7_root="${0:A:h}"
rr7_cmake="$rr7_root/.venv312/bin/cmake"
"$rr7_cmake" -S "$rr7_root/port" -B "$rr7_root/build" -G Ninja \
  -DCMAKE_BUILD_TYPE=Release \
  '-DCMAKE_CXX_FLAGS_RELEASE=-O1 -DNDEBUG' \
  '-DCMAKE_C_FLAGS_RELEASE=-O2 -DNDEBUG' \
  -DCMAKE_MAKE_PROGRAM="$rr7_root/.venv312/bin/ninja" \
  -DPython3_EXECUTABLE="$rr7_root/.venv312/bin/python" \
  -DPS3RECOMP_DIR="$rr7_root/../ps3recomp" \
  -DPORT_SPU_INPUTS="$rr7_root/EBOOT.ELF" \
  -DPS3RECOMP_FFMPEG_RUNTIME=ON \
  -DPS3RECOMP_FFMPEG_INCLUDE_DIR="$rr7_root/deps-prefix/include" \
  -DRR7_AVCODEC="$rr7_root/deps-prefix-av/lib/libavcodec.dylib" \
  -DRR7_AVUTIL="$rr7_root/deps-prefix-av/lib/libavutil.dylib" \
  -DSDL2_DIR="$rr7_root/deps/SDL2.framework/Resources/CMake" \
  -DCMAKE_PREFIX_PATH="$rr7_root/deps-prefix"
"$rr7_cmake" --build "$rr7_root/build" -j 2
