/* Exercise the existing full NEON-vs-exact test with FPCR configured exactly
 * as a native SPU run. Restore the host caller mode on exit. */
#define main rr7_float_vectors_main
#include "../ps3recomp/runtime/spu/tests/test_spu_float_neon.c"
#undef main
int main(void){
 uint64_t saved;__asm__ volatile("mrs %0, fpcr":"=r"(saved));
 const uint64_t rz=SPU_FPCR_RZFZ;__asm__ volatile("msr fpcr, %0"::"r"(rz));
 int rc=rr7_float_vectors_main();
 __asm__ volatile("msr fpcr, %0"::"r"(saved));return rc;
}
