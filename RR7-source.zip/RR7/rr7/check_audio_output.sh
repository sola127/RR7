#!/bin/zsh
# Test the real mixer and SDL queue adapter without playing sound.
set -eu
rr7_root="${0:A:h}"
rr7_sdk="$rr7_root/../ps3recomp"
for rr7_case in ring output output_stress; do
  clang -std=gnu17 -O1 -g -fsanitize=address,undefined \
    -I "$rr7_sdk/include" -F "$rr7_root/deps" \
    "$rr7_sdk/libs/audio/tests/test_audio_$rr7_case.c" \
    -framework SDL2 -Wl,-rpath,"$rr7_root/deps" -Wl,-dead_strip \
    -o "$rr7_root/analysis/test_audio_$rr7_case"
  "$rr7_root/analysis/test_audio_$rr7_case"
done
