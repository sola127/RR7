/* Compare the SDK's native multichannel decoder against FFmpeg 8.0.1. */
extern "C" {
#include <libavcodec/avcodec.h>
#include "../ps3recomp/third_party/at3_standalone/at3_bridge.h"
}
#include <vector>
#include <cstdio>
#include <cassert>
#include <cmath>
#include <cstring>
#include <algorithm>
static unsigned le32(const unsigned char*p){return p[0]|p[1]<<8|p[2]<<16|unsigned(p[3])<<24;}
static unsigned le16(const unsigned char*p){return p[0]|p[1]<<8;}
int main(int argc,char**argv){
 assert(argc==2);FILE*f=fopen(argv[1],"rb");assert(f);fseek(f,12288,SEEK_SET);
 std::vector<unsigned char>b(1024*1024);assert(fread(b.data(),1,b.size(),f)==b.size());fclose(f);
 unsigned ch=0,ba=0,at=12;
 while(at+8<b.size()){
  if(!memcmp(b.data()+at,"fmt ",4)){ch=le16(b.data()+at+10);ba=le16(b.data()+at+20);}
  if(!memcmp(b.data()+at,"data",4)){at+=8;break;}
  at+=8+le32(b.data()+at+4);
 }
 assert(ch==6&&ba&&at+256*ba<b.size());
 int align=int(ba);void* standalone=at3p_open(int(ch),&align);assert(standalone);
 const AVCodec* codec=avcodec_find_decoder(AV_CODEC_ID_ATRAC3P);assert(codec);
 AVCodecContext*c=avcodec_alloc_context3(codec);assert(c);c->sample_rate=48000;c->block_align=int(ba);av_channel_layout_default(&c->ch_layout,int(ch));assert(!avcodec_open2(c,codec,nullptr));
 AVPacket*p=av_packet_alloc();AVFrame*r=av_frame_alloc();assert(p&&r);
 float data[8][2048];float*planes[8];for(unsigned k=0;k<ch;k++)planes[k]=data[k];
 double error[8]={},energy[8]={},maxerr=0;
 for(unsigned frame=0;frame<256;frame++){
  int samples=0;assert(at3p_decode_planar(standalone,planes,int(ch),&samples,b.data()+at+frame*ba,int(ba))>=0&&samples==2048);
  assert(!av_new_packet(p,int(ba)));memcpy(p->data,b.data()+at+frame*ba,ba);assert(!avcodec_send_packet(c,p));av_packet_unref(p);assert(!avcodec_receive_frame(c,r));assert(r->format==AV_SAMPLE_FMT_FLTP&&r->nb_samples==2048&&r->ch_layout.nb_channels==int(ch));
  for(unsigned k=0;k<ch;k++)for(int i=0;i<2048;i++){
   const double ref=((float*)r->extended_data[k])[i],got=data[k][i],d=got-ref;assert(std::isfinite(got));
   error[k]+=d*d;energy[k]+=ref*ref;maxerr=std::max(maxerr,std::abs(d));
  }
  av_frame_unref(r);
 }
 for(unsigned k=0;k<ch;k++){printf("channel %u relative RMS error %.7g (energy %.2f)\n",k,sqrt(error[k]/energy[k]),energy[k]);assert(sqrt(error[k]/energy[k])<0.001);}
 printf("ATRAC reference PASS: 256 frames, 6 channels; max absolute error %.7g\n",maxerr);
 at3p_close(standalone);avcodec_free_context(&c);av_packet_free(&p);av_frame_free(&r);
}
