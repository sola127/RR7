#!/bin/zsh
# Exact SPU arithmetic in both native ARM64 modes, plus caller-mode restoration.
set -eu
rr7_root="${0:A:h}"
rr7_sdk="$rr7_root/../ps3recomp"
for rr7_mode in default rz; do
  rr7_source="$rr7_sdk/runtime/spu/tests/test_spu_float_neon.c"
  if [[ "$rr7_mode" == rz ]]; then
    rr7_source="$rr7_root/test_spu_float_rz_vectors.c"
  fi
  clang -std=gnu17 -O2 -ffp-contract=off \
    -I "$rr7_sdk/runtime/spu" -I "$rr7_sdk/include" \
    "$rr7_source" -o "$rr7_root/analysis/test_spu_float_$rr7_mode"
  "$rr7_root/analysis/test_spu_float_$rr7_mode"
done
# The fixture supplies link-only abort boundaries for services its leaf code
# never executes; production SDK supplies the actual run/halt and nesting paths.
clang -std=gnu17 -O1 -g -fsanitize=address,undefined \
  -I "$rr7_sdk/runtime/spu" -I "$rr7_sdk/include" -I "$rr7_sdk/runtime" \
  -c "$rr7_sdk/runtime/spu/tests/test_spu_float_rz_mode.c" \
  -o "$rr7_root/analysis/test_spu_float_rz_mode.o"
clang++ -fsanitize=address,undefined "$rr7_root/analysis/test_spu_float_rz_mode.o" \
  "$rr7_root/build/ps3recomp_sdk/libps3recomp_runtime.a" -F "$rr7_root/deps" \
  -framework SDL2 -framework Metal -framework MetalFX -framework QuartzCore \
  -framework AppKit -framework IOKit -framework CoreFoundation \
  -Wl,-rpath,"$rr7_root/deps" -Wl,-dead_strip -o "$rr7_root/analysis/test_spu_float_rz_mode"
SPU_FLOAT_RZ=0 "$rr7_root/analysis/test_spu_float_rz_mode"
SPU_FLOAT_RZ=1 "$rr7_root/analysis/test_spu_float_rz_mode"
