#include "port/pamf_video.hpp"
#include <cassert>
#include <fstream>
#include <iostream>
struct Digest {uint64_t bytes=0,units=0,hash=14695981039346656037ull;};
static Digest read(rr7::PamfVideo& video,const char* path,size_t chunk){
    Digest d;std::ifstream f(path,std::ios::binary);assert(f);f.seekg(2048);
    std::vector<uint8_t> b(chunk);bool first=true;
    auto emit=[&](rr7::VideoAu au){assert(!au.bytes.empty());assert(au.pts>=-1&&au.dts>=-1);
        if(first){assert(au.pts==90000);first=false;}
        d.units++;d.bytes+=au.bytes.size();
        for(uint8_t x:au.bytes){d.hash^=x;d.hash*=1099511628211ull;}
        // Hash metadata and unit boundaries as well as the elementary bytes.
        for(uint64_t x:{uint64_t(au.pts),uint64_t(au.dts),uint64_t(au.bytes.size())}){
            for(int i=0;i<8;i++){d.hash^=uint8_t(x>>(i*8));d.hash*=1099511628211ull;}
        }
    };
    while(f){f.read((char*)b.data(),b.size());video.feed(b.data(),size_t(f.gcount()),emit);}
    video.feed(nullptr,0,emit,true);assert(d.units>800&&d.bytes>70000000);
    bool rejected=false;try{video.feed(nullptr,0,emit);}catch(const std::runtime_error&){rejected=true;}assert(rejected);
    std::cout<<"chunk="<<chunk<<" units="<<d.units<<" bytes="<<d.bytes<<" metadataHash="<<d.hash<<" PASS\n";return d;
}
int main(int argc,char** argv){
    assert(argc==2);rr7::PamfVideo video;Digest expected=read(video,argv[1],65536);
    for(size_t chunk:{size_t(7),size_t(2048),size_t(32771)}){
        video.reset();Digest d=read(video,argv[1],chunk);
        assert(d.units==expected.units&&d.bytes==expected.bytes&&d.hash==expected.hash);
    }
    std::cout<<"owned video access units, timestamps, reset and EOF PASS\n";
}
