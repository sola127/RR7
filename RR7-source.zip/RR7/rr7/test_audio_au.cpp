#include "port/pamf_audio.hpp"
#include <cassert>
#include <fstream>
#include <cstdio>
#include <cmath>
int main(int argc,char** argv){
    assert(argc==2);uint64_t reference=0,referenceCount=0;
    for(size_t chunk:{size_t(65536),size_t(7),size_t(2048)}){
        rr7::PamfPes ps;rr7::PamfAudio audio;std::ifstream f(argv[1],std::ios::binary);assert(f);f.seekg(2048);
        std::vector<uint8_t> buffer(chunk);uint64_t hash=14695981039346656037ull,count=0,decoded=0;double energy=0;
        const AVCodec* decoder=avcodec_find_decoder(AV_CODEC_ID_ATRAC3P);assert(decoder);
        AVCodecContext* ctx=avcodec_alloc_context3(decoder);assert(ctx);
        ctx->block_align=1712;ctx->sample_rate=48000;ctx->ch_layout=AV_CHANNEL_LAYOUT_5POINT1_BACK;
        assert(avcodec_open2(ctx,decoder,nullptr)==0);
        AVPacket* packet=av_packet_alloc();AVFrame* frame=av_frame_alloc();assert(packet&&frame);
        auto emit=[&](rr7::VideoAu au){
            assert(au.bytes.size()==1720&&au.pts>=0);count++;
            for(uint8_t b:au.bytes){hash^=b;hash*=1099511628211ull;}
            for(int i=0;i<8;i++){hash^=uint8_t(uint64_t(au.pts)>>(8*i));hash*=1099511628211ull;}
            if(chunk==65536&&count<64){
                assert(av_new_packet(packet,1712)==0);memcpy(packet->data,au.bytes.data()+8,1712);
                assert(avcodec_send_packet(ctx,packet)==0);av_packet_unref(packet);
                while(avcodec_receive_frame(ctx,frame)==0){
                    assert(frame->ch_layout.nb_channels==6&&frame->sample_rate==48000&&frame->nb_samples==2048);
                    assert(frame->format==AV_SAMPLE_FMT_FLTP);
                    for(int c=0;c<6;c++)for(int i=0;i<frame->nb_samples;i++){
                        float v=((float*)frame->extended_data[c])[i];assert(std::isfinite(v));energy+=v*v;
                    }
                    decoded++;av_frame_unref(frame);
                }
            }
        };
        auto pes=[&](const rr7::PesPayload& p){audio.packet(p,emit);};
        while(f){f.read((char*)buffer.data(),buffer.size());ps.feed(buffer.data(),size_t(f.gcount()),pes);}
        ps.feed(nullptr,0,pes,true);audio.finish();
        if(chunk==65536){reference=hash;referenceCount=count;assert(decoded==63&&energy>1);}
        else assert(hash==reference&&count==referenceCount);
        printf("ATRAC3plus AU chunk=%zu count=%llu hash=%llu decoded=%llu energy=%g\n",chunk,(unsigned long long)count,(unsigned long long)hash,(unsigned long long)decoded,energy);
        av_packet_free(&packet);av_frame_free(&frame);avcodec_free_context(&ctx);
    }
    puts("PAMF audio access-unit boundaries, PTS chunk invariance and native 6-channel PCM PASS");
}
