/* Exercise the real mixer across ring wraps, without starting a device/thread.
 * macOS: clang -std=gnu17 -I include -I /opt/homebrew/include
 *   libs/audio/tests/test_audio_ring.c -L /opt/homebrew/lib -lSDL2
 *   -Wl,-dead_strip -o /tmp/test_audio_ring && /tmp/test_audio_ring
 */
#include "../ps3recomp/libs/audio/cellAudio.c"
#include <assert.h>

uint8_t* vm_base;
uint32_t ppu_vm_size;
int g_resv_store_active;
uint32_t g_ww_lo, g_ww_hi;
void ppu_resv_break_store(uint64_t ea) { (void)ea; }
void ps3_ww_report_inline(uint32_t a, uint64_t v, int w) { (void)a; (void)v; (void)w; }
int spu_coh_is_reserved(uint32_t a) { (void)a; return 0; }
void spu_coh_notify_write(uint32_t a) { (void)a; }
void spu_lockline_lock(void) {}
void spu_lockline_unlock(void) {}

int main(int argc,char**argv){assert(argc==3);setenv("PS3_MASTER_VOLUME",argv[1],1);float expected=atof(argv[2]);
mutex_init(&s_audio_mutex);float pcm[8*256*2]={0};
for(unsigned i=0;i<256*2;i++){float f=i%2?-.5f:.5f;u32 bits;memcpy(&bits,&f,4);((u32*)pcm)[i]=__builtin_bswap32(bits);}
AudioPortSlot*p=&s_ports[0];p->in_use=p->running=1;p->buffer=pcm;p->param.nBlock=8;p->param.nChannel=2;p->param.level=1;
audio_mix_one_block();for(unsigned i=0;i<512;i++)assert(fabsf(s_mix_buffer[i]-(i%2?-expected:expected))<1e-6);
assert(p->read_index==1);for(unsigned i=0;i<512;i++)assert(pcm[i]==0);puts("real mixer master volume and guest lifecycle PASS");}
