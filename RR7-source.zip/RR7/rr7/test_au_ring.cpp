#include "port/guest_au_ring.hpp"
#include <cassert>
#include <iostream>
#include <thread>
static uint32_t r32(const std::vector<uint8_t>& m,uint32_t p){return uint32_t(m[p])<<24|uint32_t(m[p+1])<<16|uint32_t(m[p+2])<<8|m[p+3];}
int main(){
    std::vector<uint8_t> memory(0x20000,0xa5);constexpr uint32_t base=0x10000;
    rr7::GuestAuRing ring(memory.data(),base,0x4000);
    assert(!ring.get()&&!ring.peek()&&!ring.release());
    for(uint8_t i=1;i<=4;i++)assert(ring.push(&i,1,90000+i,-1,0x1122334455667788ull,i==1));
    uint8_t x=5;assert(!ring.push(&x,1,90005,-1,0,false));
    auto first=ring.peek();assert(first&&*first==base);assert(ring.peek()==first);
    assert(r32(memory,base)==base+128&&r32(memory,base+4)==1&&memory[base+12]==1);
    assert(r32(memory,base+16)==0x11223344&&r32(memory,base+20)==0x55667788);
    assert(r32(memory,base+24)==0&&r32(memory,base+28)==90001);
    assert(r32(memory,base+32)==0xffffffff&&r32(memory,base+36)==0xffffffff);
    assert(ring.get()==first);auto second=ring.get();assert(second&&*second==base+0x1000);
    assert(!ring.push(&x,1,90005,-1,0,false)); // Get alone does not free storage.
    assert(ring.release());assert(ring.push(&x,1,90005,-1,0,false));
    assert(memory[*second+128]==2); // An acquired neighbor cannot be overwritten.
    assert(ring.release());assert(!ring.release());
    for(uint8_t expected:{3,4,5}){
        auto at=ring.get();assert(at&&memory[*at+128]==expected);assert(ring.release());
    }
    assert(!ring.get());
    std::vector<uint8_t> oversized(ring.maximum_payload()+1,7);
    assert(!ring.push(oversized.data(),oversized.size(),0,0,0,false));assert(!ring.peek());
    assert(memory[base-1]==0xa5&&memory[base+0x4000]==0xa5);
    assert(ring.push(&x,1,0,0,0,false));ring.reset();assert(!ring.peek()&&!ring.release());
    // Concurrent producer/consumer: acquired bytes remain stable until release.
    std::thread producer([&]{for(uint32_t i=0;i<10000;i++){
        uint8_t payload[]={uint8_t(i>>24),uint8_t(i>>16),uint8_t(i>>8),uint8_t(i)};
        while(!ring.push(payload,4,i,i,i,false))std::this_thread::yield();
    }});
    for(uint32_t i=0;i<10000;i++){
        std::optional<uint32_t> at;while(!(at=ring.get()))std::this_thread::yield();
        assert(r32(memory,r32(memory,*at))==i);std::this_thread::yield();
        assert(r32(memory,r32(memory,*at))==i);assert(ring.release());
    }
    producer.join();assert(!ring.get()&&!ring.release());
    std::cout<<"Guest AU ring ABI, ownership, wrap, backpressure and canaries PASS\n";
}
