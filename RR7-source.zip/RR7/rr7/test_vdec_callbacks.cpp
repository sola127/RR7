#include "ppu_recomp.h"
#include "../ps3recomp/libs/codec/cellVdec.h"
#include "ps3emu/guest_call.h"
#include <cassert>
#include <atomic>
#include <chrono>
#include <thread>
#include <unordered_map>
#include <cstdio>
extern "C" void rr7_register_vdec_bridge();
static std::unordered_map<uint32_t,void(*)(ppu_context*)> functions;
uint8_t* vm_base;
extern "C" uint32_t vm_read32(uint64_t p){return uint32_t(vm_base[p])<<24|uint32_t(vm_base[p+1])<<16|uint32_t(vm_base[p+2])<<8|vm_base[p+3];}
extern "C" void ps3_hle_register_ctx(uint32_t n,const char*,void(*f)(ppu_context*)){functions[n]=f;}
CellVdecCallbackDispatch cellVdecCallbackDispatchHook=nullptr;
static std::atomic<int> closes{0},calls{0},maximumDepth{0};
static std::atomic<bool> done{false};
extern "C" s32 cellVdecOpen(const CellVdecType*,const CellVdecResource*,const CellVdecCb*,CellVdecHandle* out){
    uint32_t p=uint32_t(uintptr_t(out));vm_base[p]=vm_base[p+1]=vm_base[p+2]=0;vm_base[p+3]=1;return 0;
}
extern "C" s32 cellVdecClose(CellVdecHandle h){assert(h==1);closes++;return 0;}
extern "C" s32 cellVdecStartSeq(CellVdecHandle h){assert(h==1);return 0;}
extern "C" s32 cellVdecDecodeAuHost(CellVdecHandle,s32,const CellVdecAuInfo*){return 0;}
extern "C" s32 cellVdecEndSeq(CellVdecHandle){return 0;}
static void command(uint32_t nid){ppu_context c={};c.gpr[3]=1;functions.at(nid)(&c);assert(uint32_t(c.gpr[3])==0);}
static void open(){ppu_context c={};c.gpr[6]=0x10000;functions.at(0xB6BBCD5D)(&c);assert(c.gpr[3]==0&&vm_read32(0x10000)==1);}
static void wait_done(){auto end=std::chrono::steady_clock::now()+std::chrono::seconds(5);
    while(!done.load(std::memory_order_acquire)){assert(std::chrono::steady_clock::now()<end);std::this_thread::yield();}}
static void callback(uint32_t opd,uint64_t handle,uint64_t kind,uint64_t,uint64_t arg,uint64_t,uint64_t,uint64_t,uint64_t){
    assert(opd==0x1234&&handle==1&&arg==0xcafe);static thread_local int depth=0;
    depth++;maximumDepth.store(std::max(maximumDepth.load(),depth));
    if(kind==0){int n=++calls;if(n<50000)cellVdecCallbackDispatchHook(1,0x1234,0,0,0xcafe);else done.store(true,std::memory_order_release);}
    if(kind==2){command(0x16698E83);done.store(true,std::memory_order_release);}
    depth--;
}
ps3_guest_caller_fn g_ps3_guest_caller=callback;
int main(){
    uint8_t memory[0x11000]={};vm_base=memory;rr7_register_vdec_bridge();open();command(0xC757C2AA);
    cellVdecCallbackDispatchHook(1,0x1234,0,0,0xcafe);wait_done();command(0x16698E83);
    assert(calls==50000&&maximumDepth==1&&closes==1);
    done=false;open();cellVdecCallbackDispatchHook(1,0x1234,2,0,0xcafe);wait_done();
    assert(closes==2);cellVdecCallbackDispatchHook(1,0x1234,0,0,0xcafe);assert(calls==50000);
    puts("50000 chained callback notifications without recursion; external close, callback close and handle reuse PASS");
}
