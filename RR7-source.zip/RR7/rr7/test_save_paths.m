#import <Foundation/Foundation.h>
#include <assert.h>
#include "port/save_paths.m"
int main(){@autoreleasepool{
NSFileManager*f=NSFileManager.defaultManager;NSString*b=[NSTemporaryDirectory() stringByAppendingPathComponent:NSUUID.UUID.UUIDString];
NSString*s=[b stringByAppendingPathComponent:@"source"],*d=[b stringByAppendingPathComponent:@"destination"];
[f createDirectoryAtPath:[s stringByAppendingPathComponent:@"dev_hdd0"] withIntermediateDirectories:YES attributes:nil error:NULL];
NSString*sf=[s stringByAppendingPathComponent:@"dev_hdd0/GAME"],*df=[d stringByAppendingPathComponent:@"dev_hdd0/GAME"];
[@"source-progress" writeToFile:sf atomically:YES encoding:NSUTF8StringEncoding error:NULL];NSError*e=nil;
assert(rr7_prepare_save_root(d,s,&e));assert([[NSString stringWithContentsOfFile:df encoding:NSUTF8StringEncoding error:NULL] isEqual:@"source-progress"]);
[@"destination-progress" writeToFile:df atomically:YES encoding:NSUTF8StringEncoding error:NULL];
assert(rr7_prepare_save_root(d,s,&e));assert([[NSString stringWithContentsOfFile:df encoding:NSUTF8StringEncoding error:NULL] isEqual:@"destination-progress"]);
assert([[NSString stringWithContentsOfFile:sf encoding:NSUTF8StringEncoding error:NULL] isEqual:@"source-progress"]);
assert(!rr7_prepare_save_root([s stringByAppendingPathComponent:@"nested"],s,&e));
NSString*bad=[b stringByAppendingPathComponent:@"occupied"];[f createDirectoryAtPath:bad withIntermediateDirectories:YES attributes:nil error:NULL];
[@"keep" writeToFile:[bad stringByAppendingPathComponent:@"unrelated"] atomically:YES encoding:NSUTF8StringEncoding error:NULL];
assert(!rr7_prepare_save_root(bad,s,&e));assert([f fileExistsAtPath:[bad stringByAppendingPathComponent:@"unrelated"]]);
assert(!rr7_prepare_save_root([b stringByAppendingPathComponent:@"RR7.app/Contents/Save"],s,&e));
NSString*empty=[b stringByAppendingPathComponent:@"empty"];[f createDirectoryAtPath:empty withIntermediateDirectories:YES attributes:nil error:NULL];assert(rr7_prepare_save_root(empty,s,&e));
[f removeItemAtPath:b error:NULL];puts("save migration copy, existing-profile preservation, overlap and foreign-folder guards PASS");}}
