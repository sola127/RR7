#!/bin/zsh
set -eu
rr7_root="${0:A:h}"
cd "$rr7_root"
clang -std=gnu17 -O1 -g -fsanitize=address,undefined -I../ps3recomp/include \
  -c test_atrac_stream.c -o analysis/test_atrac_stream.o
clang++ -fsanitize=address,undefined analysis/test_atrac_stream.o \
  build/ps3recomp_sdk/libps3recomp_runtime.a -Wl,-dead_strip -o analysis/test_atrac_stream
analysis/test_atrac_stream game/PS3_GAME/USRDIR/BGM.nub
clang++ -std=c++17 -O1 -g -fsanitize=address,undefined -Ideps-prefix-av/include \
  test_atrac_reference.cpp build/ps3recomp_sdk/libps3recomp_runtime.a \
  -Wl,-dead_strip -Ldeps-prefix-av/lib -lavcodec -lavutil -o analysis/test_atrac_reference
analysis/test_atrac_reference game/PS3_GAME/USRDIR/BGM.nub
