#include "ppu_recomp.h"
#include "ps3emu/guest_call.h"
#include <cassert>
#include <cstdio>
#include <vector>
#include <unordered_map>
#include <initializer_list>
#include <atomic>
#include <chrono>
#include <thread>
#include <fstream>
extern "C" void rr7_register_dmux_bridge();
uint8_t* vm_base=nullptr;
constexpr uint32_t MemorySize=32*1024*1024;
static std::unordered_map<uint32_t,void(*)(ppu_context*)> functions;
extern "C" void ps3_hle_register_ctx(uint32_t n,const char*,void(*f)(ppu_context*)){functions[n]=f;}
extern "C" uint8_t vm_read8(uint64_t p){assert(p<MemorySize);return vm_base[p];}
extern "C" uint16_t vm_read16(uint64_t p){return uint16_t(vm_read8(p))<<8|vm_read8(p+1);}
extern "C" uint32_t vm_read32(uint64_t p){return uint32_t(vm_read16(p))<<16|vm_read16(p+2);}
extern "C" uint64_t vm_read64(uint64_t p){return uint64_t(vm_read32(p))<<32|vm_read32(p+4);}
extern "C" void vm_write8(uint64_t p,uint8_t v){assert(p<MemorySize);vm_base[p]=v;}
extern "C" void vm_write16(uint64_t p,uint16_t v){vm_write8(p,v>>8);vm_write8(p+1,v);}
extern "C" void vm_write32(uint64_t p,uint32_t v){vm_write16(p,v>>16);vm_write16(p+2,v);}
extern "C" void vm_write64(uint64_t p,uint64_t v){vm_write32(p,v>>32);vm_write32(p+4,v);}
static uint32_t call(uint32_t n,std::initializer_list<uint64_t> args){ppu_context c={};int i=3;for(auto a:args)c.gpr[i++]=a;functions.at(n)(&c);return uint32_t(c.gpr[3]);}
static std::atomic<uint64_t> done{0},endCodes{0},units{0};
static uint64_t bytes=0,hash=14695981039346656037ull;
static uint32_t demuxHandle=0,esHandle=0;
static uint64_t audioUnits=0,audioBytes=0,audioHash=14695981039346656037ull;
static void callback(uint32_t opd,uint64_t a0,uint64_t a1,uint64_t a2,uint64_t a3,uint64_t,uint64_t,uint64_t,uint64_t){
    assert(a0==demuxHandle);
    if(opd==0x1000){
        assert(a2==0xd00d);uint32_t kind=vm_read32(a1);
        if(kind==0)done.fetch_add(1,std::memory_order_release);
        else if(kind==2)endCodes++;
        else{fprintf(stderr,"fatal demux callback %08X\n",uint32_t(vm_read64(a1+8)));assert(false);}
    }else{
        bool isAudio=opd==0x1020;
        assert((opd==0x1010||isAudio)&&a1==(isAudio?0x600000:esHandle)&&a3==0xe00e&&vm_read32(a2)==0);
        if(isAudio){
            assert(call(0x42C716B5,{0x600000,0x10410,0x10414})==0);
            uint32_t desc=vm_read32(0x10410),data=vm_read32(desc),size=vm_read32(desc+4);
            assert(size==1720&&vm_read16(data)==0x0fd0);audioUnits++;audioBytes+=size;
            for(uint32_t i=0;i<size;i++){audioHash^=vm_read8(data+i);audioHash*=1099511628211ull;}
            uint64_t pts=vm_read64(desc+24);for(int i=0;i<8;i++){audioHash^=uint8_t(pts>>(8*i));audioHash*=1099511628211ull;}
            assert(call(0x24EA6474,{0x600000})==0);return;
        }
        assert(call(0x42C716B5,{esHandle,0x10400,0x10404})==0);
        uint32_t desc=vm_read32(0x10400),data=vm_read32(desc),size=vm_read32(desc+4);
        assert(vm_read32(0x10404)==0&&size&&size<=vm_read32(desc+8));
        bytes+=size;
        for(uint32_t i=0;i<size;i++){hash^=vm_read8(data+i);hash*=1099511628211ull;}
        for(uint64_t x:{vm_read64(desc+24),vm_read64(desc+32),uint64_t(size)})for(int i=0;i<8;i++){
            hash^=uint8_t(x>>(i*8));hash*=1099511628211ull;
        }
        assert(call(0x24EA6474,{esHandle})==0);units++;
    }
}
ps3_guest_caller_fn g_ps3_guest_caller=callback;
int main(int argc,char**argv){
    assert(argc==2);std::vector<uint8_t> memory(MemorySize,0xa5);vm_base=memory.data();rr7_register_dmux_bridge();
    constexpr uint32_t type=0x10000,res=0x10100,cb=0x10200,out=0x10300,filter=0x10500;
    vm_write32(type,1);assert(call(0xA2D4189B,{type,out})==0);assert(vm_read32(out)==0x10000);
    vm_write32(res,0x20000);vm_write32(res+4,0x10000);vm_write32(cb,0x1000);vm_write32(cb+4,0xd00d);
    assert(call(0x68492DE9,{type,res,cb,out})==0);demuxHandle=vm_read32(out);assert(demuxHandle==0x20100);
    vm_write32(filter,0xe0);vm_write32(filter+4,0);vm_write32(filter+8,0);vm_write32(filter+12,0);
    assert(call(0x02170D1A,{type,filter,0,out})==0);assert(vm_read32(out)==0x400100);
    vm_write32(res,0x100000);vm_write32(res+4,0x400100);vm_write32(cb,0x1010);vm_write32(cb+4,0xe00e);
    assert(call(0x7B56DC3F,{demuxHandle,filter,res,cb,0,out})==0);esHandle=vm_read32(out);
    assert(call(0x42C716B5,{esHandle,out,0})==0x80610204);
    vm_write32(0x10600,0xbd);vm_write32(0x10604,0);vm_write32(0x10608,0);vm_write32(0x1060c,0);
    assert(call(0x02170D1A,{type,0x10600,0,out})==0&&vm_read32(out)==0x100100);
    vm_write32(res,0x600000);vm_write32(res+4,0x100100);vm_write32(cb,0x1020);
    assert(call(0x7B56DC3F,{demuxHandle,0x10600,res,cb,0,out})==0&&vm_read32(out)==0x600000);
    std::ifstream f(argv[1],std::ios::binary);assert(f);f.seekg(2048);uint64_t submitted=0;
    while(f){
        f.read((char*)vm_base+0x800000,65536);uint32_t n=uint32_t(f.gcount());if(!n)break;
        assert(call(0x04E7499F,{demuxHandle,0x800000,n,submitted==0,submitted})==0);submitted++;
        auto deadline=std::chrono::steady_clock::now()+std::chrono::seconds(5);
        while(done.load(std::memory_order_acquire)<submitted){assert(std::chrono::steady_clock::now()<deadline);std::this_thread::yield();}
    }
    assert(call(0x8C692521,{demuxHandle})==0);
    printf("dmux bridge: units=%llu bytes=%llu metadataHash=%llu endCodes=%llu\n",(unsigned long long)units.load(),(unsigned long long)bytes,(unsigned long long)hash,(unsigned long long)endCodes.load());
    assert(bytes>0&&units>1500);
    printf("audio units=%llu bytes=%llu hash=%llu\n",(unsigned long long)audioUnits,(unsigned long long)audioBytes,(unsigned long long)audioHash);
    assert(audioUnits==1254&&audioBytes==1254*1720&&audioHash==16976360637148126889ull);
    assert(memory[0x5fffff]==0xa5&&memory[0x700100]==0xa5);assert(memory[0xfffff]==0xa5&&memory[0x500100]==0xa5);
    assert(call(0x42C716B5,{esHandle,out,0})==0x80610201);
    puts("real two-stream PAMF through guest cellDmux SDK, ATRAC3plus routing, callbacks, ownership and close PASS");
}
