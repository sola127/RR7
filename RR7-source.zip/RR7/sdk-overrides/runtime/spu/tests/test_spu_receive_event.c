/* Bind an actual LV2 SPU queue, block the lifted service, and wake it from
 * a producer. Also cover routing, duplicate bindings and queue teardown. */
#include "../../syscalls/lv2_register.c"
#include <assert.h>
#include <pthread.h>
#include <stdatomic.h>
#include <unistd.h>

uint8_t* vm_base;
uint32_t ppu_vm_size;
static spu_context spu;
static atomic_int done;

static uint32_t call(int64_t (*fn)(ppu_context*), uint32_t a, uint32_t b, uint32_t c)
{
    ppu_context ctx = {0}; ctx.gpr[3]=a; ctx.gpr[4]=b; ctx.gpr[5]=c;
    return (uint32_t)fn(&ctx);
}
static void* receive(void* unused)
{
    (void)unused;
    assert(spu_receive_event(&spu) == 1);
    atomic_store(&done, 1);
    return NULL;
}
static void start_receive(pthread_t* worker, uint32_t number)
{
    spu.rcv_evt_n = spu.rcv_evt_i = 0;
    spu_channel_write(&spu.ch_out_mbox, number);
    atomic_store(&done, 0);
    assert(!pthread_create(worker, NULL, receive, NULL));
    usleep(20000);
    assert(!atomic_load(&done));
}
int main(void)
{
    spu_thread_t* t = spu_alloc_thread(); assert(t);
    spu.spu_id = t->tid; spu.spu_group_id = t->group_id = 0x1000;
    uint32_t q = sys_event_queue_create_direct(0, 8); assert(q);
    uint32_t other = sys_event_queue_create_direct(0, 8); assert(other);
    assert(call(sys_spu_thread_bind_queue_handler,t->tid,q,0x6e754153) == CELL_EINVAL);
    g_sys_event_queues[q-1].type = SYS_SPU_QUEUE;
    g_sys_event_queues[other-1].type = SYS_SPU_QUEUE;
    assert(call(sys_spu_thread_bind_queue_handler,t->tid,q,0x6e754153) == CELL_OK);
    assert(call(sys_spu_thread_bind_queue_handler,t->tid,q,123) == CELL_EBUSY);
    assert(call(sys_spu_thread_bind_queue_handler,t->tid,other,0x6e754153) == CELL_EBUSY);
    pthread_t worker; start_receive(&worker,0x6e754153);
    /* An event on another queue must not wake this worker. */
    assert(!sys_event_queue_push_by_id(other,0,1,2,3));
    usleep(10000); assert(!atomic_load(&done));
    assert(!sys_event_queue_push_by_id(q,99,0x1234567887654321ull,0xabcd,0xface));
    pthread_join(worker,NULL);
    assert(spu.rcv_evt_n == 4 && spu.rcv_evt[0] == CELL_OK);
    assert(spu.rcv_evt[1] == 0x87654321 && spu.rcv_evt[2] == 0xabcd && spu.rcv_evt[3] == 0xface);
    assert(spu.ch_out_mbox.count == 0 && g_sys_event_queues[q-1].count == 0);
    start_receive(&worker,0x6e754153);
    assert(call(sys_event_queue_destroy,q,0,0) == CELL_EBUSY);
    assert(call(sys_event_queue_destroy,q,SYS_EVENT_QUEUE_DESTROY_FORCE,0) == CELL_OK);
    pthread_join(worker,NULL);
    assert(spu.rcv_evt_n == 1 && spu.rcv_evt[0] == (uint32_t)CELL_ECANCELED);
    assert(call(sys_spu_thread_unbind_queue_handler,t->tid,0x6e754153,0) == CELL_OK);
    assert(call(sys_spu_thread_unbind_queue_handler,t->tid,0x6e754153,0) == CELL_ESRCH);
    spu.rcv_evt_n = 0; /* The guest consumed the cancellation reply. */
    spu_channel_write(&spu.ch_out_mbox,0x6e754153);
    assert(spu_receive_event(&spu) == 1);
    assert(spu.rcv_evt_n == 1 && spu.rcv_evt[0] == (uint32_t)CELL_EINVAL);
    puts("[spu_receive_event] PASS: binding, blocking, routing, payload and forced teardown");
    return 0;
}
