/* Actual SDL queued-audio recovery under two bounded host scheduling stalls.
 * No game threads or speaker: the dummy driver consumes the real SDL queue. */
#include "../cellAudio.c"
#include <assert.h>
uint8_t* vm_base;
uint32_t ppu_vm_size;
int g_resv_store_active;
uint32_t g_ww_lo,g_ww_hi;
void ppu_resv_break_store(uint64_t a){(void)a;abort();}
void ps3_ww_report_inline(uint32_t a,uint64_t v,int w){(void)a;(void)v;(void)w;abort();}
int spu_coh_is_reserved(uint32_t a){(void)a;abort();}
void spu_coh_notify_write(uint32_t a){(void)a;abort();}
void spu_lockline_lock(void){abort();}
void spu_lockline_unlock(void){abort();}
static uint64_t ns_now(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return (uint64_t)t.tv_sec*1000000000ull+t.tv_nsec;}
int main(void){
 SDL_setenv("SDL_AUDIODRIVER","dummy",1);
 assert(audio_backend_init()==0);
 uint64_t due=ns_now();
 for(unsigned tick=0;tick<500;tick++){
  if(tick==100||tick==300){SDL_Delay(60);due=ns_now();}
  while(ns_now()<due||!audio_backend_room())SDL_Delay(1);
  audio_backend_submit(s_mix_buffer,256);
  assert(s_ports[0].read_index==0);
  if(s_sdl_rebuffering)assert(SDL_GetAudioDeviceStatus(s_sdl_audio_dev)==SDL_AUDIO_PAUSED);
  due+=256000000000ull/48000;
  uint64_t now=ns_now();if(now>due+5333333ull)due=now;
 }
 for(unsigned i=0;s_sdl_rebuffering&&i<4;i++)audio_backend_submit(s_mix_buffer,256);
 assert(s_sdl_rebuffers>=2&&!s_sdl_rebuffering);
 assert(SDL_GetAudioDeviceStatus(s_sdl_audio_dev)==SDL_AUDIO_PLAYING);
 printf("actual SDL queue: recovered %u depletion(s) after two 60ms stalls; guest cursor untouched PASS\n",s_sdl_rebuffers);
 audio_backend_shutdown();SDL_QuitSubSystem(SDL_INIT_AUDIO);
}
