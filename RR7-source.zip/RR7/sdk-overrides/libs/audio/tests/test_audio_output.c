/* Device pulls 512 frames at a time while the console supplies 256. Verify
 * the production SDL backend primes the device without consuming guest PCM. */
#include <SDL2/SDL.h>
#include <assert.h>
#include <string.h>
static unsigned queued,started,closed,submissions,pauses,paused;
static int fail_queue;
static SDL_AudioDeviceID fake_open(const char*d,int capture,const SDL_AudioSpec*w,SDL_AudioSpec*h,int flags)
{ (void)d;(void)capture;(void)flags;*h=*w;h->samples=512;return 7; }
static int fake_queue(SDL_AudioDeviceID d,const void*p,Uint32 n)
{ assert(d==7);if(fail_queue)return -1;assert(n%8==0);if(!started){const float*f=p;for(unsigned i=0;i<n/4;i++)assert(f[i]==0);}
  queued+=n/8;submissions++;return 0; }
static Uint32 fake_size(SDL_AudioDeviceID d){assert(d==7);return queued*8;}
static void fake_pause(SDL_AudioDeviceID d,int pause){
 assert(d==7);
 if(pause){paused=1;pauses++;return;}
 assert(queued>=1024);paused=0;started++;
}
static void fake_close(SDL_AudioDeviceID d){assert(d==7);closed++;}
#define SDL_OpenAudioDevice fake_open
#define SDL_QueueAudio fake_queue
#define SDL_GetQueuedAudioSize fake_size
#define SDL_PauseAudioDevice fake_pause
#define SDL_CloseAudioDevice fake_close
#include "../cellAudio.c"
uint8_t* vm_base;
uint32_t ppu_vm_size;
int g_resv_store_active;
uint32_t g_ww_lo,g_ww_hi;
void ppu_resv_break_store(uint64_t a){(void)a;}
void ps3_ww_report_inline(uint32_t a,uint64_t v,int w){(void)a;(void)v;(void)w;}
int spu_coh_is_reserved(uint32_t a){(void)a;return 0;}
void spu_coh_notify_write(uint32_t a){(void)a;}
void spu_lockline_lock(void){}
void spu_lockline_unlock(void){}
int main(void)
{
  SDL_setenv("SDL_AUDIODRIVER","dummy",1);
  assert(audio_backend_init()==0&&started==1&&queued==1024&&submissions==1);
  assert(audio_backend_room()==0);assert(s_ports[0].read_index==0);
  for(unsigned tick=0;tick<4000;tick++){
    if(!(tick%2)){assert(queued>=512);queued-=512;}
    assert(audio_backend_room()==256);
    audio_backend_submit(s_mix_buffer,256);
    assert(queued>=512&&queued<=1024);
  }
  assert(s_sdl_empty_submissions==0&&s_ports[0].read_index==0);
  /* A host scheduling stall spends the entire lead. Recovery must wait for
   * four genuine producer periods, without racing the guest cursor ahead. */
  for(unsigned episode=0;episode<2;episode++){
    queued=0;
    for(unsigned block=0;block<4;block++){
      audio_backend_submit(s_mix_buffer,256);
      assert(queued==(block+1)*256);
      assert(paused==(block<3));
      assert(s_sdl_rebuffering==(block<3));
      assert(s_ports[0].read_index==0);
    }
    assert(pauses==episode+1&&started==episode+2);
    assert(s_sdl_empty_submissions==episode+1&&s_sdl_rebuffers==episode+1);
    for(unsigned tick=0;tick<400;tick++){
      if(!(tick%2))queued-=512;
      audio_backend_submit(s_mix_buffer,256);
      assert(queued>=512&&queued<=1024&&!paused);
    }
  }
  audio_backend_shutdown();assert(closed==1&&!s_sdl_audio_dev);
  started=queued=0;fail_queue=1;
  assert(audio_backend_init()==-1&&closed==2&&!s_sdl_audio_dev&&!started);
  /* Two explicit captures in one running process. Consuming the trigger
   * prevents an old request from immediately starting another capture. */
  char dir[]="/tmp/rr7-audio-output-XXXXXX";assert(mkdtemp(dir));
  char output[256],trigger[256];
  snprintf(output,sizeof output,"%s/mix.f32",dir);
  snprintf(trigger,sizeof trigger,"%s/trigger",dir);
  setenv("AUDIO_WAV",output,1);setenv("AUDIO_WAV_TRIGGER",trigger,1);setenv("AUDIO_WAV_SECONDS","1",1);
  for(unsigned take=0;take<2;take++){
    FILE* f=fopen(trigger,"wb");assert(f);fclose(f);
    s_mix_buffer[0]=(take+1)*0.125f;
    for(unsigned block=0;block<187;block++)audio_dump_mix();
    assert(access(trigger,F_OK)!=0);
    f=fopen(output,"rb");assert(f);float first;assert(fread(&first,4,1,f)==1);
    assert(first==s_mix_buffer[0]);fseek(f,0,SEEK_END);assert(ftell(f)==187*256*2*4);fclose(f);
    s_mix_buffer[0]=0.75f;audio_dump_mix(); /* no new trigger: no overwrite */
    f=fopen(output,"rb");assert(f);assert(fread(&first,4,1,f)==1);
    assert(first==(take+1)*0.125f);fclose(f);
  }
  remove(output);assert(rmdir(dir)==0);
  SDL_QuitSubSystem(SDL_INIT_AUDIO);
  puts("audio output: 4000 periods, two stall/rebuffer recoveries, guest cursor untouched, repeated capture, failure cleanup PASS");
}
