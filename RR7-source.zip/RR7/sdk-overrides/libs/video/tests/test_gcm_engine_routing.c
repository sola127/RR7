/* Fixture adapted from test_gcm_legacy_state_filter.c.
 * The FIFO walker hands rsx_state every subchannel-0 method only while
 * something reads that state: the vtable backend, or the walker without the
 * draw engine. With the draw engine up and no vtable, only the methods
 * rsx_process_method acts on beyond its state reach it (cellGcmSys.c,
 * gcm_legacy_method_has_effect). Subchannel 1 (not 2D by default) reaches
 * rsx_state the same way and is filtered the same way.
 *
 * cc -std=gnu17 -I include -I libs/video
 *   libs/video/tests/test_gcm_legacy_state_filter.c
 *   -ffunction-sections -fdata-sections -Wl,-dead_strip -o /tmp/test_gcm_legacy_state_filter
 *   (gcc: -Wl,--gc-sections -pthread -lm)
 */
#include "../cellGcmSys.c"
#include "../rsx_tiling.c"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
/* GCM_REPORT_SPU_HOLD_MS asks the SPU task layer whether a task round is
 * running; there are no SPU tasks here. */
int spu_taskset_round_busy(uint32_t* ts, uint32_t* tid) { (void)ts; (void)tid; return 0; }
uint8_t* vm_base;
uint32_t ppu_vm_size;
int g_resv_store_active;
uint32_t g_ww_lo, g_ww_hi;
void ppu_resv_break_store(uint64_t ea) { (void)ea; }
void ps3_ww_report_inline(uint32_t a, uint64_t v, int w) { (void)a; (void)v; (void)w; }
int spu_coh_is_reserved(uint32_t a) { (void)a; return 0; }
void spu_coh_notify_write(uint32_t a) { (void)a; }
void spu_lockline_lock(void) {}
void spu_lockline_unlock(void) {}
ps3_guest_caller_fn g_ps3_guest_caller;
/* The walker's other consumers: no graphics backend, no lifted program. */
PPU_THREAD_LOCAL ppu_context* g_active_ctx;
u32 g_rsx_last_reference;
void (*g_spu_put_hook)(uint32_t ea, uint32_t size);
void ppu_dump_bctrl_ring(uint32_t n, const char* why) { (void)n; (void)why; }
void ppu_dump_guest_stack(ppu_context* c, const char* why) { (void)c; (void)why; }
void rsx_state_init(rsx_state* state) { (void)state; }
/* What the walker hands rsx_state, and the switches that decide it. */
static u32 legacy_seen[64], legacy_n;
static int engine_on=1;
static u32 engine_methods[32],engine_values[32],engine_n,live_n;
static rsx_backend* vtable;
int  rsx_process_method(rsx_state* state, u32 method, u32 data)
{ (void)state; (void)data; if (legacy_n < 64) legacy_seen[legacy_n++] = method; return 0; }
int  rsx_draw_engine_enabled(void) { return engine_on; }
rsx_backend* rsx_get_backend(void) { return vtable; }
/* The walker hands vertex-program runs here (#554). */
int  rsx_process_vp_run(rsx_state* state, u32 method, const u8* src, u32 count)
{ (void)state; (void)method; (void)src; (void)count; return 0; }
void rsx_draw_engine_method(u32 method, u32 arg) { if(engine_n<32){engine_methods[engine_n]=method;engine_values[engine_n++]=arg;} }
void rsx_draw_engine_note_flip(u32 buffer_id) { (void)buffer_id; }
void rsx_draw_engine_guest_read(u32 l, u32 o, u32 p, u32 w, u32 h) { (void)l; (void)o; (void)p; (void)w; (void)h; }
void rsx_draw_engine_guest_wrote(u32 l, u32 o, u32 p, u32 w, u32 h) { (void)l; (void)o; (void)p; (void)w; (void)h; }
int  rsx_live_draw_enabled(void) { return 1; }
void rsx_live_draw_method(u32 method, u32 arg) { (void)method; (void)arg; live_n++; }
int  rsx_live_draw_blit(u32 a, u32 b, u32 c, u32 d, u32 e, u32 f, u32 w, u32 h)
{ (void)a; (void)b; (void)c; (void)d; (void)e; (void)f; (void)w; (void)h; return 0; }
void rsx_live_draw_note_resolve(u32 a, u32 b, u32 c, u32 d) { (void)a; (void)b; (void)c; (void)d; }
int  rsx_live_draw_resolve_blit(u32 a, u32 b, u32 c, u32 d, u32 e, u32 f, u32 g, u32 h,
                                u32 i, u32 j, u32 k, u32 l)
{ (void)a; (void)b; (void)c; (void)d; (void)e; (void)f; (void)g; (void)h; (void)i; (void)j; (void)k; (void)l; return 0; }

static u32 user_interrupts;
void rsx_raise_user_cmd(uint32_t arg) { (void)arg; user_interrupts++; }

#define IO_ADDR   0x00100000u
#define IO_SIZE   0x00100000u
#define CMD_SIZE  0x00010000u

static uint32_t g_heap = 0x00400000u;
static u32 host_alloc(u32 size, u32 align)
{
    if (!align) align = 4;
    g_heap = (g_heap + align - 1u) & ~(align - 1u);
    u32 r = g_heap;
    g_heap += size;
    return r;
}
static void gw32(uint32_t ea, uint32_t v)
{
    uint8_t* p = vm_base + ea;
    p[0] = (uint8_t)(v >> 24); p[1] = (uint8_t)(v >> 16); p[2] = (uint8_t)(v >> 8); p[3] = (uint8_t)v;
}
static void host_w32(u32 ea, u32 v) { gw32(ea, v); }

static int fails;
static void check(int ok, const char* what)
{
    printf("[%s] %s\n", ok ? "PASS" : "FAIL", what);
    fails += !ok;
}

/* Interleave NV4097 state with real NV308A/NV3089 transfer-sized
 * words at identical method offsets. Only NV4097 and driver commands may
 * reach a consumer which canonicalizes the subchannel away. */
int main(int argc,char**argv) {
 const int sub1_2d=argc>1;
 if(sub1_2d)setenv("GCM_SUBCH1_2D","1",1);
 const uint32_t vm_size=ppu_hle_inject_base+0x10000u;
 vm_base=calloc(1,vm_size);if(!vm_base)return 2;ppu_vm_size=vm_size;
 u32 ctx=host_alloc(4,4);cellGcmSetupContext(ctx,CMD_SIZE,IO_SIZE,IO_ADDR,host_alloc,host_w32);
 const u32 ctrl=(u32)(uintptr_t)cellGcmGetControlRegister();
 const u32 cmds[][2]={
  {0x0304,1},{0x0308,0x206},{0x030C,255},
  {0xA304,0},{0xA308,0x10004},{0xA30C,0x10004},
  {0xC304,3},{0xC308,0x10004},{0xC30C,0x10004},
  {0x6304,0x400040},{0x430C,0},
  {0x2308,0x204},{0x230C,128},
  {0xE944,0},{0xEB00,7},{0xEB04,8}};
 for(u32 i=0;i<sizeof(cmds)/sizeof(cmds[0]);i++){
  gw32(IO_ADDR+i*8,(1u<<18)|cmds[i][0]);gw32(IO_ADDR+i*8+4,cmds[i][1]);
 }
 s_fifo_getoff=0;vm_write32(ctrl+4,0);vm_write32(ctrl,sizeof(cmds));cellGcm_rsx_process_fifo();
 const u32 want_default[]={0x0304,0x0308,0x030C,0x2308,0x230C,0xE944,0xEB04};
 const u32 want_sub1_2d[]={0x0304,0x0308,0x030C,0xE944,0xEB04};
 const u32* want=sub1_2d?want_sub1_2d:want_default;u32 n=sub1_2d?5:7;
 check(engine_n==n,"only routed NV4097 and driver methods reach draw engine");
 check(live_n==n,"live mirror follows same routing");
 for(u32 i=0;i<engine_n&&i<n;i++)check(engine_methods[i]==want[i],"stream order and raw subchannel preserved");
 check(user_interrupts==1,"user interrupt remains routed to its interrupt consumer");
 check(engine_values[1]==0x206&&engine_values[2]==255,"alpha state is not replaced by 2D rectangle dimensions");
 printf("[gcm_engine_routing] %s (%d failed)\n",fails?"FAIL":"PASS",fails);
 free(vm_base);return fails?1:0;
}
