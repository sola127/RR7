/* Optional spatial presentation upscaler. Guest render targets stay unchanged. */
#import <Metal/Metal.h>
#import <MetalFX/MetalFX.h>

@interface RSXMetalFX : NSObject
- (instancetype)initWithDevice:(id<MTLDevice>)device;
- (id<MTLTexture>)encode:(id<MTLCommandBuffer>)commandBuffer
                 source:(id<MTLTexture>)source
           contentWidth:(NSUInteger)width contentHeight:(NSUInteger)height
            outputWidth:(NSUInteger)outputWidth outputHeight:(NSUInteger)outputHeight;
@end
