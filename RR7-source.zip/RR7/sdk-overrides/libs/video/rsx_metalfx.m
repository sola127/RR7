#import "rsx_metalfx.h"
#include <stdio.h>

@implementation RSXMetalFX {
    id<MTLDevice> _device;
    id<MTLFXSpatialScaler> _scaler;
    id<MTLTexture> _input, _output;
}
- (instancetype)initWithDevice:(id<MTLDevice>)device
{
    if (!(self = [super init])) return nil;
    if (![MTLFXSpatialScalerDescriptor supportsDevice:device]) return nil;
    _device = device;
    return self;
}
- (id<MTLTexture>)encode:(id<MTLCommandBuffer>)cb
                 source:(id<MTLTexture>)src
           contentWidth:(NSUInteger)width contentHeight:(NSUInteger)height
            outputWidth:(NSUInteger)ow outputHeight:(NSUInteger)oh
{
    if (!cb || !src || !width || !height || !ow || !oh ||
        width > src.width || height > src.height ||
        src.textureType != MTLTextureType2D || src.sampleCount != 1) return nil;
    const MTLPixelFormat format = src.pixelFormat;
    if (format != MTLPixelFormatRGBA8Unorm && format != MTLPixelFormatBGRA8Unorm &&
        format != MTLPixelFormatRGBA16Float) return nil;
    /* Copy the active rectangle into an exact-size texture. Padding in a PS3
     * surface must never become part of the reconstructed image. */
    if (!_scaler || _input.width != width || _input.height != height ||
        _input.pixelFormat != format || _output.width != ow || _output.height != oh) {
        MTLFXSpatialScalerDescriptor *d = [MTLFXSpatialScalerDescriptor new];
        d.inputWidth = width; d.inputHeight = height;
        d.outputWidth = ow; d.outputHeight = oh;
        d.colorTextureFormat = format; d.outputTextureFormat = format;
        d.colorProcessingMode = MTLFXSpatialScalerColorProcessingModePerceptual;
        _scaler = [d newSpatialScalerWithDevice:_device];
        _input = nil; _output = nil;
        if (!_scaler) return nil;
        MTLTextureDescriptor *t = [MTLTextureDescriptor
            texture2DDescriptorWithPixelFormat:format width:width height:height mipmapped:NO];
        t.storageMode = MTLStorageModePrivate;
        t.usage = _scaler.colorTextureUsage;
        _input = [_device newTextureWithDescriptor:t];
        t.width = ow; t.height = oh;
        t.usage = _scaler.outputTextureUsage | MTLTextureUsageShaderRead;
        _output = [_device newTextureWithDescriptor:t];
        if (!_input || !_output) { _scaler = nil; return nil; }
        fprintf(stderr, "[rsx engine/metal] MetalFX spatial %lux%lu -> %lux%lu\n",
                (unsigned long)width, (unsigned long)height,
                (unsigned long)ow, (unsigned long)oh);
    }
    id<MTLBlitCommandEncoder> copy = [cb blitCommandEncoder];
    if (!copy) return nil;
    [copy copyFromTexture:src sourceSlice:0 sourceLevel:0 sourceOrigin:MTLOriginMake(0,0,0)
              sourceSize:MTLSizeMake(width,height,1) toTexture:_input
        destinationSlice:0 destinationLevel:0 destinationOrigin:MTLOriginMake(0,0,0)];
    [copy endEncoding];
    _scaler.colorTexture = _input; _scaler.outputTexture = _output;
    _scaler.inputContentWidth = width; _scaler.inputContentHeight = height;
    [_scaler encodeToCommandBuffer:cb];
    return _output;
}
@end
