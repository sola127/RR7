/* Actual raster multisampling. Resolved single-sample surfaces remain the
 * engine ABI, while per-sample colour/depth/stencil survive pass boundaries.
 * A direct write to a resolved surface invalidates its multisample shadow. */
@interface RR7MSAATarget : NSObject
@property(nonatomic,strong) id<MTLTexture> texture;
@property(nonatomic) unsigned valid;
@end
@implementation RR7MSAATarget
@end
static NSMapTable* s_msaa_targets;
static id<MTLLibrary> s_msaa_seed_lib;
static NSMutableDictionary* s_msaa_seed_pipelines;
static unsigned rr7_msaa_requested(void){
    const char* e=getenv("PS3_MSAA_SAMPLES");unsigned n=e?(unsigned)atoi(e):1;
    if(n!=2&&n!=4&&n!=8)return 1;
    return [s_dev supportsTextureSampleCount:n]?n:1;
}
static int rr7_msaa_float32(MTLPixelFormat fmt){
    return fmt==MTLPixelFormatR32Float||fmt==MTLPixelFormatRG32Float||fmt==MTLPixelFormatRGBA32Float;
}
static unsigned rr7_msaa_format_samples(MTLPixelFormat fmt){
    unsigned n=rr7_msaa_requested();
    return n>1&&rr7_msaa_float32(fmt)&&!s_dev.supports32BitMSAA?1:n;
}
static void rr7_msaa_reset(void){s_msaa_targets=nil;s_msaa_seed_lib=nil;s_msaa_seed_pipelines=nil;}
static void rr7_msaa_invalidate(id<MTLTexture> t){
    if(!s_msaa_targets||!t)return;
    while(t.parentTexture)t=t.parentTexture;
    RR7MSAATarget* entry=[s_msaa_targets objectForKey:t];entry.valid=0;
}
static id<MTLRenderCommandEncoder> rr7_single_encoder(id<MTLCommandBuffer> cb,MTLRenderPassDescriptor* rp){
    for(unsigned i=0;i<8;i++)rr7_msaa_invalidate(rp.colorAttachments[i].texture);
    rr7_msaa_invalidate(rp.depthAttachment.texture);rr7_msaa_invalidate(rp.stencilAttachment.texture);
    return [cb renderCommandEncoderWithDescriptor:rp];
}
static RR7MSAATarget* rr7_msaa_target(id<MTLTexture> base,unsigned n){
    if(!base)return nil;
    if(!s_msaa_targets)s_msaa_targets=[NSMapTable weakToStrongObjectsMapTable];
    RR7MSAATarget* entry=[s_msaa_targets objectForKey:base];if(entry)return entry;
    MTLTextureDescriptor* td=[MTLTextureDescriptor texture2DDescriptorWithPixelFormat:base.pixelFormat width:base.width height:base.height mipmapped:NO];
    td.textureType=MTLTextureType2DMultisample;td.sampleCount=n;td.storageMode=MTLStorageModePrivate;td.usage=MTLTextureUsageRenderTarget;
    id<MTLTexture> tex=[s_dev newTextureWithDescriptor:td];if(!tex)return nil;
    tex.label=[NSString stringWithFormat:@"RR7 real %ux MSAA",n];entry=[RR7MSAATarget new];entry.texture=tex;
    [s_msaa_targets setObject:entry forKey:base];return entry;
}
static id<MTLRenderPipelineState> rr7_msaa_seed_pipeline(MTLPixelFormat fmt,unsigned n,BOOL depth){
    if(!s_msaa_seed_pipelines)s_msaa_seed_pipelines=[NSMutableDictionary new];
    NSString* key=[NSString stringWithFormat:@"%lu:%u:%d",(unsigned long)fmt,n,depth];id pso=s_msaa_seed_pipelines[key];if(pso)return pso;
    if(!s_msaa_seed_lib){
        NSString* source=@"#include <metal_stdlib>\nusing namespace metal;\n"
        "struct V{float4 p[[position]];};\n"
        "vertex V seed_v(uint i[[vertex_id]]){float2 p[3]={float2(-1,-1),float2(3,-1),float2(-1,3)};return {float4(p[i],0,1)};}\n"
        "fragment float4 seed_c(V v[[stage_in]],texture2d<float> t[[texture(0)]]){return t.read(uint2(v.p.xy));}\n"
        "struct DS{float d[[depth(any)]];uint s[[stencil]];};\n"
        "fragment DS seed_ds(V v[[stage_in]],depth2d<float> z[[texture(0)]],texture2d<uint> s[[texture(1)]],constant uint& mask[[buffer(0)]]){uint2 p=uint2(v.p.xy);DS o;o.d=(mask&2)?z.read(p):1;o.s=(mask&4)?s.read(p).r:0;return o;}\n";
        NSError* error=nil;s_msaa_seed_lib=[s_dev newLibraryWithSource:source options:nil error:&error];
        if(!s_msaa_seed_lib){fprintf(stderr,"[MSAA] seed library: %s\n",error.description.UTF8String);return nil;}
    }
    MTLRenderPipelineDescriptor* pd=[MTLRenderPipelineDescriptor new];pd.vertexFunction=[s_msaa_seed_lib newFunctionWithName:@"seed_v"];
    pd.fragmentFunction=[s_msaa_seed_lib newFunctionWithName:depth?@"seed_ds":@"seed_c"];pd.rasterSampleCount=n;
    if(depth){pd.depthAttachmentPixelFormat=fmt;pd.stencilAttachmentPixelFormat=fmt;}else pd.colorAttachments[0].pixelFormat=fmt;
    NSError* error=nil;pso=[s_dev newRenderPipelineStateWithDescriptor:pd error:&error];
    if(!pso){fprintf(stderr,"[MSAA] seed pipeline: %s\n",error.description.UTF8String);return nil;}
    s_msaa_seed_pipelines[key]=pso;return pso;
}
static BOOL rr7_msaa_seed_color(id<MTLCommandBuffer> cb,id<MTLTexture> base,RR7MSAATarget* target,unsigned n){
    id<MTLRenderPipelineState> pso=rr7_msaa_seed_pipeline(base.pixelFormat,n,NO);if(!pso)return NO;
    MTLRenderPassDescriptor* rp=[MTLRenderPassDescriptor renderPassDescriptor];rp.colorAttachments[0].texture=target.texture;rp.colorAttachments[0].loadAction=MTLLoadActionDontCare;rp.colorAttachments[0].storeAction=MTLStoreActionStore;
    id<MTLRenderCommandEncoder> enc=[cb renderCommandEncoderWithDescriptor:rp];if(!enc)return NO;
    [enc setRenderPipelineState:pso];[enc setFragmentTexture:base atIndex:0];[enc drawPrimitives:MTLPrimitiveTypeTriangle vertexStart:0 vertexCount:3];[enc endEncoding];target.valid|=1;return YES;
}
static BOOL rr7_msaa_seed_depth(id<MTLCommandBuffer> cb,id<MTLTexture> base,RR7MSAATarget* target,unsigned n,unsigned mask){
    if(!mask)return YES;
    id<MTLRenderPipelineState> pso=rr7_msaa_seed_pipeline(base.pixelFormat,n,YES);if(!pso)return NO;
    id<MTLTexture> stencil=[base newTextureViewWithPixelFormat:MTLPixelFormatX32_Stencil8];if(!stencil)return NO;
    MTLRenderPassDescriptor* rp=[MTLRenderPassDescriptor renderPassDescriptor];rp.depthAttachment.texture=target.texture;rp.stencilAttachment.texture=target.texture;
    rp.depthAttachment.loadAction=(target.valid&2)?MTLLoadActionLoad:MTLLoadActionDontCare;rp.stencilAttachment.loadAction=(target.valid&4)?MTLLoadActionLoad:MTLLoadActionDontCare;
    rp.depthAttachment.storeAction=rp.stencilAttachment.storeAction=MTLStoreActionStore;
    MTLDepthStencilDescriptor* dd=[MTLDepthStencilDescriptor new];dd.depthCompareFunction=MTLCompareFunctionAlways;dd.depthWriteEnabled=(mask&2)!=0;
    MTLStencilDescriptor* sd=[MTLStencilDescriptor new];sd.stencilCompareFunction=MTLCompareFunctionAlways;sd.depthStencilPassOperation=MTLStencilOperationReplace;sd.writeMask=(mask&4)?255:0;dd.frontFaceStencil=dd.backFaceStencil=sd;
    id<MTLDepthStencilState> ds=[s_dev newDepthStencilStateWithDescriptor:dd];if(!ds)return NO;
    id<MTLRenderCommandEncoder> enc=[cb renderCommandEncoderWithDescriptor:rp];if(!enc)return NO;
    [enc setRenderPipelineState:pso];[enc setDepthStencilState:ds];[enc setFragmentTexture:base atIndex:0];[enc setFragmentTexture:stencil atIndex:1];[enc setFragmentBytes:&mask length:sizeof mask atIndex:0];[enc drawPrimitives:MTLPrimitiveTypeTriangle vertexStart:0 vertexCount:3];[enc endEncoding];target.valid|=mask;return YES;
}
static id<MTLRenderCommandEncoder> rr7_msaa_encoder(id<MTLCommandBuffer> cb,MTLRenderPassDescriptor* original){
    unsigned n=rr7_msaa_requested();for(unsigned i=0;i<8;i++)if(original.colorAttachments[i].texture&&rr7_msaa_format_samples(original.colorAttachments[i].texture.pixelFormat)==1)n=1;
    if(n==1)return rr7_single_encoder(cb,original);
    MTLRenderPassDescriptor* rp=[original copy];
    for(unsigned i=0;i<8;i++){
        id<MTLTexture> base=rp.colorAttachments[i].texture;if(!base)continue;RR7MSAATarget* target=rr7_msaa_target(base,n);if(!target)return nil;
        if(rp.colorAttachments[i].loadAction==MTLLoadActionLoad&&!(target.valid&1)&&!rr7_msaa_seed_color(cb,base,target,n))return nil;
        rp.colorAttachments[i].texture=target.texture;rp.colorAttachments[i].resolveTexture=base;rp.colorAttachments[i].storeAction=MTLStoreActionStoreAndMultisampleResolve;target.valid|=1;
    }
    id<MTLTexture> base=rp.depthAttachment.texture;
    if(base){
        RR7MSAATarget* target=rr7_msaa_target(base,n);if(!target)return nil;
        unsigned seed=0;if(rp.depthAttachment.loadAction==MTLLoadActionLoad&&!(target.valid&2))seed|=2;
        if(rp.stencilAttachment.texture&&rp.stencilAttachment.loadAction==MTLLoadActionLoad&&!(target.valid&4))seed|=4;
        if(!rr7_msaa_seed_depth(cb,base,target,n,seed))return nil;
        rp.depthAttachment.texture=target.texture;rp.depthAttachment.resolveTexture=base;rp.depthAttachment.storeAction=MTLStoreActionStoreAndMultisampleResolve;
        rp.depthAttachment.depthResolveFilter=MTLMultisampleDepthResolveFilterMin;target.valid|=2;
        if(rp.stencilAttachment.texture){rp.stencilAttachment.texture=target.texture;rp.stencilAttachment.resolveTexture=base;rp.stencilAttachment.storeAction=MTLStoreActionStoreAndMultisampleResolve;rp.stencilAttachment.stencilResolveFilter=MTLMultisampleStencilResolveFilterDepthResolvedSample;target.valid|=4;}
    }
    return [cb renderCommandEncoderWithDescriptor:rp];
}
