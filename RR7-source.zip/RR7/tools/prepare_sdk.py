"""Fetch the pinned upstream SDK, apply source changes, preserve all notices."""
from pathlib import Path
import json, shutil, subprocess

root = Path(__file__).resolve().parents[1]
sdk = root / "ps3recomp"
if sdk.exists():
    raise SystemExit("ps3recomp already exists; refusing to overwrite local changes")
pin = json.loads((root / "upstream.json").read_text())
subprocess.run(["git", "clone", "--no-checkout", pin["repository"], str(sdk)], check=True)
subprocess.run(["git", "-C", str(sdk), "checkout", "--detach", pin["commit"]], check=True)
patch = root / "patches/ps3recomp.patch"
subprocess.run(["git", "-C", str(sdk), "apply", "--check", str(patch)], check=True)
subprocess.run(["git", "-C", str(sdk), "apply", str(patch)], check=True)
for source in (root / "sdk-overrides").rglob("*"):
    if source.is_file():
        target = sdk / source.relative_to(root / "sdk-overrides")
        if target.exists():
            raise SystemExit(f"New SDK source unexpectedly exists: {target.relative_to(sdk)}")
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, target)
print("Pinned SDK ready. Keep its MIT and separable-component license notices.")
