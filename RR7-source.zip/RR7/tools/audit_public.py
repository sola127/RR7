"""Conservative accidental-upload checks; not a legal clearance tool."""
from pathlib import Path
import hashlib, json, re, subprocess, sys

root = Path(__file__).resolve().parents[1]
allowed_suffix = {".py", ".sh", ".cpp", ".c", ".h", ".hpp", ".m", ".txt", ".md", ".json", ".patch", ".yml"}
blocked_parts = {"recompiled", "spu_images", "game", "gamedata", "hdd0", "analysis", "assets", "deps", "deps-src", "deps-build", "deps-prefix", "deps-prefix-av", "build"}
errors = []
manifest = []
# In a checkout, examine every tracked/staged/unignored candidate, including
# files that were explicitly force-added despite .gitignore.
git = subprocess.run(["git", "-C", str(root), "ls-files", "--cached", "--others", "--exclude-standard", "-z"], capture_output=True)
if (root / ".git").exists() and git.returncode == 0:
    candidates = [root / n.decode() for n in git.stdout.split(b"\0") if n]
else:
    candidates = [f for f in root.rglob("*") if f.is_file() and ".git" not in f.relative_to(root).parts]
for path in sorted(set(candidates)):
    relative = path.relative_to(root)
    if path.is_symlink():
        errors.append(f"symlink forbidden: {relative}"); continue
    if any(p in blocked_parts or p.endswith((".app", ".dSYM")) for p in relative.parts):
        errors.append(f"private/generated directory: {relative}")
    if path.suffix not in allowed_suffix and path.name not in {"LICENSE", ".gitignore"}:
        errors.append(f"unreviewed file type: {relative}")
    data = path.read_bytes()
    try: text = data.decode("utf-8")
    except UnicodeDecodeError:
        errors.append(f"non-text file: {relative}"); continue
    if b"\0" in data or len(data) > 1_000_000:
        errors.append(f"binary/oversize payload: {relative}")
    if "GIT binary patch" in text and path.suffix == ".patch":
        errors.append(f"binary patch: {relative}")
    patterns = [r"/Users/[A-Za-z0-9_-]+/", r"(?:gh[pousr]_)[A-Za-z0-9]{30,}", r"github_pat_[A-Za-z0-9_]{40,}", r"-----BEGIN [A-Z ]*PRIVATE KEY-----", r"AKIA[0-9A-Z]{16}"]
    if any(re.search(p, text) for p in patterns):
        errors.append(f"possible personal path/credential: {relative}")
    if path.name != "PUBLIC_MANIFEST.json":
        manifest.append({"path": relative.as_posix(), "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()})
if errors:
    raise SystemExit("\n".join(errors))
if "--write-manifest" in sys.argv:
    (root / "PUBLIC_MANIFEST.json").write_text(json.dumps(manifest, indent=2) + "\n")
else:
    expected = json.loads((root / "PUBLIC_MANIFEST.json").read_text())
    if expected != manifest:
        raise SystemExit("Manifest differs; review changes before regenerating it")
print(f"PASS: {len(manifest)} reviewed text files; no detected prohibited payloads")
